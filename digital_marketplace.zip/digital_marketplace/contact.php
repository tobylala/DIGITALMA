
<?php
$pageTitle = 'Contact Us';
$activePage = 'contact';
include 'includes/header.php';
?>

<section class="page-banner">
    <div class="container">
        <h1>Contact Us</h1>
        <p>Have a question? We would like to hear from you.</p>
    </div>
</section>

<section class="section-padding">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-5">
                <h2 class="section-heading">Get in Touch</h2>
                <p class="text-secondary">
                    Contact our team for questions about accounts,
                    digital products, payments or affiliate commissions.
                </p>

                <div class="d-flex gap-3 align-items-center mt-4">
                    <div class="feature-icon mb-0">
                        <i class="bi bi-envelope"></i>
                    </div>
                    <div>
                        <strong>Email</strong>
                        <p class="text-secondary mb-0">
                            Contact email will be added here.
                        </p>
                    </div>
                </div>

                <div class="d-flex gap-3 align-items-center mt-4">
                    <div class="feature-icon mb-0">
                        <i class="bi bi-geo-alt"></i>
                    </div>
                    <div>
                        <strong>Location</strong>
                        <p class="text-secondary mb-0">
                            Ethiopia
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="feature-card">
                    <h4 class="section-heading mb-4">Send a Message</h4>

                    <form action="#" method="post"
                          onsubmit="alert('The contact form is not connected yet. We will implement message processing later.'); return false;">

                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control"
                                   placeholder="Enter your full name" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control"
                                   placeholder="Enter your email" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Subject</label>
                            <input type="text" class="form-control"
                                   placeholder="Message subject" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Message</label>
                            <textarea class="form-control" rows="5"
                                      placeholder="Write your message..."
                                      required></textarea>
                        </div>

                        <button type="submit" class="btn btn-gold px-4">
                            Send Message <i class="bi bi-send ms-2"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
