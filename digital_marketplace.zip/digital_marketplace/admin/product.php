
<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection error. A PDO connection named $pdo is required.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

/* =========================================================
   ADMIN AUTHENTICATION
========================================================= */

if (empty($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT id, full_name, role, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([(int) $_SESSION['user_id']]);
$currentUser = $stmt->fetch();

if (
    !$currentUser ||
    $currentUser['role'] !== 'admin' ||
    $currentUser['status'] !== 'active'
) {
    session_unset();
    session_destroy();
    header('Location: ../login.php');
    exit;
}

/* =========================================================
   CHECK PRODUCTS TABLE
========================================================= */

$requiredColumns = [
    'id', 'product_name', 'description', 'price',
    'commission_rate', 'image_path', 'file_path',
    'status', 'created_at', 'updated_at'
];

$columns = $pdo->query("SHOW COLUMNS FROM products")->fetchAll();
$existingColumns = array_column($columns, 'Field');
$missingColumns = array_diff($requiredColumns, $existingColumns);

if ($missingColumns) {
    die(
        '<h2>Products table structure mismatch</h2><pre>' .
        htmlspecialchars(implode(', ', $missingColumns), ENT_QUOTES, 'UTF-8') .
        '</pre>'
    );
}

/* =========================================================
   UPLOAD DIRECTORIES
========================================================= */

$projectRoot = dirname(__DIR__);

$imageDirectory = $projectRoot . '/storage/products/uploads/images/';
$fileDirectory = $projectRoot . '/storage/products/uploads/files/';

$imageUrlPrefix = 'storage/products/uploads/images/';
$fileUrlPrefix = 'storage/products/uploads/files/';

foreach ([$imageDirectory, $fileDirectory] as $directory) {
    if (!is_dir($directory)) {
        if (!mkdir($directory, 0755, true) && !is_dir($directory)) {
            die('Unable to create upload directory.');
        }
    }

    if (!is_writable($directory)) {
        die('Upload directory is not writable: ' . htmlspecialchars($directory));
    }
}

/* Block direct web access to downloadable files.
   Downloads should be served through a protected download page. */
$htaccess = $fileDirectory . '.htaccess';

if (!file_exists($htaccess)) {
    @file_put_contents($htaccess, "Require all denied\nDeny from all\n");
}

if (empty($_SESSION['products_csrf'])) {
    $_SESSION['products_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['products_csrf'];
$message = '';
$messageType = 'success';

/* =========================================================
   ALLOWED FILE FORMATS
========================================================= */

$imageExtensions = [
    'jpg'  => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png'  => ['image/png'],
    'webp' => ['image/webp'],
    'gif'  => ['image/gif'],
    'bmp'  => ['image/bmp', 'image/x-ms-bmp'],
    'tif'  => ['image/tiff'],
    'tiff' => ['image/tiff'],
    'avif' => ['image/avif']
];

$documentExtensions = [
    'pdf' => ['application/pdf'],
    'zip' => ['application/zip', 'application/x-zip-compressed'],
    'rar' => ['application/vnd.rar', 'application/x-rar'],
    'doc' => ['application/msword'],
    'docx' => [
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/zip'
    ],
    'xls' => ['application/vnd.ms-excel'],
    'xlsx' => [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/zip'
    ],
    'ppt' => ['application/vnd.ms-powerpoint'],
    'pptx' => [
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/zip'
    ],
    'mp3' => ['audio/mpeg', 'audio/mp3'],
    'mp4' => ['video/mp4'],
    'txt' => ['text/plain'],
    'csv' => ['text/plain', 'text/csv', 'application/csv']
];

$downloadExtensions = array_merge($imageExtensions, $documentExtensions);

/* =========================================================
   HELPER FUNCTIONS
========================================================= */

function productEscape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function productUpload(
    string $field,
    string $directory,
    string $urlPrefix,
    array $allowedTypes,
    int $maxSize
): ?string {

    if (!isset($_FILES[$field])) {
        return null;
    }

    $file = $_FILES[$field];

    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('File upload failed. Please try again.');
    }

    if (
        !is_uploaded_file($file['tmp_name']) ||
        $file['size'] <= 0 ||
        $file['size'] > $maxSize
    ) {
        throw new RuntimeException('File is invalid or exceeds the allowed size.');
    }

    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!isset($allowedTypes[$extension])) {
        throw new RuntimeException(
            'This file extension is not allowed: .' . productEscape($extension)
        );
    }

    if (!class_exists('finfo')) {
        throw new RuntimeException('Enable the PHP Fileinfo extension.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    if (!in_array($mime, $allowedTypes[$extension], true)) {
        throw new RuntimeException(
            'The uploaded file content does not match its extension. Detected type: ' .
            $mime
        );
    }

    $newName = bin2hex(random_bytes(20)) . '.' . $extension;
    $destination = $directory . $newName;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new RuntimeException('Unable to save uploaded file.');
    }

    return $urlPrefix . $newName;
}

function productDeleteFile(?string $relativePath, string $projectRoot): void
{
    if (!$relativePath) {
        return;
    }

    $relativePath = str_replace('\\', '/', $relativePath);

    if (strpos($relativePath, 'storage/products/uploads/') !== 0) {
        return;
    }

    if (strpos($relativePath, '..') !== false) {
        return;
    }

    $root = realpath($projectRoot);
    $fullPath = realpath($projectRoot . '/' . $relativePath);

    if (!$root || !$fullPath || !is_file($fullPath)) {
        return;
    }

    if (strpos($fullPath, $root . DIRECTORY_SEPARATOR) !== 0) {
        return;
    }

    @unlink($fullPath);
}

function productTableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
    ");
    $stmt->execute([$table]);

    return (int) $stmt->fetchColumn() > 0;
}

function productTableHasColumn(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
          AND COLUMN_NAME = ?
    ");
    $stmt->execute([$table, $column]);

    return (int) $stmt->fetchColumn() > 0;
}

/* =========================================================
   HANDLE POST REQUESTS
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUploads = [];

    try {
        $submittedToken = $_POST['csrf_token'] ?? '';

        if (
            !is_string($submittedToken) ||
            !hash_equals($csrfToken, $submittedToken)
        ) {
            throw new RuntimeException('Invalid security token. Refresh and try again.');
        }

        $action = $_POST['action'] ?? '';

        /* ---------------- ADD PRODUCT ---------------- */

        if ($action === 'add') {
            $name = trim($_POST['product_name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $price = filter_var($_POST['price'] ?? '', FILTER_VALIDATE_FLOAT);
            $commission = filter_var($_POST['commission_rate'] ?? '0', FILTER_VALIDATE_FLOAT);
            $status = $_POST['status'] ?? 'inactive';

            if ($name === '' || strlen($name) > 200) {
                throw new RuntimeException('Product name is required (maximum 200 characters).');
            }

            if ($price === false || $price < 0) {
                throw new RuntimeException('Enter a valid product price.');
            }

            if ($commission === false || $commission < 0 || $commission > 100) {
                throw new RuntimeException('Commission must be between 0 and 100.');
            }

            if (!in_array($status, ['active', 'inactive'], true)) {
                throw new RuntimeException('Invalid product status.');
            }

            $imagePath = productUpload(
                'product_image',
                $imageDirectory,
                $imageUrlPrefix,
                $imageExtensions,
                5 * 1024 * 1024
            );

            if ($imagePath) {
                $newUploads[] = $imagePath;
            }

            $filePath = productUpload(
                'product_file',
                $fileDirectory,
                $fileUrlPrefix,
                $downloadExtensions,
                50 * 1024 * 1024
            );

            if ($filePath) {
                $newUploads[] = $filePath;
            }

            if (!$filePath) {
                throw new RuntimeException('Please select a downloadable product file.');
            }

            $stmt = $pdo->prepare("
                INSERT INTO products (
                    product_name,
                    description,
                    price,
                    commission_rate,
                    image_path,
                    file_path,
                    status
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $name,
                $description,
                $price,
                $commission,
                $imagePath,
                $filePath,
                $status
            ]);

            header('Location: products.php?success=added');
            exit;
        }

        /* ---------------- EDIT PRODUCT ---------------- */

        if ($action === 'edit') {
            $id = filter_var($_POST['product_id'] ?? '', FILTER_VALIDATE_INT);

            if (!$id || $id < 1) {
                throw new RuntimeException('Invalid product ID.');
            }

            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$id]);
            $oldProduct = $stmt->fetch();

            if (!$oldProduct) {
                throw new RuntimeException('Product not found.');
            }

            $name = trim($_POST['product_name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $price = filter_var($_POST['price'] ?? '', FILTER_VALIDATE_FLOAT);
            $commission = filter_var($_POST['commission_rate'] ?? '0', FILTER_VALIDATE_FLOAT);
            $status = $_POST['status'] ?? 'inactive';

            if ($name === '' || strlen($name) > 200) {
                throw new RuntimeException('Product name is required (maximum 200 characters).');
            }

            if ($price === false || $price < 0) {
                throw new RuntimeException('Enter a valid product price.');
            }

            if ($commission === false || $commission < 0 || $commission > 100) {
                throw new RuntimeException('Commission must be between 0 and 100.');
            }

            if (!in_array($status, ['active', 'inactive'], true)) {
                throw new RuntimeException('Invalid product status.');
            }

            $newImage = productUpload(
                'product_image',
                $imageDirectory,
                $imageUrlPrefix,
                $imageExtensions,
                5 * 1024 * 1024
            );

            if ($newImage) {
                $newUploads[] = $newImage;
            }

            $newFile = productUpload(
                'product_file',
                $fileDirectory,
                $fileUrlPrefix,
                $downloadExtensions,
                50 * 1024 * 1024
            );

            if ($newFile) {
                $newUploads[] = $newFile;
            }

            $imagePath = $newImage ?: $oldProduct['image_path'];
            $filePath = $newFile ?: $oldProduct['file_path'];

            if (!$filePath) {
                throw new RuntimeException('Please upload a downloadable product file.');
            }

            $stmt = $pdo->prepare("
                UPDATE products
                SET
                    product_name = ?,
                    description = ?,
                    price = ?,
                    commission_rate = ?,
                    image_path = ?,
                    file_path = ?,
                    status = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $name,
                $description,
                $price,
                $commission,
                $imagePath,
                $filePath,
                $status,
                $id
            ]);

            if ($newImage) {
                productDeleteFile($oldProduct['image_path'], $projectRoot);
            }

            if ($newFile) {
                productDeleteFile($oldProduct['file_path'], $projectRoot);
            }

            header('Location: products.php?success=updated');
            exit;
        }

        /* ---------------- CHANGE STATUS ---------------- */

        if ($action === 'status') {
            $id = filter_var($_POST['product_id'] ?? '', FILTER_VALIDATE_INT);
            $status = $_POST['status'] ?? '';

            if (!$id || !in_array($status, ['active', 'inactive'], true)) {
                throw new RuntimeException('Invalid status request.');
            }

            $stmt = $pdo->prepare("
                UPDATE products
                SET status = ?
                WHERE id = ?
            ");
            $stmt->execute([$status, $id]);

            header('Location: products.php?success=status');
            exit;
        }

        /* ---------------- DELETE PRODUCT ---------------- */

        if ($action === 'delete') {
            $id = filter_var($_POST['product_id'] ?? '', FILTER_VALIDATE_INT);

            if (!$id || $id < 1) {
                throw new RuntimeException('Invalid product ID.');
            }

            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$id]);
            $product = $stmt->fetch();

            if (!$product) {
                throw new RuntimeException('Product not found.');
            }

            foreach (['orders', 'order_items', 'product_access'] as $table) {
                if (
                    productTableExists($pdo, $table) &&
                    productTableHasColumn($pdo, $table, 'product_id')
                ) {
                    $check = $pdo->prepare(
                        "SELECT COUNT(*) FROM `$table` WHERE product_id = ?"
                    );
                    $check->execute([$id]);

                    if ((int) $check->fetchColumn() > 0) {
                        throw new RuntimeException(
                            'This product has purchase records. Deactivate it instead of deleting it.'
                        );
                    }
                }
            }

            $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$id]);

            productDeleteFile($product['image_path'], $projectRoot);
            productDeleteFile($product['file_path'], $projectRoot);

            header('Location: products.php?success=deleted');
            exit;
        }

        throw new RuntimeException('Unknown action.');

    } catch (Throwable $e) {
        foreach ($newUploads as $uploadedPath) {
            productDeleteFile($uploadedPath, $projectRoot);
        }

        $message = $e->getMessage();
        $messageType = 'error';
    }
}

/* =========================================================
   SUCCESS MESSAGES
========================================================= */

$successMessages = [
    'added' => 'Product added successfully.',
    'updated' => 'Product updated successfully.',
    'deleted' => 'Product deleted successfully.',
    'status' => 'Product status updated successfully.'
];

if (isset($_GET['success']) && isset($successMessages[$_GET['success']])) {
    $message = $successMessages[$_GET['success']];
    $messageType = 'success';
}

/* =========================================================
   SEARCH AND FILTER
========================================================= */

$search = trim($_GET['search'] ?? '');
$statusFilter = $_GET['status'] ?? '';

$where = [];
$params = [];

if ($search !== '') {
    $where[] = "(product_name LIKE ? OR description LIKE ?)";
    $params[] = '%' . $search . '%';
    $params[] = '%' . $search . '%';
}

if (in_array($statusFilter, ['active', 'inactive'], true)) {
    $where[] = "status = ?";
    $params[] = $statusFilter;
}

$sql = "SELECT * FROM products";

if ($where) {
    $sql .= " WHERE " . implode(' AND ', $where);
}

$sql .= " ORDER BY id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

/* =========================================================
   STATISTICS
========================================================= */

$stats = $pdo->query("
    SELECT
        COUNT(*) AS total,
        COALESCE(SUM(status = 'active'), 0) AS active,
        COALESCE(SUM(status = 'inactive'), 0) AS inactive
    FROM products
")->fetch();

/* =========================================================
   EDIT PRODUCT
========================================================= */

$editProduct = null;

if (isset($_GET['edit'])) {
    $editId = filter_var($_GET['edit'], FILTER_VALIDATE_INT);

    if ($editId && $editId > 0) {
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$editId]);
        $editProduct = $stmt->fetch();
    }
}

$isEditing = is_array($editProduct);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Product Management | DigitalMarket Admin</title>

<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Inter,Arial,sans-serif;background:#f3f5f9;color:#17243b}
.sidebar{width:245px;height:100vh;position:fixed;top:0;left:0;background:#102747;color:#fff;padding:28px 18px;overflow-y:auto}
.brand{font-size:22px;font-weight:800;margin-bottom:42px;padding-left:10px}
.brand span{color:#e5b34c}
.nav-label{color:#9caec4;font-size:11px;text-transform:uppercase;margin:20px 10px 12px;letter-spacing:1.2px}
.sidebar a{display:block;text-decoration:none;color:#dce5f1;padding:13px 12px;margin-bottom:5px;border-radius:8px;font-size:14px}
.sidebar a:hover,.sidebar a.active{background:#203d62;color:#fff}
.sidebar a.active{border-left:3px solid #e5b34c}
.main{margin-left:245px;padding:30px;max-width:1600px}
.topbar{display:flex;align-items:center;justify-content:space-between;gap:15px;margin-bottom:28px}
.topbar h1{font-size:25px;margin-bottom:6px}
.topbar p{color:#78869b;font-size:13px}
.admin-info{background:#fff;border:1px solid #e8edf4;border-radius:10px;padding:11px 16px;font-size:13px}
.stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin-bottom:25px}
.stat-card,.panel{background:#fff;border:1px solid #e8edf4;border-radius:12px;box-shadow:0 3px 12px rgba(20,40,70,.03)}
.stat-card{padding:20px}
.stat-card small{color:#77869b;font-size:12px}
.stat-card h2{margin-top:10px;font-size:27px}
.panel{padding:22px;margin-bottom:24px}
.panel-heading{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;gap:10px}
.panel-heading h2{font-size:17px}
.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.form-group{margin-bottom:15px}
.form-group.full{grid-column:1/-1}
label{display:block;font-size:13px;font-weight:600;margin-bottom:8px}
input,textarea,select{width:100%;padding:11px 12px;border:1px solid #dce3ed;border-radius:7px;outline:none;background:#fff;font:inherit;font-size:13px}
input:focus,textarea:focus,select:focus{border-color:#315c91;box-shadow:0 0 0 3px rgba(49,92,145,.09)}
textarea{min-height:100px;resize:vertical}
.help{color:#8491a4;font-size:11px;margin-top:6px}
.btn{display:inline-block;border:none;border-radius:7px;padding:10px 15px;font-size:12px;font-weight:700;cursor:pointer;text-decoration:none;text-align:center}
.btn-primary{background:#102747;color:#fff}
.btn-primary:hover{background:#1c3d68}
.btn-gold{background:#e5b34c;color:#17243b}
.btn-danger{background:#fff0f0;color:#c0392b}
.btn-light{background:#eef2f7;color:#263b56}
.btn-small{padding:7px 10px;font-size:11px}
.form-actions{display:flex;gap:10px;margin-top:5px}
.alert{padding:13px 16px;border-radius:8px;margin-bottom:20px;font-size:13px}
.alert.success{background:#e8f8ef;color:#187545}
.alert.error{background:#fff0f0;color:#b52e2e}
.filter-row{display:flex;align-items:center;gap:10px;margin-bottom:17px}
.filter-row input{max-width:350px}
.filter-row select{max-width:170px}
.table-wrap{width:100%;overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:850px}
th{background:#f6f8fb;color:#687991;font-size:11px;text-align:left;text-transform:uppercase;letter-spacing:.5px;padding:13px 12px}
td{padding:13px 12px;border-bottom:1px solid #edf0f5;font-size:12px;vertical-align:middle}
.product-cell{display:flex;align-items:center;gap:11px;min-width:180px}
.product-image,.product-placeholder{width:43px;height:43px;border-radius:7px;object-fit:cover;background:#eef2f7}
.product-placeholder{display:flex;align-items:center;justify-content:center;color:#8795a9;font-size:18px}
.product-name{font-weight:700;color:#1d2d44}
.badge{display:inline-block;padding:5px 9px;border-radius:20px;font-size:10px;font-weight:700;text-transform:capitalize}
.badge.active{background:#e5f8ed;color:#16834b}
.badge.inactive{background:#fff0e6;color:#b66a22}
.actions{display:flex;gap:5px;flex-wrap:wrap;align-items:center}
.inline-form{display:inline-flex}
.empty{text-align:center;padding:35px;color:#8290a4}
.current-file{margin-top:7px;font-size:11px;color:#52657d;overflow-wrap:anywhere}
@media(max-width:1000px){.sidebar{width:200px}.main{margin-left:200px;padding:20px}}
@media(max-width:650px){.sidebar{position:static;width:100%;height:auto}.brand{margin-bottom:15px}.main{margin-left:0;padding:15px}.form-grid,.stats{grid-template-columns:1fr}.topbar,.filter-row{align-items:flex-start;flex-direction:column}.filter-row input,.filter-row select{max-width:100%}}
</style>
</head>

<body>

<aside class="sidebar">
    <div class="brand">Digital<span>Market</span></div>

    <a href="dashboard.php">Dashboard</a>
    <a href="products.php" class="active">Manage Products</a>
    <a href="../auth/logout.php">Logout</a>
</aside>

<main class="main">

    <div class="topbar">
        <div>
            <h1>Product Management</h1>
            <p>Add, edit, publish and manage marketplace products.</p>
        </div>

        <div class="admin-info">
            Administrator:
            <strong><?= productEscape($currentUser['full_name']) ?></strong>
        </div>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert <?= productEscape($messageType) ?>">
            <?= productEscape($message) ?>
        </div>
    <?php endif; ?>

    <section class="stats">
        <div class="stat-card">
            <small>Total Products</small>
            <h2><?= (int) ($stats['total'] ?? 0) ?></h2>
        </div>
        <div class="stat-card">
            <small>Active Products</small>
            <h2><?= (int) ($stats['active'] ?? 0) ?></h2>
        </div>
        <div class="stat-card">
            <small>Inactive Products</small>
            <h2><?= (int) ($stats['inactive'] ?? 0) ?></h2>
        </div>
    </section>

    <section class="panel" id="product-form">
        <div class="panel-heading">
            <h2><?= $isEditing ? 'Edit Product' : 'Add New Product' ?></h2>

            <?php if ($isEditing): ?>
                <a href="products.php" class="btn btn-light">Cancel Editing</a>
            <?php endif; ?>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= productEscape($csrfToken) ?>">
            <input type="hidden" name="action" value="<?= $isEditing ? 'edit' : 'add' ?>">

            <?php if ($isEditing): ?>
                <input type="hidden" name="product_id" value="<?= (int) $editProduct['id'] ?>">
            <?php endif; ?>

            <div class="form-grid">

                <div class="form-group">
                    <label>Product Name *</label>
                    <input type="text" name="product_name" maxlength="200" required
                           value="<?= productEscape($editProduct['product_name'] ?? '') ?>"
                           placeholder="Enter product name">
                </div>

                <div class="form-group">
                    <label>Product Price *</label>
                    <input type="number" name="price" min="0" step="0.01" required
                           value="<?= productEscape($editProduct['price'] ?? '') ?>"
                           placeholder="0.00">
                </div>

                <div class="form-group">
                    <label>Commission Rate (%)</label>
                    <input type="number" name="commission_rate" min="0" max="100" step="0.01"
                           value="<?= productEscape($editProduct['commission_rate'] ?? '0') ?>">
                </div>

                <div class="form-group">
                    <label>Product Status</label>
                    <select name="status">
                        <?php $selectedStatus = $editProduct['status'] ?? 'inactive'; ?>
                        <option value="active" <?= $selectedStatus === 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $selectedStatus === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>

                <div class="form-group full">
                    <label>Product Description</label>
                    <textarea name="description" placeholder="Describe your product..."><?= productEscape($editProduct['description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Product Display Image</label>
                    <input type="file" name="product_image"
                           accept=".jpg,.jpeg,.png,.webp,.gif,.bmp,.tif,.tiff,.avif">
                    <div class="help">
                        JPG, PNG, WEBP, GIF, BMP, TIFF or AVIF. Maximum 5 MB.
                        This image appears in the marketplace.
                    </div>

                    <?php if ($isEditing && !empty($editProduct['image_path'])): ?>
                        <div class="current-file">
                            Current image: <?= productEscape($editProduct['image_path']) ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Downloadable Product File *</label>
                    <input type="file" name="product_file"
                           accept=".jpg,.jpeg,.png,.webp,.gif,.bmp,.tif,.tiff,.avif,.pdf,.zip,.rar,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.mp3,.mp4,.txt,.csv"
                           <?= $isEditing ? '' : 'required' ?>>
                    <div class="help">
                        Images/screenshots, PDF, ZIP, RAR, Word, Excel,
                        PowerPoint, MP3, MP4, TXT and CSV. Maximum 50 MB.
                    </div>

                    <?php if ($isEditing && !empty($editProduct['file_path'])): ?>
                        <div class="current-file">
                            Current file: <?= productEscape(basename($editProduct['file_path'])) ?>
                        </div>
                    <?php endif; ?>
                </div>

            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <?= $isEditing ? 'Save Product Changes' : 'Add Product' ?>
                </button>

                <?php if ($isEditing): ?>
                    <a href="product.php" class="btn btn-light">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </section>

    <section class="panel">
        <div class="panel-heading">
            <h2>All Products</h2>
            <span class="help"><?= count($products) ?> result(s)</span>
        </div>

        <form method="GET" class="filter-row">
            <input type="text" name="search" value="<?= productEscape($search) ?>"
                   placeholder="Search product name or description...">

            <select name="status">
                <option value="">All statuses</option>
                <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>Active</option>
                <option value="inactive" <?= $statusFilter === 'inactive' ? 'selected' : '' ?>>Inactive</option>
            </select>

            <button type="submit" class="btn btn-primary">Search</button>
            <a href="products.php" class="btn btn-light">Reset</a>
        </form>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Commission</th>
                        <th>Download File</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (!$products): ?>
                    <tr>
                        <td colspan="8" class="empty">No products found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td>#<?= (int) $product['id'] ?></td>

                            <td>
                                <div class="product-cell">
                                    <?php if (!empty($product['image_path'])): ?>
                                        <img src="../<?= productEscape($product['image_path']) ?>"
                                             alt="Product image" class="product-image">
                                    <?php else: ?>
                                        <div class="product-placeholder">&#9633;</div>
                                    <?php endif; ?>

                                    <div>
                                        <div class="product-name">
                                            <?= productEscape($product['product_name']) ?>
                                        </div>
                                        <div class="help">
                                            <?= productEscape(substr((string) $product['description'], 0, 55)) ?>
                                        </div>
                                    </div>
                                </div>
                            </td>

                            <td><?= number_format((float) $product['price'], 2) ?></td>
                            <td><?= number_format((float) $product['commission_rate'], 2) ?>%</td>
                            <td><?= !empty($product['file_path']) ? 'Available' : 'Missing' ?></td>

                            <td>
                                <span class="badge <?= productEscape($product['status']) ?>">
                                    <?= productEscape($product['status']) ?>
                                </span>
                            </td>

                            <td>
                                <?= !empty($product['created_at'])
                                    ? productEscape(date('M d, Y', strtotime($product['created_at'])))
                                    : '—' ?>
                            </td>

                            <td>
                                <div class="actions">
                                    <a class="btn btn-small btn-light"
                                       href="products.php?edit=<?= (int) $product['id'] ?>#product-form">
                                        Edit
                                    </a>

                                    <form method="POST" class="inline-form">
                                        <input type="hidden" name="csrf_token" value="<?= productEscape($csrfToken) ?>">
                                        <input type="hidden" name="action" value="status">
                                        <input type="hidden" name="product_id" value="<?= (int) $product['id'] ?>">
                                        <input type="hidden" name="status"
                                               value="<?= $product['status'] === 'active' ? 'inactive' : 'active' ?>">
                                        <button type="submit" class="btn btn-small btn-gold">
                                            <?= $product['status'] === 'active' ? 'Deactivate' : 'Activate' ?>
                                        </button>
                                    </form>

                                    <form method="POST" class="inline-form"
                                          onsubmit="return confirm('Permanently delete this product? Products linked to purchases cannot be deleted.');">
                                        <input type="hidden" name="csrf_token" value="<?= productEscape($csrfToken) ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="product_id" value="<?= (int) $product['id'] ?>">
                                        <button type="submit" class="btn btn-small btn-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</main>
</body>
</html>
