
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../user/dashboard.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Database Connection
|--------------------------------------------------------------------------
*/

if (!isset($pdo) || !($pdo instanceof PDO)) {
    exit('Database connection failed. Please check config/database.php.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

$adminId = (int) $_SESSION['user_id'];
$adminName = $_SESSION['user_name'] ?? 'Administrator';

/*
|--------------------------------------------------------------------------
| CSRF Token
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/*
|--------------------------------------------------------------------------
| Secure Logout Handler
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {

    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !isset($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $submittedToken)
    ) {
        http_response_code(403);
        exit('Invalid security token. Please refresh the page and try again.');
    }

    // Clear all session variables
    $_SESSION = [];

    // Remove session cookie
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            [
                'expires' => time() - 42000,
                'path' => $params['path'],
                'domain' => $params['domain'],
                'secure' => $params['secure'],
                'httponly' => $params['httponly'],
                'samesite' => $params['samesite'] ?? 'Lax'
            ]
        );
    }

    // Destroy session
    session_destroy();

    // Redirect to login
    header('Location: ../auth/login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Helper Functions
|--------------------------------------------------------------------------
*/

function e($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function getCount(PDO $pdo, string $sql, array $params = []): int
{
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        return (int) $stmt->fetchColumn();
    } catch (PDOException $exception) {
        error_log('Admin dashboard count error: ' . $exception->getMessage());
        return 0;
    }
}

function getAmount(PDO $pdo, string $sql, array $params = []): float
{
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        return (float) $stmt->fetchColumn();
    } catch (PDOException $exception) {
        error_log('Admin dashboard amount error: ' . $exception->getMessage());
        return 0;
    }
}

function getRows(PDO $pdo, string $sql, array $params = []): array
{
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll();
    } catch (PDOException $exception) {
        error_log('Admin dashboard query error: ' . $exception->getMessage());
        return [];
    }
}

function statusClass(string $status): string
{
    return match (strtolower($status)) {
        'active', 'completed', 'approved', 'success' => 'success',
        'pending', 'processing' => 'warning',
        'rejected', 'failed', 'cancelled', 'suspended' => 'danger',
        default => 'secondary'
    };
}

function money($amount): string
{
    return number_format((float) $amount, 2);
}

/*
|--------------------------------------------------------------------------
| Dashboard Statistics
|--------------------------------------------------------------------------
*/

// Users
$totalUsers = getCount(
    $pdo,
    "SELECT COUNT(*) FROM users"
);

$totalAdmins = getCount(
    $pdo,
    "SELECT COUNT(*) FROM users WHERE role = 'admin'"
);

$totalCustomers = getCount(
    $pdo,
    "SELECT COUNT(*) FROM users WHERE role = 'user'"
);

$activeUsers = getCount(
    $pdo,
    "SELECT COUNT(*) FROM users WHERE status = 'active'"
);

// Products
$totalProducts = getCount(
    $pdo,
    "SELECT COUNT(*) FROM products"
);

$activeProducts = getCount(
    $pdo,
    "SELECT COUNT(*) FROM products WHERE status = 'active'"
);

// Orders
$totalOrders = getCount(
    $pdo,
    "SELECT COUNT(*) FROM orders"
);

$completedOrders = getCount(
    $pdo,
    "SELECT COUNT(*) FROM orders WHERE status = 'completed'"
);

$pendingOrders = getCount(
    $pdo,
    "SELECT COUNT(*) FROM orders WHERE status = 'pending'"
);

$totalSales = getAmount(
    $pdo,
    "SELECT COALESCE(SUM(total_amount), 0)
     FROM orders
     WHERE status = 'completed'"
);

// Deposits
$totalDeposits = getCount(
    $pdo,
    "SELECT COUNT(*) FROM deposits"
);

$pendingDeposits = getCount(
    $pdo,
    "SELECT COUNT(*) FROM deposits WHERE status = 'pending'"
);

$approvedDeposits = getAmount(
    $pdo,
    "SELECT COALESCE(SUM(amount), 0)
     FROM deposits
     WHERE status = 'approved'"
);

// Withdrawals
$totalWithdrawals = getCount(
    $pdo,
    "SELECT COUNT(*) FROM withdrawals"
);

$pendingWithdrawals = getCount(
    $pdo,
    "SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'"
);

$approvedWithdrawals = getAmount(
    $pdo,
    "SELECT COALESCE(SUM(amount), 0)
     FROM withdrawals
     WHERE status = 'approved'"
);

// Commissions
$totalCommissions = getAmount(
    $pdo,
    "SELECT COALESCE(SUM(amount), 0)
     FROM commissions
     WHERE status = 'approved'"
);

$pendingCommissions = getCount(
    $pdo,
    "SELECT COUNT(*) FROM commissions WHERE status = 'pending'"
);

/*
|--------------------------------------------------------------------------
| Recent Users
|--------------------------------------------------------------------------
*/

$recentUsers = getRows(
    $pdo,
    "SELECT id, full_name, username, email, role, status, created_at
     FROM users
     ORDER BY created_at DESC
     LIMIT 6"
);

/*
|--------------------------------------------------------------------------
| Recent Orders
|--------------------------------------------------------------------------
*/

$recentOrders = getRows(
    $pdo,
    "SELECT
        o.id,
        o.order_number,
        o.total_amount,
        o.status,
        o.created_at,
        u.full_name,
        u.username
     FROM orders o
     LEFT JOIN users u ON u.id = o.user_id
     ORDER BY o.created_at DESC
     LIMIT 6"
);

/*
|--------------------------------------------------------------------------
| Initials
|--------------------------------------------------------------------------
*/

$adminInitials = strtoupper(substr((string) $adminName, 0, 1));

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard | Digital Marketplace</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
        rel="stylesheet"
    >

    <style>

        :root {
            --primary: #635bff;
            --primary-dark: #5148e5;
            --sidebar: #171b2e;
            --sidebar-text: #aeb4c8;
            --background: #f5f6fa;
            --card-radius: 16px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--background);
            color: #24283b;
            font-family: 'Inter', sans-serif;
        }

        /* SIDEBAR */

        .sidebar {
            width: 255px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: var(--sidebar);
            color: white;
            padding: 25px 17px;
            display: flex;
            flex-direction: column;
            z-index: 1000;
            overflow-y: auto;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 5px 10px 30px;
            font-size: 19px;
            font-weight: 800;
            color: white;
            text-decoration: none;
        }

        .brand-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--primary);
            font-size: 21px;
        }

        .sidebar-label {
            color: #737b98;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.3px;
            padding: 15px 12px 9px;
            text-transform: uppercase;
        }

        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 14px;
            border-radius: 10px;
            color: var(--sidebar-text);
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 5px;
            transition: .2s;
        }

        .sidebar-link i {
            font-size: 17px;
        }

        .sidebar-link:hover,
        .sidebar-link.active {
            background: rgba(99, 91, 255, .18);
            color: white;
        }

        .sidebar-link.active {
            border-left: 3px solid var(--primary);
        }

        .sidebar-bottom {
            margin-top: auto;
            padding-top: 20px;
        }

        .logout-btn {
            border: 0;
            width: 100%;
            background: rgba(239, 68, 68, .12);
            color: #ff8b8b;
            padding: 12px 14px;
            border-radius: 10px;
            text-align: left;
            font-size: 13px;
            font-weight: 600;
            transition: .2s;
        }

        .logout-btn:hover {
            background: #dc3545;
            color: white;
        }

        /* MAIN */

        .main-content {
            margin-left: 255px;
            padding: 30px;
            min-height: 100vh;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 30px;
        }

        .page-title {
            font-size: 25px;
            font-weight: 800;
            margin: 0;
        }

        .page-subtitle {
            color: #85899b;
            font-size: 13px;
            margin-top: 6px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 11px;
            background: white;
            padding: 9px 15px;
            border-radius: 12px;
            box-shadow: 0 3px 15px rgba(20, 25, 50, .04);
        }

        .avatar {
            width: 39px;
            height: 39px;
            background: #e9e7ff;
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            font-weight: 800;
        }

        .profile-name {
            font-size: 13px;
            font-weight: 700;
        }

        .profile-role {
            font-size: 11px;
            color: #9296a7;
        }

        /* WELCOME */

        .welcome-card {
            background: linear-gradient(115deg, #635bff, #837bff);
            color: white;
            border-radius: var(--card-radius);
            padding: 27px 30px;
            margin-bottom: 25px;
            position: relative;
            overflow: hidden;
        }

        .welcome-card h2 {
            font-size: 22px;
            font-weight: 800;
            margin-bottom: 8px;
        }

        .welcome-card p {
            margin: 0;
            opacity: .85;
            font-size: 13px;
        }

        .welcome-icon {
            position: absolute;
            right: 35px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 75px;
            opacity: .15;
        }

        /* STATISTICS */

        .stat-card {
            background: white;
            border-radius: var(--card-radius);
            padding: 22px;
            height: 100%;
            box-shadow: 0 4px 18px rgba(20, 25, 50, .035);
            border: 1px solid #f0f0f5;
        }

        .stat-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .purple {
            background: #eeedff;
            color: #635bff;
        }

        .green {
            background: #e5f9ef;
            color: #16a36a;
        }

        .orange {
            background: #fff2e3;
            color: #f39a37;
        }

        .blue {
            background: #e7f3ff;
            color: #3288dc;
        }

        .red {
            background: #ffe9e9;
            color: #e34e4e;
        }

        .stat-label {
            font-size: 12px;
            color: #8a8ea0;
            font-weight: 500;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 800;
            margin-top: 5px;
        }

        /* CONTENT CARDS */

        .section-card {
            background: white;
            border-radius: var(--card-radius);
            padding: 22px;
            box-shadow: 0 4px 18px rgba(20, 25, 50, .035);
            border: 1px solid #f0f0f5;
            height: 100%;
        }

        .section-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .section-heading h5 {
            font-size: 15px;
            font-weight: 800;
            margin: 0;
        }

        .view-link {
            color: var(--primary);
            font-size: 12px;
            text-decoration: none;
            font-weight: 600;
        }

        .view-link:hover {
            color: var(--primary-dark);
        }

        /* TABLE */

        .table {
            vertical-align: middle;
            margin-bottom: 0;
        }

        .table thead th {
            color: #9296a7;
            font-size: 11px;
            font-weight: 600;
            border-bottom: 1px solid #eeeef3;
            padding: 12px 9px;
            white-space: nowrap;
        }

        .table tbody td {
            font-size: 12px;
            padding: 14px 9px;
            border-bottom: 1px solid #f1f1f5;
        }

        .table tbody tr:last-child td {
            border-bottom: 0;
        }

        .badge-status {
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 700;
        }

        /* QUICK ACTIONS */

        .quick-action {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 14px;
            border: 1px solid #eeeef3;
            border-radius: 12px;
            text-decoration: none;
            color: #24283b;
            margin-bottom: 10px;
            transition: .2s;
        }

        .quick-action:hover {
            border-color: var(--primary);
            background: #faf9ff;
            transform: translateY(-2px);
        }

        .quick-action-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: #eeedff;
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        .quick-action-title {
            font-size: 12px;
            font-weight: 700;
        }

        .quick-action-description {
            font-size: 10px;
            color: #9296a7;
            margin-top: 3px;
        }

        .empty-state {
            text-align: center;
            padding: 25px 10px;
            color: #9699a8;
            font-size: 12px;
        }

        .empty-state i {
            font-size: 28px;
            display: block;
            margin-bottom: 8px;
            color: #c3c4d0;
        }

        footer {
            text-align: center;
            color: #999dad;
            font-size: 11px;
            padding: 25px 10px 10px;
        }

        .mobile-menu {
            display: none;
            background: white;
            border: 0;
            border-radius: 9px;
            padding: 8px 12px;
            font-size: 20px;
        }

        @media (max-width: 991px) {

            .sidebar {
                transform: translateX(-100%);
                transition: .25s;
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 22px 16px;
            }

            .mobile-menu {
                display: inline-block;
            }

            .welcome-icon {
                font-size: 55px;
                right: 15px;
            }
        }

        @media (max-width: 576px) {

            .topbar {
                align-items: flex-start;
            }

            .page-title {
                font-size: 20px;
            }

            .user-profile {
                padding: 7px;
            }

            .user-profile .profile-details {
                display: none;
            }

            .welcome-card {
                padding: 23px 20px;
            }

            .welcome-card h2 {
                font-size: 19px;
            }

            .stat-value {
                font-size: 21px;
            }
        }

    </style>

</head>

<body>

<!-- =========================================================
     SIDEBAR
========================================================= -->

<aside class="sidebar" id="sidebar">

    <a href="dashboard.php" class="brand">

        <span class="brand-icon">
            <i class="bi bi-shop"></i>
        </span>

        <span>Digital Market</span>

    </a>

    <div class="sidebar-label">Main Menu</div>

    <a href="dashboard.php" class="sidebar-link active">
        <i class="bi bi-grid-1x2"></i>
        Dashboard
    </a>

    <a href="users.php" class="sidebar-link">
        <i class="bi bi-people"></i>
        Manage Users
    </a>

    <a href="product.php" class="sidebar-link">
        <i class="bi bi-box-seam"></i>
        Manage Products
    </a>

    <a href="orders.php" class="sidebar-link">
        <i class="bi bi-cart3"></i>
        Manage Orders
    </a>

    <div class="sidebar-label">Financial Management</div>

    <a href="deposits.php" class="sidebar-link">
        <i class="bi bi-wallet2"></i>
        Deposits

        <?php if ($pendingDeposits > 0): ?>
            <span class="badge bg-danger ms-auto">
                <?= $pendingDeposits ?>
            </span>
        <?php endif; ?>
    </a>

    <a href="withdrawals.php" class="sidebar-link">
        <i class="bi bi-cash-stack"></i>
        Withdrawals

        <?php if ($pendingWithdrawals > 0): ?>
            <span class="badge bg-danger ms-auto">
                <?= $pendingWithdrawals ?>
            </span>
        <?php endif; ?>
    </a>

    <a href="commissions.php" class="sidebar-link">
        <i class="bi bi-graph-up-arrow"></i>
        Commissions
    </a>

    <div class="sidebar-label">System</div>

    <a href="reports.php" class="sidebar-link">
        <i class="bi bi-bar-chart"></i>
        Reports
    </a>

    <a href="settings.php" class="sidebar-link">
        <i class="bi bi-gear"></i>
        Settings
    </a>

    <div class="sidebar-bottom">

        <form method="POST" action="dashboard.php">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($_SESSION['csrf_token']) ?>"
            >

            <button
                type="submit"
                name="logout"
                value="1"
                class="logout-btn"
                onclick="return confirm('Are you sure you want to logout?');"
            >
                <i class="bi bi-box-arrow-right me-2"></i>
                Logout
            </button>

        </form>

    </div>

</aside>

<!-- =========================================================
     MAIN CONTENT
========================================================= -->

<main class="main-content">

    <!-- TOP BAR -->

    <div class="topbar">

        <div class="d-flex align-items-center gap-3">

            <button
                class="mobile-menu"
                type="button"
                onclick="toggleSidebar()"
                aria-label="Toggle menu"
            >
                <i class="bi bi-list"></i>
            </button>

            <div>

                <h1 class="page-title">
                    Admin Dashboard
                </h1>

                <div class="page-subtitle">
                    Manage and monitor your digital marketplace.
                </div>

            </div>

        </div>

        <div class="user-profile">

            <div class="avatar">
                <?= e($adminInitials) ?>
            </div>

            <div class="profile-details">

                <div class="profile-name">
                    <?= e($adminName) ?>
                </div>

                <div class="profile-role">
                    System Administrator
                </div>

            </div>

        </div>

    </div>

    <!-- WELCOME -->

    <section class="welcome-card">

        <h2>
            Welcome back, <?= e($adminName) ?>!
        </h2>

        <p>
            Here's what's happening in your digital marketplace today.
        </p>

        <i class="bi bi-speedometer2 welcome-icon"></i>

    </section>

    <!-- MAIN STATISTICS -->

    <div class="row g-3 mb-4">

        <!-- Users -->

        <div class="col-6 col-xl-3">

            <div class="stat-card">

                <div class="stat-top">

                    <div class="stat-icon purple">
                        <i class="bi bi-people"></i>
                    </div>

                </div>

                <div class="stat-label">
                    Total Users
                </div>

                <div class="stat-value">
                    <?= number_format($totalUsers) ?>
                </div>

            </div>

        </div>

        <!-- Products -->

        <div class="col-6 col-xl-3">

            <div class="stat-card">

                <div class="stat-top">

                    <div class="stat-icon green">
                        <i class="bi bi-box-seam"></i>
                    </div>

                </div>

                <div class="stat-label">
                    Total Products
                </div>

                <div class="stat-value">
                    <?= number_format($totalProducts) ?>
                </div>

            </div>

        </div>

        <!-- Orders -->

        <div class="col-6 col-xl-3">

            <div class="stat-card">

                <div class="stat-top">

                    <div class="stat-icon orange">
                        <i class="bi bi-cart-check"></i>
                    </div>

                </div>

                <div class="stat-label">
                    Total Orders
                </div>

                <div class="stat-value">
                    <?= number_format($totalOrders) ?>
                </div>

            </div>

        </div>

        <!-- Sales -->

        <div class="col-6 col-xl-3">

            <div class="stat-card">

                <div class="stat-top">

                    <div class="stat-icon blue">
                        <i class="bi bi-currency-dollar"></i>
                    </div>

                </div>

                <div class="stat-label">
                    Completed Sales
                </div>

                <div class="stat-value" style="font-size:21px;">
                    <?= money($totalSales) ?>
                </div>

            </div>

        </div>

    </div>

    <!-- FINANCIAL STATISTICS -->

    <div class="row g-3 mb-4">

        <div class="col-6 col-xl-3">

            <div class="stat-card">

                <div class="stat-top">
                    <div class="stat-icon green">
                        <i class="bi bi-wallet"></i>
                    </div>
                </div>

                <div class="stat-label">
                    Approved Deposits
                </div>

                <div class="stat-value" style="font-size:21px;">
                    <?= money($approvedDeposits) ?>
                </div>

            </div>

        </div>

        <div class="col-6 col-xl-3">

            <div class="stat-card">

                <div class="stat-top">
                    <div class="stat-icon orange">
                        <i class="bi bi-clock-history"></i>
                    </div>
                </div>

                <div class="stat-label">
                    Pending Deposits
                </div>

                <div class="stat-value">
                    <?= number_format($pendingDeposits) ?>
                </div>

            </div>

        </div>

        <div class="col-6 col-xl-3">

            <div class="stat-card">

                <div class="stat-top">
                    <div class="stat-icon red">
                        <i class="bi bi-arrow-up-circle"></i>
                    </div>
                </div>

                <div class="stat-label">
                    Pending Withdrawals
                </div>

                <div class="stat-value">
                    <?= number_format($pendingWithdrawals) ?>
                </div>

            </div>

        </div>

        <div class="col-6 col-xl-3">

            <div class="stat-card">

                <div class="stat-top">
                    <div class="stat-icon purple">
                        <i class="bi bi-graph-up-arrow"></i>
                    </div>
                </div>

                <div class="stat-label">
                    Approved Commissions
                </div>

                <div class="stat-value" style="font-size:21px;">
                    <?= money($totalCommissions) ?>
                </div>

            </div>

        </div>

    </div>

    <!-- ORDERS AND QUICK ACTIONS -->

    <div class="row g-3 mb-4">

        <div class="col-lg-8">

            <div class="section-card">

                <div class="section-heading">

                    <h5>Recent Orders</h5>

                    <a href="orders.php" class="view-link">
                        View All
                        <i class="bi bi-arrow-right"></i>
                    </a>

                </div>

                <div class="table-responsive">

                    <table class="table">

                        <thead>

                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>

                        </thead>

                        <tbody>

                        <?php if ($recentOrders): ?>

                            <?php foreach ($recentOrders as $order): ?>

                                <?php
                                $orderStatus = (string) ($order['status'] ?? 'pending');
                                $customer = $order['full_name']
                                    ?? $order['username']
                                    ?? 'Unknown';
                                ?>

                                <tr>

                                    <td class="fw-semibold">
                                        <?= e($order['order_number'] ?? ('#' . $order['id'])) ?>
                                    </td>

                                    <td>
                                        <?= e($customer) ?>
                                    </td>

                                    <td>
                                        <?= money($order['total_amount'] ?? 0) ?>
                                    </td>

                                    <td>

                                        <span class="badge bg-<?= e(statusClass($orderStatus)) ?>-subtle text-<?= e(statusClass($orderStatus)) ?> badge-status">
                                            <?= e(ucfirst($orderStatus)) ?>
                                        </span>

                                    </td>

                                    <td>
                                        <?= e(
                                            !empty($order['created_at'])
                                                ? date('M d, Y', strtotime($order['created_at']))
                                                : '-'
                                        ) ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>

                                <td colspan="5">

                                    <div class="empty-state">
                                        <i class="bi bi-cart-x"></i>
                                        No orders have been placed yet.
                                    </div>

                                </td>

                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

        <!-- QUICK ACTIONS -->

        <div class="col-lg-4">

            <div class="section-card">

                <div class="section-heading">
                    <h5>Quick Actions</h5>
                </div>

                <a href="users.php" class="quick-action">

                    <div class="quick-action-icon">
                        <i class="bi bi-person-plus"></i>
                    </div>

                    <div>
                        <div class="quick-action-title">
                            Manage Users
                        </div>

                        <div class="quick-action-description">
                            View and manage marketplace accounts.
                        </div>
                    </div>

                </a>

                <a href="products.php" class="quick-action">

                    <div class="quick-action-icon">
                        <i class="bi bi-plus-circle"></i>
                    </div>

                    <div>
                        <div class="quick-action-title">
                            Manage Products
                        </div>

                        <div class="quick-action-description">
                            Add and manage digital products.
                        </div>
                    </div>

                </a>

                <a href="deposits.php" class="quick-action">

                    <div class="quick-action-icon">
                        <i class="bi bi-wallet2"></i>
                    </div>

                    <div>
                        <div class="quick-action-title">
                            Review Deposits
                        </div>

                        <div class="quick-action-description">
                            <?= $pendingDeposits ?> pending deposit requests.
                        </div>
                    </div>

                </a>

                <a href="withdrawals.php" class="quick-action">

                    <div class="quick-action-icon">
                        <i class="bi bi-cash-stack"></i>
                    </div>

                    <div>
                        <div class="quick-action-title">
                            Review Withdrawals
                        </div>

                        <div class="quick-action-description">
                            <?= $pendingWithdrawals ?> pending withdrawal requests.
                        </div>
                    </div>

                </a>

            </div>

        </div>

    </div>

    <!-- RECENT USERS -->

    <div class="section-card mb-4">

        <div class="section-heading">

            <h5>Recently Registered Users</h5>

            <a href="users.php" class="view-link">
                Manage Users
                <i class="bi bi-arrow-right"></i>
            </a>

        </div>

        <div class="table-responsive">

            <table class="table">

                <thead>

                    <tr>
                        <th>User</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Registered</th>
                    </tr>

                </thead>

                <tbody>

                <?php if ($recentUsers): ?>

                    <?php foreach ($recentUsers as $user): ?>

                        <?php
                        $userStatus = (string) ($user['status'] ?? 'unknown');
                        $userRole = (string) ($user['role'] ?? 'user');
                        ?>

                        <tr>

                            <td class="fw-semibold">
                                <?= e($user['full_name'] ?? 'Unknown') ?>
                            </td>

                            <td>
                                <?= e($user['username'] ?? '-') ?>
                            </td>

                            <td>
                                <?= e($user['email'] ?? '-') ?>
                            </td>

                            <td>
                                <span class="badge bg-primary-subtle text-primary badge-status">
                                    <?= e(ucfirst($userRole)) ?>
                                </span>
                            </td>

                            <td>
                                <span class="badge bg-<?= e(statusClass($userStatus)) ?>-subtle text-<?= e(statusClass($userStatus)) ?> badge-status">
                                    <?= e(ucfirst($userStatus)) ?>
                                </span>
                            </td>

                            <td>
                                <?= e(
                                    !empty($user['created_at'])
                                        ? date('M d, Y', strtotime($user['created_at']))
                                        : '-'
                                ) ?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="6">
                            <div class="empty-state">
                                <i class="bi bi-people"></i>
                                No registered users found.
                            </div>
                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

    <!-- SUMMARY -->

    <div class="row g-3">

        <div class="col-md-4">

            <div class="section-card">

                <div class="d-flex align-items-center gap-3">

                    <div class="stat-icon green">
                        <i class="bi bi-check-circle"></i>
                    </div>

                    <div>

                        <div class="stat-label">
                            Completed Orders
                        </div>

                        <div class="stat-value">
                            <?= number_format($completedOrders) ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-md-4">

            <div class="section-card">

                <div class="d-flex align-items-center gap-3">

                    <div class="stat-icon orange">
                        <i class="bi bi-hourglass-split"></i>
                    </div>

                    <div>

                        <div class="stat-label">
                            Pending Orders
                        </div>

                        <div class="stat-value">
                            <?= number_format($pendingOrders) ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-md-4">

            <div class="section-card">

                <div class="d-flex align-items-center gap-3">

                    <div class="stat-icon purple">
                        <i class="bi bi-people"></i>
                    </div>

                    <div>

                        <div class="stat-label">
                            Active Users
                        </div>

                        <div class="stat-value">
                            <?= number_format($activeUsers) ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- FOOTER -->

    <footer>
        &copy; <?= date('Y') ?> Digital Marketplace.
        All rights reserved.
    </footer>

</main>

<script>
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('show');
    }
</script>

</body>
</html>
