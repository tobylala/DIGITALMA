
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection failed. Check config/database.php.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/* =====================================================
   ADMIN AUTHENTICATION
===================================================== */

$adminId = (int)($_SESSION['user_id'] ?? 0);

if ($adminId <= 0) {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT id, role, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$adminId]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (
    !$admin ||
    $admin['role'] !== 'admin' ||
    $admin['status'] !== 'active'
) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

/* =====================================================
   HELPERS
===================================================== */

function cm_e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function cm_money($value): string
{
    return number_format((float)$value, 2);
}

function cm_date($date): string
{
    if (!$date) {
        return '-';
    }

    return date('d M Y', strtotime($date));
}

/* =====================================================
   SEARCH AND FILTERS
===================================================== */

$search = trim($_GET['search'] ?? '');
$statusFilter = $_GET['status'] ?? '';

$allowedStatuses = ['active', 'completed', 'paused'];

$where = [];
$params = [];

if (in_array($statusFilter, $allowedStatuses, true)) {
    $where[] = 's.status = ?';
    $params[] = $statusFilter;
}

if ($search !== '') {
    $where[] = "(
        CAST(s.id AS CHAR) LIKE ?
        OR CAST(s.user_id AS CHAR) LIKE ?
        OR CAST(s.order_id AS CHAR) LIKE ?
        OR u.full_name LIKE ?
        OR u.username LIKE ?
        OR u.email LIKE ?
        OR p.product_name LIKE ?
        OR o.order_number LIKE ?
    )";

    $keyword = '%' . $search . '%';

    for ($i = 0; $i < 8; $i++) {
        $params[] = $keyword;
    }
}

$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

/* =====================================================
   STATISTICS
===================================================== */

$stats = $pdo->query("
    SELECT
        COUNT(*) AS total_schedules,

        SUM(CASE
            WHEN status = 'active' THEN 1 ELSE 0
        END) AS active_schedules,

        SUM(CASE
            WHEN status = 'completed' THEN 1 ELSE 0
        END) AS completed_schedules,

        SUM(CASE
            WHEN status = 'paused' THEN 1 ELSE 0
        END) AS paused_schedules,

        COALESCE(SUM(
            purchase_price * daily_rate / 100 * duration_days
        ), 0) AS total_expected_commission

    FROM daily_commission_schedules
")->fetch(PDO::FETCH_ASSOC);

/* =====================================================
   EARNED COMMISSION TOTAL
===================================================== */

$earnedTotal = $pdo->query("
    SELECT COALESCE(SUM(amount), 0)
    FROM daily_commission_logs
")->fetchColumn();

/* =====================================================
   DAILY COMMISSION SCHEDULES
===================================================== */

$sql = "
    SELECT
        s.id AS schedule_id,
        s.user_id,
        s.order_id,
        s.order_item_id,
        s.product_id,
        s.purchase_price,
        s.daily_rate,
        s.duration_days,
        s.start_date,
        s.end_date,
        s.status,
        s.created_at,

        u.full_name,
        u.username,
        u.email,

        p.product_name,
        o.order_number,

        COALESCE(logs.total_earned, 0) AS total_earned,
        COALESCE(logs.paid_days, 0) AS paid_days,
        logs.last_payment_date,

        ROUND(
            s.purchase_price * s.daily_rate / 100,
            2
        ) AS daily_amount,

        ROUND(
            s.purchase_price * s.daily_rate / 100 * s.duration_days,
            2
        ) AS total_commission,

        CASE
            WHEN s.status = 'completed' THEN 0
            WHEN s.end_date < CURDATE() THEN 0
            WHEN s.start_date > CURDATE() THEN s.duration_days
            ELSE DATEDIFF(s.end_date, CURDATE()) + 1
        END AS days_left

    FROM daily_commission_schedules s

    INNER JOIN users u
        ON u.id = s.user_id

    INNER JOIN products p
        ON p.id = s.product_id

    LEFT JOIN orders o
        ON o.id = s.order_id

    LEFT JOIN (
        SELECT
            schedule_id,
            SUM(amount) AS total_earned,
            COUNT(*) AS paid_days,
            MAX(commission_date) AS last_payment_date
        FROM daily_commission_logs
        GROUP BY schedule_id
    ) logs
        ON logs.schedule_id = s.id

    $whereSQL

    ORDER BY
        CASE s.status
            WHEN 'active' THEN 1
            WHEN 'paused' THEN 2
            WHEN 'completed' THEN 3
        END,
        s.created_at DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* =====================================================
   CURRENT DATE
===================================================== */

$today = date('d M Y');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Daily Commissions | DigitalMarket Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        :root {
            --navy: #102747;
            --navy-dark: #0a1b32;
            --gold: #d8aa45;
            --page-bg: #f4f6fa;
        }

        body {
            background: var(--page-bg);
            font-family: Arial, sans-serif;
            color: #263445;
        }

        .sidebar {
            width: 250px;
            min-height: 100vh;
            background: var(--navy-dark);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            padding: 22px 15px;
            z-index: 1000;
        }

        .brand {
            color: white;
            font-size: 21px;
            font-weight: 700;
            padding: 8px 12px 25px;
        }

        .brand span {
            color: var(--gold);
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #dce5f1;
            padding: 12px 14px;
            margin-bottom: 5px;
            border-radius: 7px;
            text-decoration: none;
            font-size: 14px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #1d3b60;
            color: white;
        }

        .sidebar a.active {
            border-left: 3px solid var(--gold);
        }

        .main {
            margin-left: 250px;
            padding: 30px;
        }

        .page-title {
            color: var(--navy);
            font-weight: 700;
        }

        .stat-card,
        .content-card {
            background: white;
            border: 1px solid #e8edf3;
            border-radius: 12px;
        }

        .stat-card {
            padding: 20px;
            height: 100%;
        }

        .stat-label {
            color: #718096;
            font-size: 13px;
        }

        .stat-value {
            color: var(--navy);
            font-size: 23px;
            font-weight: 700;
            margin-top: 7px;
        }

        .stat-icon {
            width: 43px;
            height: 43px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #edf2f8;
            color: var(--navy);
            font-size: 20px;
        }

        .content-card {
            padding: 22px;
        }

        .table th {
            background: #f8fafc;
            color: #617086;
            font-size: 11px;
            text-transform: uppercase;
            white-space: nowrap;
            padding: 13px 12px;
        }

        .table td {
            vertical-align: middle;
            font-size: 13px;
            padding: 13px 12px;
        }

        .status {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: capitalize;
        }

        .status-active {
            background: #d1fae5;
            color: #065f46;
        }

        .status-completed {
            background: #dbeafe;
            color: #1e40af;
        }

        .status-paused {
            background: #fff3cd;
            color: #856404;
        }

        .days-badge {
            display: inline-block;
            background: #edf2f8;
            color: var(--navy);
            padding: 6px 9px;
            border-radius: 7px;
            font-weight: 700;
            white-space: nowrap;
        }

        .btn-navy {
            background: var(--navy);
            color: white;
        }

        .btn-navy:hover {
            background: var(--navy-dark);
            color: white;
        }

        .product-name {
            font-weight: 700;
            color: var(--navy);
        }

        .money {
            white-space: nowrap;
            font-weight: 700;
        }

        @media(max-width: 900px) {
            .sidebar {
                width: 65px;
                padding: 15px 8px;
            }

            .brand {
                font-size: 0;
                padding: 10px 5px 20px;
            }

            .brand:first-letter {
                font-size: 22px;
            }

            .sidebar a {
                justify-content: center;
                font-size: 0;
                padding: 13px 5px;
            }

            .sidebar a i {
                font-size: 19px;
            }

            .main {
                margin-left: 65px;
                padding: 18px;
            }
        }

        @media(max-width: 576px) {
            .main {
                padding: 12px;
            }

            .content-card {
                padding: 12px;
            }
        }
    </style>
</head>

<body>

<aside class="sidebar">

    <div class="brand">
        Digital<span>Market</span>
    </div>

    <a href="dashboard.php">
        <i class="bi bi-speedometer2"></i> Dashboard
    </a>

    <a href="commisions.php" class="active">
        <i class="bi bi-cash-stack"></i> Daily Commissions
    </a>

    <a href="../auth/logout.php">
        <i class="bi bi-box-arrow-right"></i> Logout
    </a>

</aside>

<main class="main">

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">

        <div>
            <h3 class="page-title mb-1">Daily Commission Management</h3>

            <div class="text-secondary small">
                Monitor customers, purchased products, automatic earnings and remaining days.
            </div>
        </div>

        <div class="text-secondary small">
            <i class="bi bi-calendar3 me-1"></i>
            <?= cm_e($today) ?>
        </div>

    </div>

    <!-- SUMMARY CARDS -->

    <div class="row g-3 mb-4">

        <div class="col-xl-3 col-md-6 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-label">Total Schedules</div>
                        <div class="stat-value">
                            <?= (int)$stats['total_schedules'] ?>
                        </div>
                    </div>
                    <div class="stat-icon">
                        <i class="bi bi-people"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-label">Active Schedules</div>
                        <div class="stat-value text-success">
                            <?= (int)$stats['active_schedules'] ?>
                        </div>
                    </div>
                    <div class="stat-icon text-success">
                        <i class="bi bi-play-circle"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-label">Total Expected Commission</div>
                        <div class="stat-value">
                            <?= cm_money($stats['total_expected_commission']) ?>
                        </div>
                        <small class="text-secondary">ETB</small>
                    </div>
                    <div class="stat-icon">
                        <i class="bi bi-wallet2"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between">
                    <div>
                        <div class="stat-label">Total Already Paid</div>
                        <div class="stat-value text-success">
                            <?= cm_money($earnedTotal) ?>
                        </div>
                        <small class="text-secondary">ETB</small>
                    </div>
                    <div class="stat-icon text-success">
                        <i class="bi bi-check-circle"></i>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- ADDITIONAL COUNTS -->

    <div class="row g-3 mb-4">

        <div class="col-md-6">
            <div class="content-card d-flex justify-content-between align-items-center">
                <div>
                    <div class="text-secondary small">Completed Schedules</div>
                    <h5 class="fw-bold mb-0">
                        <?= (int)$stats['completed_schedules'] ?>
                    </h5>
                </div>
                <i class="bi bi-check-circle fs-3 text-primary"></i>
            </div>
        </div>

        <div class="col-md-6">
            <div class="content-card d-flex justify-content-between align-items-center">
                <div>
                    <div class="text-secondary small">Paused Schedules</div>
                    <h5 class="fw-bold mb-0">
                        <?= (int)$stats['paused_schedules'] ?>
                    </h5>
                </div>
                <i class="bi bi-pause-circle fs-3 text-warning"></i>
            </div>
        </div>

    </div>

    <!-- SEARCH AND FILTER -->

    <div class="content-card mb-4">

        <form method="GET" class="row g-3 align-items-end">

            <div class="col-lg-6">
                <label class="form-label small fw-semibold">
                    Search customer or product
                </label>

                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Customer name, username, product, order..."
                    value="<?= cm_e($search) ?>"
                >
            </div>

            <div class="col-lg-3">
                <label class="form-label small fw-semibold">
                    Schedule Status
                </label>

                <select name="status" class="form-select">
                    <option value="">All statuses</option>

                    <?php foreach ($allowedStatuses as $status): ?>
                        <option value="<?= cm_e($status) ?>"
                            <?= $statusFilter === $status ? 'selected' : '' ?>>
                            <?= ucfirst($status) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-lg-3 d-flex gap-2">
                <button class="btn btn-navy flex-grow-1">
                    <i class="bi bi-search"></i> Search
                </button>

                <a href="commisions.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-clockwise"></i>
                </a>
            </div>

        </form>

    </div>

    <!-- DAILY COMMISSION TABLE -->

    <div class="content-card">

        <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">

            <div>
                <h5 class="fw-bold mb-1">Customer Commission Records</h5>
                <div class="text-secondary small">
                    Each row represents one purchased product and its commission schedule.
                </div>
            </div>

            <span class="badge bg-light text-dark">
                <?= count($schedules) ?> record(s)
            </span>

        </div>

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Purchased Product</th>
                        <th>Purchase Price</th>
                        <th>Daily Commission</th>
                        <th>Total Commission</th>
                        <th>Already Earned</th>
                        <th>Days Left</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (!$schedules): ?>

                    <tr>
                        <td colspan="10" class="text-center py-5 text-secondary">
                            <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                            No daily commission schedules found.
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($schedules as $row): ?>

                        <tr>

                            <td>
                                <div class="fw-bold">
                                    <?= cm_e($row['full_name']) ?>
                                </div>

                                <small class="text-secondary">
                                    @<?= cm_e($row['username']) ?>
                                </small>

                                <br>

                                <small class="text-secondary">
                                    User ID: #<?= (int)$row['user_id'] ?>
                                </small>
                            </td>

                            <td>
                                <div class="product-name">
                                    <?= cm_e($row['product_name']) ?>
                                </div>

                                <small class="text-secondary">
                                    Order: <?= cm_e($row['order_number'] ?? '#' . $row['order_id']) ?>
                                </small>
                            </td>

                            <td class="money">
                                <?= cm_money($row['purchase_price']) ?> ETB
                            </td>

                            <td>
                                <div class="fw-bold text-success">
                                    <?= cm_money($row['daily_amount']) ?> ETB
                                </div>

                                <small class="text-secondary">
                                    <?= cm_money($row['daily_rate']) ?>%
                                </small>
                            </td>

                            <td>
                                <div class="fw-bold">
                                    <?= cm_money($row['total_commission']) ?> ETB
                                </div>

                                <small class="text-secondary">
                                    <?= (int)$row['duration_days'] ?> days
                                </small>
                            </td>

                            <td>
                                <div class="fw-bold text-success">
                                    <?= cm_money($row['total_earned']) ?> ETB
                                </div>

                                <small class="text-secondary">
                                    <?= (int)$row['paid_days'] ?> payment(s)
                                </small>
                            </td>

                            <td>
                                <span class="days-badge">
                                    <?= (int)$row['days_left'] ?> days
                                </span>
                            </td>

                            <td>
                                <?= cm_date($row['start_date']) ?>
                            </td>

                            <td>
                                <?= cm_date($row['end_date']) ?>
                            </td>

                            <td>
                                <span class="status status-<?= cm_e($row['status']) ?>">
                                    <?= cm_e($row['status']) ?>
                                </span>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

    <div class="alert alert-info mt-4 small">
        <i class="bi bi-info-circle me-1"></i>
        Daily commissions are credited automatically by the system processor.
        This page is for monitoring only. Total commission represents the
        scheduled amount for the full duration, while already earned represents
        payments recorded in the daily commission ledger.
    </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
