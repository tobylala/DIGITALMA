
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection error.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

/* =========================================================
   ADMIN AUTHENTICATION
========================================================= */

if (empty($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT id, full_name, role, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([(int)$_SESSION['user_id']]);
$admin = $stmt->fetch();

if (!$admin || $admin['role'] !== 'admin' || $admin['status'] !== 'active') {
    session_unset();
    session_destroy();
    header('Location: ../auth/login.php');
    exit;
}

$adminId = (int)$admin['id'];

/* =========================================================
   SECURITY AND HELPERS
========================================================= */

if (empty($_SESSION['orders_csrf'])) {
    $_SESSION['orders_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['orders_csrf'];

function h($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function money($value): string
{
    return number_format((float)$value, 2);
}

function redirectToOrder(int $orderId, string $success): void
{
    header(
        'Location: orders.php?view=' . $orderId .
        '&success=' . urlencode($success)
    );
    exit;
}

/*
 * These values match the existing orders table.
 */
$orderStatuses = [
    'pending',
    'completed',
    'cancelled',
    'refunded'
];

$paymentStatuses = [
    'pending',
    'paid',
    'failed',
    'refunded'
];

$message = '';
$messageType = 'success';

/* =========================================================
   POST ACTIONS
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {
        $token = $_POST['csrf_token'] ?? '';

        if (!is_string($token) || !hash_equals($csrfToken, $token)) {
            throw new RuntimeException('Security verification failed. Refresh and try again.');
        }

        $action = $_POST['action'] ?? '';

        /* ---------------------------------------------
           UPDATE ORDER STATUS
        --------------------------------------------- */

        if ($action === 'update_order') {

            $orderId = filter_var(
                $_POST['order_id'] ?? '',
                FILTER_VALIDATE_INT
            );

            $newStatus = $_POST['status'] ?? '';
            $newPaymentStatus = $_POST['payment_status'] ?? '';

            if (!$orderId || $orderId < 1) {
                throw new RuntimeException('Invalid order ID.');
            }

            if (!in_array($newStatus, $orderStatuses, true)) {
                throw new RuntimeException('Invalid order status.');
            }

            if (!in_array($newPaymentStatus, $paymentStatuses, true)) {
                throw new RuntimeException('Invalid payment status.');
            }

            $stmt = $pdo->prepare("
                SELECT id
                FROM orders
                WHERE id = ?
                LIMIT 1
            ");
            $stmt->execute([$orderId]);

            if (!$stmt->fetch()) {
                throw new RuntimeException('Order not found.');
            }

            if ($newStatus === 'completed' && $newPaymentStatus !== 'paid') {
                throw new RuntimeException(
                    'An order must be paid before it can be completed.'
                );
            }

            if ($newPaymentStatus === 'refunded' && $newStatus === 'completed') {
                throw new RuntimeException(
                    'A refunded order cannot remain completed.'
                );
            }

            if ($newStatus === 'cancelled' && $newPaymentStatus === 'paid') {
                throw new RuntimeException(
                    'A paid order cannot be cancelled directly. Review the refund process first.'
                );
            }

            $stmt = $pdo->prepare("
                UPDATE orders
                SET
                    status = ?,
                    payment_status = ?,
                    completed_at = CASE
                        WHEN ? = 'completed' AND completed_at IS NULL
                            THEN NOW()
                        WHEN ? <> 'completed'
                            THEN NULL
                        ELSE completed_at
                    END
                WHERE id = ?
            ");

            $stmt->execute([
                $newStatus,
                $newPaymentStatus,
                $newStatus,
                $newStatus,
                $orderId
            ]);

            redirectToOrder($orderId, 'order_updated');
        }

        /* ---------------------------------------------
           APPROVE REFERRAL COMMISSION
           
           Approval:
           1. Locks the commission.
           2. Checks that the related order is paid
              and completed.
           3. Locks/creates the referrer's commission wallet.
           4. Credits the wallet once.
           5. Records a wallet transaction.
           6. Marks the commission approved.
        --------------------------------------------- */

        if ($action === 'approve_commission') {

            $commissionId = filter_var(
                $_POST['commission_id'] ?? '',
                FILTER_VALIDATE_INT
            );

            if (!$commissionId || $commissionId < 1) {
                throw new RuntimeException('Invalid commission ID.');
            }

            $pdo->beginTransaction();

            try {

                $stmt = $pdo->prepare("
                    SELECT
                        c.id,
                        c.affiliate_id,
                        c.order_id,
                        c.amount,
                        c.status,
                        o.status AS order_status,
                        o.payment_status
                    FROM commissions c
                    INNER JOIN orders o ON o.id = c.order_id
                    WHERE c.id = ?
                    LIMIT 1
                    FOR UPDATE
                ");

                $stmt->execute([$commissionId]);
                $commission = $stmt->fetch();

                if (!$commission) {
                    throw new RuntimeException('Referral commission not found.');
                }

                if ($commission['status'] !== 'pending') {
                    throw new RuntimeException(
                        'This commission is not pending. It may already have been approved or reversed.'
                    );
                }

                if (
                    $commission['order_status'] !== 'completed' ||
                    $commission['payment_status'] !== 'paid'
                ) {
                    throw new RuntimeException(
                        'Approve the customer order and confirm payment before approving its referral commission.'
                    );
                }

                $affiliateId = (int)$commission['affiliate_id'];
                $amount = round((float)$commission['amount'], 2);
                $orderId = (int)$commission['order_id'];

                if ($affiliateId <= 0 || $amount <= 0) {
                    throw new RuntimeException('Invalid referrer or commission amount.');
                }

                /*
                 * Confirm that the referrer account is active.
                 */
                $stmt = $pdo->prepare("
                    SELECT id, role, status
                    FROM users
                    WHERE id = ?
                    LIMIT 1
                    FOR UPDATE
                ");
                $stmt->execute([$affiliateId]);
                $affiliate = $stmt->fetch();

                if (
                    !$affiliate ||
                    $affiliate['role'] !== 'user' ||
                    $affiliate['status'] !== 'active'
                ) {
                    throw new RuntimeException(
                        'The referrer account is not active. Commission cannot be credited.'
                    );
                }

                /*
                 * Create the commission wallet if it does not exist.
                 */
                $stmt = $pdo->prepare("
                    INSERT IGNORE INTO wallet_accounts
                        (user_id, wallet_type, balance, reserved_balance)
                    VALUES
                        (?, 'commission', 0.00, 0.00)
                ");
                $stmt->execute([$affiliateId]);

                /*
                 * Lock the wallet.
                 */
                $stmt = $pdo->prepare("
                    SELECT id, balance, reserved_balance
                    FROM wallet_accounts
                    WHERE user_id = ?
                      AND wallet_type = 'commission'
                    LIMIT 1
                    FOR UPDATE
                ");
                $stmt->execute([$affiliateId]);
                $wallet = $stmt->fetch();

                if (!$wallet) {
                    throw new RuntimeException('Could not create or access the referrer commission wallet.');
                }

                $walletId = (int)$wallet['id'];

                /*
                 * Unique transaction key prevents duplicate credit.
                 */
                $idempotencyKey = 'commission_credit_' . $commissionId;

                $stmt = $pdo->prepare("
                    SELECT
                        id,
                        wallet_id,
                        transaction_type,
                        amount
                    FROM wallet_transactions
                    WHERE idempotency_key = ?
                    LIMIT 1
                    FOR UPDATE
                ");
                $stmt->execute([$idempotencyKey]);
                $existingTransaction = $stmt->fetch();

                if ($existingTransaction) {

                    /*
                     * If a transaction already exists, verify that
                     * it represents this exact commission credit.
                     */
                    if (
                        (int)$existingTransaction['wallet_id'] !== $walletId ||
                        $existingTransaction['transaction_type'] !== 'credit' ||
                        abs((float)$existingTransaction['amount'] - $amount) > 0.001
                    ) {
                        throw new RuntimeException(
                            'A conflicting wallet transaction already uses this commission reference.'
                        );
                    }

                } else {

                    /*
                     * Credit the referrer's commission wallet.
                     */
                    $stmt = $pdo->prepare("
                        UPDATE wallet_accounts
                        SET balance = balance + ?
                        WHERE id = ?
                    ");
                    $stmt->execute([$amount, $walletId]);

                    /*
                     * Read the updated balance for the ledger.
                     */
                    $stmt = $pdo->prepare("
                        SELECT balance
                        FROM wallet_accounts
                        WHERE id = ?
                        LIMIT 1
                    ");
                    $stmt->execute([$walletId]);
                    $updatedWallet = $stmt->fetch();

                    $balanceAfter = (float)$updatedWallet['balance'];

                    /*
                     * Record the credit in the wallet ledger.
                     */
                    $stmt = $pdo->prepare("
                        INSERT INTO wallet_transactions (
                            wallet_id,
                            transaction_type,
                            amount,
                            balance_after,
                            reference_type,
                            reference_id,
                            idempotency_key,
                            description
                        ) VALUES (
                            ?,
                            'credit',
                            ?,
                            ?,
                            'commission',
                            ?,
                            ?,
                            ?
                        )
                    ");

                    $stmt->execute([
                        $walletId,
                        $amount,
                        $balanceAfter,
                        $commissionId,
                        $idempotencyKey,
                        'Referral commission approved for order #' . $orderId
                    ]);
                }

                /*
                 * Mark commission approved.
                 */
                $stmt = $pdo->prepare("
                    UPDATE commissions
                    SET
                        status = 'approved',
                        approved_by = ?,
                        approved_at = NOW()
                    WHERE id = ?
                      AND status = 'pending'
                ");
                $stmt->execute([$adminId, $commissionId]);

                if ($stmt->rowCount() !== 1) {
                    throw new RuntimeException('Commission status could not be updated.');
                }

                $pdo->commit();

                redirectToOrder($orderId, 'commission_approved');

            } catch (Throwable $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                throw $e;
            }
        }

        throw new RuntimeException('Unknown request.');

    } catch (Throwable $e) {
        $message = $e->getMessage();
        $messageType = 'error';
    }
}

/* =========================================================
   SUCCESS MESSAGES
========================================================= */

if (isset($_GET['success'])) {

    $successMessages = [
        'order_updated' => 'Customer order updated successfully.',
        'commission_approved' => 'Referral commission approved and credited to the referrer wallet.'
    ];

    if (isset($successMessages[$_GET['success']])) {
        $message = $successMessages[$_GET['success']];
        $messageType = 'success';
    }
}

/* =========================================================
   SEARCH AND FILTERS
========================================================= */

$search = trim($_GET['search'] ?? '');
$statusFilter = $_GET['status'] ?? '';
$paymentFilter = $_GET['payment'] ?? '';

$where = [];
$params = [];

if ($search !== '') {

    $where[] = "(
        o.order_number LIKE ?
        OR u.full_name LIKE ?
        OR u.username LIKE ?
        OR p.product_name LIKE ?
    )";

    $term = '%' . $search . '%';

    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

if (in_array($statusFilter, $orderStatuses, true)) {
    $where[] = "o.status = ?";
    $params[] = $statusFilter;
}

if (in_array($paymentFilter, $paymentStatuses, true)) {
    $where[] = "o.payment_status = ?";
    $params[] = $paymentFilter;
}

$sql = "
    SELECT
        o.*,
        u.full_name AS customer_name,
        u.email AS customer_email,
        u.username AS customer_username,
        p.product_name AS product_name,
        (
            SELECT COUNT(*)
            FROM commissions c
            WHERE c.order_id = o.id
              AND c.status = 'pending'
        ) AS pending_commissions,
        (
            SELECT COUNT(*)
            FROM commissions c
            WHERE c.order_id = o.id
              AND c.status = 'approved'
        ) AS approved_commissions
    FROM orders o
    LEFT JOIN users u ON u.id = o.user_id
    LEFT JOIN products p ON p.id = o.product_id
";

if ($where) {
    $sql .= " WHERE " . implode(' AND ', $where);
}

$sql .= " ORDER BY o.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

/* =========================================================
   DASHBOARD STATISTICS
========================================================= */

$stats = $pdo->query("
    SELECT
        COUNT(*) AS total_orders,
        COALESCE(SUM(status = 'pending'), 0) AS pending_orders,
        COALESCE(SUM(status = 'completed'), 0) AS completed_orders,
        COALESCE(SUM(status = 'cancelled'), 0) AS cancelled_orders,
        COALESCE(SUM(payment_status = 'paid'), 0) AS paid_orders,
        COALESCE(
            SUM(
                CASE
                    WHEN payment_status = 'paid'
                    THEN total_amount
                    ELSE 0
                END
            ),
            0
        ) AS total_revenue
    FROM orders
")->fetch();

$commissionStats = $pdo->query("
    SELECT
        COUNT(*) AS total_commissions,
        COALESCE(SUM(status = 'pending'), 0) AS pending_commissions,
        COALESCE(SUM(status = 'approved'), 0) AS approved_commissions,
        COALESCE(
            SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END),
            0
        ) AS pending_amount,
        COALESCE(
            SUM(CASE WHEN status = 'approved' THEN amount ELSE 0 END),
            0
        ) AS approved_amount
    FROM commissions
")->fetch();

/* =========================================================
   VIEW ORDER DETAILS
========================================================= */

$viewOrder = null;
$orderCommissions = [];

if (isset($_GET['view'])) {

    $viewId = filter_var($_GET['view'], FILTER_VALIDATE_INT);

    if ($viewId && $viewId > 0) {

        $stmt = $pdo->prepare("
            SELECT
                o.*,
                u.full_name AS customer_name,
                u.email AS customer_email,
                u.phone AS customer_phone,
                u.username AS customer_username,
                p.product_name AS product_name
            FROM orders o
            LEFT JOIN users u ON u.id = o.user_id
            LEFT JOIN products p ON p.id = o.product_id
            WHERE o.id = ?
            LIMIT 1
        ");

        $stmt->execute([$viewId]);
        $viewOrder = $stmt->fetch();

        if ($viewOrder) {

            $stmt = $pdo->prepare("
                SELECT
                    c.id,
                    c.affiliate_id,
                    c.order_id,
                    c.order_item_id,
                    c.amount,
                    c.status,
                    c.approved_by,
                    c.approved_at,
                    c.created_at,
                    u.full_name AS referrer_name,
                    u.username AS referrer_username,
                    u.email AS referrer_email,
                    admin.full_name AS approved_by_name
                FROM commissions c
                LEFT JOIN users u ON u.id = c.affiliate_id
                LEFT JOIN users admin ON admin.id = c.approved_by
                WHERE c.order_id = ?
                ORDER BY c.id DESC
            ");

            $stmt->execute([$viewId]);
            $orderCommissions = $stmt->fetchAll();
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Order Management | DigitalMarket</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Inter, Arial, sans-serif;
    background: #f3f5f9;
    color: #17243b;
}

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 245px;
    height: 100vh;
    padding: 28px 18px;
    background: #102747;
    color: white;
}

.brand {
    font-size: 22px;
    font-weight: 800;
    margin-bottom: 42px;
    padding-left: 10px;
}

.brand span {
    color: #e5b34c;
}

.nav-label {
    color: #9caec4;
    font-size: 11px;
    text-transform: uppercase;
    margin: 20px 10px 12px;
    letter-spacing: 1.2px;
}

.sidebar a {
    display: block;
    text-decoration: none;
    color: #dce5f1;
    padding: 13px 12px;
    margin-bottom: 5px;
    border-radius: 8px;
    font-size: 14px;
}

.sidebar a:hover,
.sidebar a.active {
    background: #203d62;
    color: white;
}

.sidebar a.active {
    border-left: 3px solid #e5b34c;
}

.main {
    margin-left: 245px;
    padding: 30px;
}

.topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    margin-bottom: 28px;
}

.topbar h1 {
    font-size: 25px;
    margin-bottom: 6px;
}

.topbar p {
    color: #78869b;
    font-size: 13px;
}

.admin-info {
    padding: 11px 16px;
    border: 1px solid #e8edf4;
    border-radius: 9px;
    background: white;
    font-size: 13px;
}

.stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 16px;
    margin-bottom: 22px;
}

.stat-card {
    padding: 20px;
    background: white;
    border: 1px solid #e8edf4;
    border-radius: 12px;
}

.stat-card small {
    color: #77869b;
    font-size: 12px;
}

.stat-card h2 {
    margin-top: 10px;
    font-size: 25px;
}

.stat-card.revenue {
    background: #102747;
    color: white;
}

.stat-card.revenue small {
    color: #d0d9e6;
}

.stat-card.gold {
    background: #fff9e9;
    border-color: #f2dfae;
}

.stat-card.gold h2 {
    color: #946500;
}

.panel {
    padding: 22px;
    background: white;
    border: 1px solid #e8edf4;
    border-radius: 12px;
    margin-bottom: 24px;
}

.panel-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-bottom: 18px;
}

.panel-heading h2 {
    font-size: 17px;
}

.alert {
    padding: 13px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 13px;
}

.alert.success {
    background: #e8f8ef;
    color: #187545;
}

.alert.error {
    background: #fff0f0;
    color: #b52e2e;
}

.filter-row {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 18px;
}

input,
select {
    padding: 10px 12px;
    border: 1px solid #dce3ed;
    border-radius: 7px;
    background: white;
    outline: none;
    font: inherit;
    font-size: 12px;
}

input:focus,
select:focus {
    border-color: #315c91;
}

.filter-row input {
    min-width: 240px;
}

.btn {
    display: inline-block;
    border: none;
    border-radius: 7px;
    padding: 10px 14px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    text-decoration: none;
    text-align: center;
}

.btn-primary {
    background: #102747;
    color: white;
}

.btn-primary:hover {
    background: #203d62;
}

.btn-gold {
    background: #e5b34c;
    color: #17243b;
}

.btn-light {
    background: #eef2f7;
    color: #263b56;
}

.btn-small {
    padding: 7px 10px;
    font-size: 11px;
}

.btn-approve {
    background: #16834b;
    color: white;
}

.btn-approve:hover {
    background: #116b3d;
}

.btn-disabled {
    background: #e8edf2;
    color: #8793a3;
    cursor: not-allowed;
}

.table-wrap {
    overflow-x: auto;
}

table {
    width: 100%;
    min-width: 1000px;
    border-collapse: collapse;
}

th {
    padding: 13px 12px;
    background: #f6f8fb;
    color: #687991;
    font-size: 11px;
    text-transform: uppercase;
    text-align: left;
}

td {
    padding: 13px 12px;
    border-bottom: 1px solid #edf0f5;
    font-size: 12px;
    vertical-align: middle;
}

.order-number {
    font-weight: 700;
    color: #18395e;
}

.customer-name {
    font-weight: 700;
}

.sub-text {
    display: block;
    margin-top: 4px;
    font-size: 11px;
    color: #8491a4;
}

.badge {
    display: inline-block;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 700;
    text-transform: capitalize;
    white-space: nowrap;
}

.badge.pending {
    background: #fff4d9;
    color: #a16a00;
}

.badge.completed,
.badge.paid,
.badge.approved {
    background: #e5f8ed;
    color: #16834b;
}

.badge.cancelled,
.badge.failed,
.badge.reversed {
    background: #fff0f0;
    color: #bd3434;
}

.badge.refunded {
    background: #f0eaff;
    color: #7145a7;
}

.badge.processing {
    background: #e7f0ff;
    color: #285eac;
}

.actions {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}

.empty {
    text-align: center;
    padding: 35px;
    color: #8290a4;
}

.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 15px;
}

.detail-item {
    padding: 14px;
    border: 1px solid #edf0f5;
    border-radius: 8px;
}

.detail-item small {
    display: block;
    margin-bottom: 7px;
    color: #8491a4;
    font-size: 11px;
}

.detail-item strong {
    font-size: 13px;
    overflow-wrap: anywhere;
}

.update-form {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
    margin-top: 20px;
}

.update-form label {
    display: block;
    margin-bottom: 7px;
    font-size: 12px;
    font-weight: 700;
}

.update-form select {
    width: 100%;
}

.update-form button {
    grid-column: 1 / -1;
    justify-self: start;
}

.section-note {
    background: #f5f8fc;
    border: 1px solid #e7edf5;
    border-radius: 8px;
    padding: 13px 15px;
    color: #52647c;
    font-size: 12px;
    line-height: 1.6;
    margin-bottom: 18px;
}

.commission-title {
    font-size: 16px;
    margin-bottom: 15px;
}

@media(max-width: 1050px) {
    .sidebar {
        width: 200px;
    }

    .main {
        margin-left: 200px;
        padding: 20px;
    }

    .stats {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media(max-width: 650px) {
    .sidebar {
        position: static;
        width: 100%;
        height: auto;
    }

    .brand {
        margin-bottom: 15px;
    }

    .main {
        margin-left: 0;
        padding: 15px;
    }

    .stats,
    .detail-grid,
    .update-form {
        grid-template-columns: 1fr;
    }

    .topbar {
        align-items: flex-start;
        flex-direction: column;
    }

    .filter-row input {
        width: 100%;
    }
}
</style>
</head>

<body>

<aside class="sidebar">

    <div class="brand">
        Digital<span>Market</span>
    </div>

    <div class="nav-label">Main menu</div>

    <a href="dashboard.php">Dashboard</a>
    <a href="orders.php" class="active">Manage Orders</a>
    <a href="commisions.php">Manage Commissions</a>
    <a href="../auth/logout.php">Logout</a>

</aside>

<main class="main">

    <div class="topbar">
        <div>
            <h1>Order Management</h1>
            <p>Manage customer orders, confirm payments and approve referral commissions.</p>
        </div>

        <div class="admin-info">
            Administrator:
            <strong><?= h($admin['full_name']) ?></strong>
        </div>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert <?= h($messageType) ?>">
            <?= h($message) ?>
        </div>
    <?php endif; ?>

    <!-- ORDER STATISTICS -->

    <section class="stats">

        <div class="stat-card">
            <small>Total Orders</small>
            <h2><?= (int)$stats['total_orders'] ?></h2>
        </div>

        <div class="stat-card">
            <small>Pending Orders</small>
            <h2><?= (int)$stats['pending_orders'] ?></h2>
        </div>

        <div class="stat-card">
            <small>Completed Orders</small>
            <h2><?= (int)$stats['completed_orders'] ?></h2>
        </div>

        <div class="stat-card">
            <small>Cancelled Orders</small>
            <h2><?= (int)$stats['cancelled_orders'] ?></h2>
        </div>

        <div class="stat-card">
            <small>Paid Orders</small>
            <h2><?= (int)$stats['paid_orders'] ?></h2>
        </div>

        <div class="stat-card revenue">
            <small>Confirmed Revenue</small>
            <h2><?= money($stats['total_revenue']) ?> ETB</h2>
        </div>

        <div class="stat-card gold">
            <small>Pending Referral Commissions</small>
            <h2><?= (int)$commissionStats['pending_commissions'] ?></h2>
            <span class="sub-text">
                <?= money($commissionStats['pending_amount']) ?> ETB awaiting approval
            </span>
        </div>

        <div class="stat-card">
            <small>Approved Referral Commissions</small>
            <h2><?= (int)$commissionStats['approved_commissions'] ?></h2>
            <span class="sub-text">
                <?= money($commissionStats['approved_amount']) ?> ETB credited
            </span>
        </div>

    </section>

    <!-- ORDER DETAILS -->

    <?php if (isset($_GET['view'])): ?>

        <section class="panel">

            <div class="panel-heading">
                <h2>Order Details</h2>

                <a href="orders.php" class="btn btn-light">
                    Back to Orders
                </a>
            </div>

            <?php if (!$viewOrder): ?>

                <p class="empty">Order not found.</p>

            <?php else: ?>

                <div class="detail-grid">

                    <div class="detail-item">
                        <small>Order Number</small>
                        <strong><?= h($viewOrder['order_number']) ?></strong>
                    </div>

                    <div class="detail-item">
                        <small>Order Date</small>
                        <strong>
                            <?= h(date('M d, Y H:i', strtotime($viewOrder['created_at']))) ?>
                        </strong>
                    </div>

                    <div class="detail-item">
                        <small>Customer Name</small>
                        <strong><?= h($viewOrder['customer_name'] ?? 'Unknown customer') ?></strong>
                    </div>

                    <div class="detail-item">
                        <small>Customer Username</small>
                        <strong><?= h($viewOrder['customer_username'] ?? 'Not available') ?></strong>
                    </div>

                    <div class="detail-item">
                        <small>Customer Email</small>
                        <strong><?= h($viewOrder['customer_email'] ?? 'Not available') ?></strong>
                    </div>

                    <div class="detail-item">
                        <small>Customer Phone</small>
                        <strong><?= h($viewOrder['customer_phone'] ?? 'Not available') ?></strong>
                    </div>

                    <div class="detail-item">
                        <small>Product</small>
                        <strong><?= h($viewOrder['product_name'] ?? 'Product unavailable') ?></strong>
                    </div>

                    <div class="detail-item">
                        <small>Quantity</small>
                        <strong><?= (int)$viewOrder['quantity'] ?></strong>
                    </div>

                    <div class="detail-item">
                        <small>Unit Price</small>
                        <strong><?= money($viewOrder['unit_price']) ?> ETB</strong>
                    </div>

                    <div class="detail-item">
                        <small>Total Amount</small>
                        <strong><?= money($viewOrder['total_amount']) ?> ETB</strong>
                    </div>

                    <div class="detail-item">
                        <small>Payment Method</small>
                        <strong><?= h($viewOrder['payment_method'] ?: 'Not specified') ?></strong>
                    </div>

                    <div class="detail-item">
                        <small>Referral Code Used</small>
                        <strong><?= h($viewOrder['referral_code'] ?: 'No referral') ?></strong>
                    </div>

                    <div class="detail-item">
                        <small>Order Status</small>
                        <strong>
                            <span class="badge <?= h($viewOrder['status']) ?>">
                                <?= h($viewOrder['status']) ?>
                            </span>
                        </strong>
                    </div>

                    <div class="detail-item">
                        <small>Payment Status</small>
                        <strong>
                            <span class="badge <?= h($viewOrder['payment_status']) ?>">
                                <?= h($viewOrder['payment_status']) ?>
                            </span>
                        </strong>
                    </div>

                </div>

                <h3 style="margin-top:25px;font-size:16px;">
                    Update Customer Order
                </h3>

                <div class="section-note" style="margin-top:12px;">
                    To approve an order, set its payment status to
                    <strong>Paid</strong> and order status to
                    <strong>Completed</strong>. Referral commissions can only
                    be approved after both conditions are satisfied.
                </div>

                <form method="POST" class="update-form">

                    <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
                    <input type="hidden" name="action" value="update_order">
                    <input type="hidden" name="order_id" value="<?= (int)$viewOrder['id'] ?>">

                    <div>
                        <label>Order Status</label>

                        <select name="status" required>
                            <?php foreach ($orderStatuses as $status): ?>
                                <option value="<?= h($status) ?>"
                                    <?= $viewOrder['status'] === $status ? 'selected' : '' ?>>
                                    <?= ucfirst($status) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label>Payment Status</label>

                        <select name="payment_status" required>
                            <?php foreach ($paymentStatuses as $status): ?>
                                <option value="<?= h($status) ?>"
                                    <?= $viewOrder['payment_status'] === $status ? 'selected' : '' ?>>
                                    <?= ucfirst($status) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        Save Order Updates
                    </button>

                </form>

                <!-- REFERRAL COMMISSIONS -->

                <div style="margin-top:35px;">

                    <h3 class="commission-title">
                        Referral Commission for This Order
                    </h3>

                    <div class="section-note">
                        Referral commission is separate from the daily 5% product
                        commission. Approving a referral commission credits the
                        referrer's commission wallet immediately.
                    </div>

                    <div class="table-wrap">

                        <table style="min-width:850px;">

                            <thead>
                                <tr>
                                    <th>Referrer</th>
                                    <th>Commission Amount</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Approved By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>

                            <?php if (!$orderCommissions): ?>

                                <tr>
                                    <td colspan="6" class="empty">
                                        No referral commission was recorded for this order.
                                    </td>
                                </tr>

                            <?php else: ?>

                                <?php foreach ($orderCommissions as $commission): ?>

                                    <tr>

                                        <td>
                                            <strong><?= h($commission['referrer_name'] ?? 'Unknown referrer') ?></strong>
                                            <span class="sub-text">
                                                @<?= h($commission['referrer_username'] ?? 'unknown') ?>
                                            </span>
                                            <span class="sub-text">
                                                <?= h($commission['referrer_email'] ?? '') ?>
                                            </span>
                                        </td>

                                        <td>
                                            <strong>
                                                <?= money($commission['amount']) ?> ETB
                                            </strong>
                                        </td>

                                        <td>
                                            <span class="badge <?= h($commission['status']) ?>">
                                                <?= h($commission['status']) ?>
                                            </span>
                                        </td>

                                        <td>
                                            <?= h(date('M d, Y', strtotime($commission['created_at']))) ?>
                                        </td>

                                        <td>
                                            <?= h($commission['approved_by_name'] ?? 'Not approved') ?>
                                            <?php if (!empty($commission['approved_at'])): ?>
                                                <span class="sub-text">
                                                    <?= h(date('M d, Y H:i', strtotime($commission['approved_at']))) ?>
                                                </span>
                                            <?php endif; ?>
                                        </td>

                                        <td>

                                            <?php if ($commission['status'] === 'pending'): ?>

                                                <?php if (
                                                    $viewOrder['status'] === 'completed' &&
                                                    $viewOrder['payment_status'] === 'paid'
                                                ): ?>

                                                    <form method="POST"
                                                          onsubmit="return confirm('Approve this referral commission and credit the referrer wallet?');">

                                                        <input type="hidden"
                                                               name="csrf_token"
                                                               value="<?= h($csrfToken) ?>">

                                                        <input type="hidden"
                                                               name="action"
                                                               value="approve_commission">

                                                        <input type="hidden"
                                                               name="commission_id"
                                                               value="<?= (int)$commission['id'] ?>">

                                                        <button type="submit"
                                                                class="btn btn-approve btn-small">
                                                            Approve & Credit
                                                        </button>

                                                    </form>

                                                <?php else: ?>

                                                    <span class="btn btn-disabled btn-small">
                                                        Complete Order First
                                                    </span>

                                                <?php endif; ?>

                                            <?php elseif ($commission['status'] === 'approved'): ?>

                                                <span class="badge approved">
                                                    Wallet Credited
                                                </span>

                                            <?php else: ?>

                                                <span class="badge reversed">
                                                    Reversed
                                                </span>

                                            <?php endif; ?>

                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            <?php endif; ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            <?php endif; ?>

        </section>

    <?php endif; ?>

    <!-- ALL ORDERS -->

    <section class="panel">

        <div class="panel-heading">
            <h2>All Customer Orders</h2>

            <span class="sub-text">
                <?= count($orders) ?> order(s) found
            </span>
        </div>

        <form method="GET" class="filter-row">

            <input type="text"
                   name="search"
                   value="<?= h($search) ?>"
                   placeholder="Search order, customer or product...">

            <select name="status">
                <option value="">All Order Statuses</option>

                <?php foreach ($orderStatuses as $status): ?>
                    <option value="<?= h($status) ?>"
                        <?= $statusFilter === $status ? 'selected' : '' ?>>
                        <?= ucfirst($status) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select name="payment">
                <option value="">All Payment Statuses</option>

                <?php foreach ($paymentStatuses as $status): ?>
                    <option value="<?= h($status) ?>"
                        <?= $paymentFilter === $status ? 'selected' : '' ?>>
                        <?= ucfirst($status) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="btn btn-primary">
                Filter
            </button>

            <a href="orders.php" class="btn btn-light">
                Reset
            </a>

        </form>

        <div class="table-wrap">

            <table>

                <thead>
                    <tr>
                        <th>Order</th>
                        <th>Customer</th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Payment</th>
                        <th>Order Status</th>
                        <th>Referral Commission</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (!$orders): ?>

                    <tr>
                        <td colspan="10" class="empty">
                            No orders found.
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($orders as $order): ?>

                        <tr>

                            <td>
                                <span class="order-number">
                                    <?= h($order['order_number']) ?>
                                </span>
                            </td>

                            <td>
                                <span class="customer-name">
                                    <?= h($order['customer_name'] ?? 'Unknown customer') ?>
                                </span>

                                <span class="sub-text">
                                    <?= h($order['customer_email'] ?? '') ?>
                                </span>
                            </td>

                            <td>
                                <?= h($order['product_name'] ?? 'Product unavailable') ?>
                            </td>

                            <td><?= (int)$order['quantity'] ?></td>

                            <td>
                                <strong><?= money($order['total_amount']) ?> ETB</strong>
                            </td>

                            <td>
                                <span class="badge <?= h($order['payment_status']) ?>">
                                    <?= h($order['payment_status']) ?>
                                </span>
                            </td>

                            <td>
                                <span class="badge <?= h($order['status']) ?>">
                                    <?= h($order['status']) ?>
                                </span>
                            </td>

                            <td>

                                <?php if ((int)$order['pending_commissions'] > 0): ?>

                                    <span class="badge pending">
                                        <?= (int)$order['pending_commissions'] ?> Pending
                                    </span>

                                <?php elseif ((int)$order['approved_commissions'] > 0): ?>

                                    <span class="badge approved">
                                        <?= (int)$order['approved_commissions'] ?> Approved
                                    </span>

                                <?php else: ?>

                                    <span class="sub-text">
                                        No referral commission
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>
                                <?= h(date('M d, Y', strtotime($order['created_at']))) ?>
                            </td>

                            <td>
                                <div class="actions">
                                    <a href="orders.php?view=<?= (int)$order['id'] ?>"
                                       class="btn btn-small btn-primary">
                                        View / Manage
                                    </a>
                                </div>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

</main>

</body>
</html>
