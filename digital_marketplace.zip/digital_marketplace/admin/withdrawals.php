
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection is not available.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/*
|--------------------------------------------------------------------------
| ADMIN AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if (($_SESSION['user_role'] ?? '') !== 'admin') {
    http_response_code(403);
    die('Access denied.');
}

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];

if (!isset($_SESSION['withdrawal_flash'])) {
    $_SESSION['withdrawal_flash'] = null;
}

/*
|--------------------------------------------------------------------------
| HELPER FUNCTIONS
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function flashMessage(string $type, string $message): void
{
    $_SESSION['withdrawal_flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function redirectBack(): void
{
    header('Location: withdrawals.php');
    exit;
}

function getWalletLedger(
    PDO $pdo,
    int $walletId,
    int $withdrawalId,
    string $transactionType
): bool {
    $stmt = $pdo->prepare("
        SELECT id
        FROM wallet_transactions
        WHERE wallet_id = ?
          AND reference_type = 'withdrawal'
          AND reference_id = ?
          AND transaction_type = ?
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->execute([
        $walletId,
        $withdrawalId,
        $transactionType
    ]);

    return (bool)$stmt->fetchColumn();
}

function addWalletTransaction(
    PDO $pdo,
    int $walletId,
    string $type,
    float $amount,
    float $balanceAfter,
    int $withdrawalId,
    string $idempotencyKey,
    string $description
): void {
    $stmt = $pdo->prepare("
        INSERT INTO wallet_transactions (
            wallet_id,
            transaction_type,
            amount,
            balance_after,
            reference_type,
            reference_id,
            idempotency_key,
            description,
            created_at
        ) VALUES (?, ?, ?, ?, 'withdrawal', ?, ?, ?, NOW())
    ");

    $stmt->execute([
        $walletId,
        $type,
        number_format($amount, 2, '.', ''),
        number_format($balanceAfter, 2, '.', ''),
        $withdrawalId,
        $idempotencyKey,
        $description
    ]);
}

/*
|--------------------------------------------------------------------------
| GET WITHDRAWAL WALLET ALLOCATIONS
|--------------------------------------------------------------------------
| Supports combined-wallet withdrawals and older single-wallet records.
*/

function getWithdrawalAllocations(
    PDO $pdo,
    array $withdrawal
): array {
    $withdrawalId = (int)$withdrawal['id'];
    $userId = (int)$withdrawal['user_id'];

    $stmt = $pdo->prepare("
        SELECT
            id,
            wallet_id,
            wallet_type,
            amount
        FROM withdrawal_wallet_allocations
        WHERE withdrawal_id = ?
        ORDER BY id ASC
        FOR UPDATE
    ");

    $stmt->execute([$withdrawalId]);
    $allocations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($allocations)) {
        return $allocations;
    }

    // Legacy withdrawal: use withdrawals.wallet_type.
    $walletType = $withdrawal['wallet_type'] ?? 'commission';

    if (!in_array($walletType, ['purchase', 'commission'], true)) {
        throw new RuntimeException(
            'The withdrawal wallet type is invalid.'
        );
    }

    $stmt = $pdo->prepare("
        SELECT id
        FROM wallet_accounts
        WHERE user_id = ?
          AND wallet_type = ?
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->execute([$userId, $walletType]);
    $walletId = (int)$stmt->fetchColumn();

    if ($walletId <= 0) {
        throw new RuntimeException(
            'The wallet associated with this withdrawal was not found.'
        );
    }

    return [[
        'wallet_id' => $walletId,
        'wallet_type' => $walletType,
        'amount' => $withdrawal['amount']
    ]];
}

/*
|--------------------------------------------------------------------------
| ENSURE ALLOCATION TABLE EXISTS
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS withdrawal_wallet_allocations (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        withdrawal_id INT UNSIGNED NOT NULL,
        wallet_id INT UNSIGNED NOT NULL,
        wallet_type ENUM('purchase','commission') NOT NULL,
        amount DECIMAL(15,2) NOT NULL,
        created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_withdrawal_wallet (withdrawal_id, wallet_id),
        INDEX idx_withdrawal_id (withdrawal_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

/*
|--------------------------------------------------------------------------
| PROCESS ADMIN ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedToken = $_POST['csrf_token'] ?? '';

    if (!hash_equals($csrfToken, $postedToken)) {
        flashMessage('danger', 'Invalid security token. Please try again.');
        redirectBack();
    }

    $withdrawalId = (int)($_POST['withdrawal_id'] ?? 0);
    $action = trim($_POST['action'] ?? '');
    $adminNote = trim($_POST['admin_note'] ?? '');
    $paymentReference = trim($_POST['payment_reference'] ?? '');
    $adminId = (int)$_SESSION['user_id'];

    if ($withdrawalId <= 0) {
        flashMessage('danger', 'Invalid withdrawal request.');
        redirectBack();
    }

    try {
        $pdo->beginTransaction();

        /*
        |--------------------------------------------------------------------------
        | LOCK WITHDRAWAL
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT *
            FROM withdrawals
            WHERE id = ?
            LIMIT 1
            FOR UPDATE
        ");

        $stmt->execute([$withdrawalId]);
        $withdrawal = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$withdrawal) {
            throw new RuntimeException('Withdrawal request not found.');
        }

        $currentStatus = $withdrawal['status'];

        /*
        |--------------------------------------------------------------------------
        | APPROVE
        |--------------------------------------------------------------------------
        | Pending or rejected requests can be approved.
        | No wallet movement occurs.
        */

        if ($action === 'approve') {

            if (!in_array($currentStatus, ['pending', 'rejected'], true)) {
                throw new RuntimeException(
                    'Only pending or rejected withdrawals can be approved.'
                );
            }

            $stmt = $pdo->prepare("
                UPDATE withdrawals
                SET status = 'approved',
                    admin_note = ?,
                    reviewed_by = ?,
                    reviewed_at = NOW()
                WHERE id = ?
            ");

            $stmt->execute([
                $adminNote,
                $adminId,
                $withdrawalId
            ]);

            $successMessage = 'Withdrawal approved successfully. Money remains reserved.';
        }

        /*
        |--------------------------------------------------------------------------
        | REJECT
        |--------------------------------------------------------------------------
        | IMPORTANT:
        | Rejecting does NOT release or credit money.
        | Money remains reserved for further checking.
        */

        elseif ($action === 'reject') {

            if (!in_array($currentStatus, ['pending', 'approved'], true)) {
                throw new RuntimeException(
                    'Only pending or approved withdrawals can be rejected.'
                );
            }

            $stmt = $pdo->prepare("
                UPDATE withdrawals
                SET status = 'rejected',
                    admin_note = ?,
                    reviewed_by = ?,
                    reviewed_at = NOW()
                WHERE id = ?
            ");

            $stmt->execute([
                $adminNote,
                $adminId,
                $withdrawalId
            ]);

            $successMessage =
                'Withdrawal rejected for further checking. Money remains reserved in the user wallet.';
        }

        /*
        |--------------------------------------------------------------------------
        | REFUND UNPAID WITHDRAWAL
        |--------------------------------------------------------------------------
        | Releases reserved money back to the available wallet.
        | Does not refund a withdrawal already marked as paid.
        */

        elseif ($action === 'refund') {

            if (!in_array(
                $currentStatus,
                ['pending', 'approved', 'rejected'],
                true
            )) {
                throw new RuntimeException(
                    'Only unpaid withdrawals can be refunded.'
                );
            }

            $allocations = getWithdrawalAllocations($pdo, $withdrawal);

            foreach ($allocations as $allocation) {

                $walletId = (int)$allocation['wallet_id'];
                $walletType = $allocation['wallet_type'];
                $amount = round((float)$allocation['amount'], 2);

                if ($amount <= 0) {
                    throw new RuntimeException(
                        'Invalid wallet allocation amount.'
                    );
                }

                // Lock wallet.
                $stmt = $pdo->prepare("
                    SELECT id, balance, reserved_balance
                    FROM wallet_accounts
                    WHERE id = ?
                    FOR UPDATE
                ");

                $stmt->execute([$walletId]);
                $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$wallet) {
                    throw new RuntimeException(
                        'A wallet associated with this withdrawal was not found.'
                    );
                }

                $hasReserve = getWalletLedger(
                    $pdo,
                    $walletId,
                    $withdrawalId,
                    'reserve'
                );

                $hasRelease = getWalletLedger(
                    $pdo,
                    $walletId,
                    $withdrawalId,
                    'release'
                );

                $hasDebit = getWalletLedger(
                    $pdo,
                    $withdrawalId,
                    $withdrawalId,
                    'debit'
                );

                $hasCredit = getWalletLedger(
                    $pdo,
                    $walletId,
                    $withdrawalId,
                    'credit'
                );

                /*
                 * Normal combined-wallet withdrawal:
                 * release the reserved amount.
                 */

                if ($hasReserve && !$hasRelease && !$hasDebit) {

                    $reservedBalance = (float)$wallet['reserved_balance'];

                    if ($reservedBalance < $amount) {
                        throw new RuntimeException(
                            'The reserved balance is insufficient to refund this withdrawal.'
                        );
                    }

                    $newReserved = round(
                        $reservedBalance - $amount,
                        2
                    );

                    $stmt = $pdo->prepare("
                        UPDATE wallet_accounts
                        SET reserved_balance = ?,
                            updated_at = NOW()
                        WHERE id = ?
                    ");

                    $stmt->execute([
                        $newReserved,
                        $walletId
                    ]);

                    addWalletTransaction(
                        $pdo,
                        $walletId,
                        'release',
                        $amount,
                        (float)$wallet['balance'],
                        $withdrawalId,
                        'withdrawal_release_' . $withdrawalId . '_' . $walletType,
                        'Unpaid withdrawal refunded - reserved amount released'
                    );
                }

                /*
                 * Legacy case:
                 * money was debited before payment, but withdrawal
                 * has not been paid. Credit it back once.
                 */

                elseif ($hasDebit && !$hasCredit) {

                    $newBalance = round(
                        (float)$wallet['balance'] + $amount,
                        2
                    );

                    $stmt = $pdo->prepare("
                        UPDATE wallet_accounts
                        SET balance = ?,
                            updated_at = NOW()
                        WHERE id = ?
                    ");

                    $stmt->execute([
                        $newBalance,
                        $walletId
                    ]);

                    addWalletTransaction(
                        $pdo,
                        $walletId,
                        'credit',
                        $amount,
                        $newBalance,
                        $withdrawalId,
                        'withdrawal_refund_' . $withdrawalId . '_' . $walletType,
                        'Unpaid withdrawal refunded to wallet'
                    );
                }

                elseif ($hasRelease || $hasCredit) {
                    throw new RuntimeException(
                        'This wallet allocation has already been refunded.'
                    );
                }

                else {
                    throw new RuntimeException(
                        'No reservation or previous withdrawal debit was found. The system cannot safely refund this amount.'
                    );
                }
            }

            $stmt = $pdo->prepare("
                UPDATE withdrawals
                SET status = 'refunded',
                    admin_note = ?,
                    reviewed_by = ?,
                    reviewed_at = NOW()
                WHERE id = ?
            ");

            $stmt->execute([
                $adminNote,
                $adminId,
                $withdrawalId
            ]);

            $successMessage =
                'Unpaid withdrawal refunded successfully. The reserved money has been returned to the user wallet.';
        }

        /*
        |--------------------------------------------------------------------------
        | MARK AS PAID
        |--------------------------------------------------------------------------
        | Only approved requests can be paid.
        | Deducts money from each allocated wallet.
        */

        elseif ($action === 'pay') {

            if ($currentStatus !== 'approved') {
                throw new RuntimeException(
                    'Only approved withdrawals can be marked as paid.'
                );
            }

            if ($paymentReference === '') {
                throw new RuntimeException(
                    'Enter the payment transaction reference before marking as paid.'
                );
            }

            $allocations = getWithdrawalAllocations($pdo, $withdrawal);

            foreach ($allocations as $allocation) {

                $walletId = (int)$allocation['wallet_id'];
                $walletType = $allocation['wallet_type'];
                $amount = round((float)$allocation['amount'], 2);

                if ($amount <= 0) {
                    throw new RuntimeException(
                        'Invalid wallet allocation amount.'
                    );
                }

                $stmt = $pdo->prepare("
                    SELECT id, balance, reserved_balance
                    FROM wallet_accounts
                    WHERE id = ?
                    FOR UPDATE
                ");

                $stmt->execute([$walletId]);
                $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$wallet) {
                    throw new RuntimeException(
                        'A wallet associated with this withdrawal was not found.'
                    );
                }

                $hasReserve = getWalletLedger(
                    $pdo,
                    $walletId,
                    $withdrawalId,
                    'reserve'
                );

                $hasDebit = getWalletLedger(
                    $pdo,
                    $walletId,
                    $withdrawalId,
                    'debit'
                );

                $hasRelease = getWalletLedger(
                    $pdo,
                    $walletId,
                    $withdrawalId,
                    'release'
                );

                if ($hasDebit) {
                    throw new RuntimeException(
                        'This withdrawal allocation has already been debited.'
                    );
                }

                if ($hasRelease) {
                    throw new RuntimeException(
                        'This withdrawal allocation was already refunded and cannot be paid.'
                    );
                }

                $balance = (float)$wallet['balance'];
                $reserved = (float)$wallet['reserved_balance'];

                if ($hasReserve) {

                    if ($reserved < $amount || $balance < $amount) {
                        throw new RuntimeException(
                            'Insufficient reserved wallet balance to complete payment.'
                        );
                    }

                    $newBalance = round($balance - $amount, 2);
                    $newReserved = round($reserved - $amount, 2);

                    $stmt = $pdo->prepare("
                        UPDATE wallet_accounts
                        SET balance = ?,
                            reserved_balance = ?,
                            updated_at = NOW()
                        WHERE id = ?
                    ");

                    $stmt->execute([
                        $newBalance,
                        $newReserved,
                        $walletId
                    ]);
                } else {

                    // Legacy request without a reserve ledger.
                    $available = $balance - $reserved;

                    if ($available < $amount) {
                        throw new RuntimeException(
                            'Insufficient available wallet balance to complete payment.'
                        );
                    }

                    $newBalance = round($balance - $amount, 2);

                    $stmt = $pdo->prepare("
                        UPDATE wallet_accounts
                        SET balance = ?,
                            updated_at = NOW()
                        WHERE id = ?
                    ");

                    $stmt->execute([
                        $newBalance,
                        $walletId
                    ]);
                }

                addWalletTransaction(
                    $pdo,
                    $walletId,
                    'debit',
                    $amount,
                    $newBalance,
                    $withdrawalId,
                    'withdrawal_paid_' . $withdrawalId . '_' . $walletType,
                    'Withdrawal paid - ' . $paymentReference
                );
            }

            $stmt = $pdo->prepare("
                UPDATE withdrawals
                SET status = 'paid',
                    payment_reference = ?,
                    paid_at = NOW(),
                    admin_note = ?,
                    reviewed_by = ?,
                    reviewed_at = NOW()
                WHERE id = ?
            ");

            $stmt->execute([
                $paymentReference,
                $adminNote,
                $adminId,
                $withdrawalId
            ]);

            $successMessage =
                'Withdrawal marked as paid successfully. Wallet balances have been updated.';
        }

        else {
            throw new RuntimeException('Invalid withdrawal action.');
        }

        $pdo->commit();

        flashMessage('success', $successMessage);

    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        flashMessage('danger', $e->getMessage());
    }

    redirectBack();
}

/*
|--------------------------------------------------------------------------
| FLASH MESSAGE
|--------------------------------------------------------------------------
*/

$flash = $_SESSION['withdrawal_flash'];
unset($_SESSION['withdrawal_flash']);

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$search = trim($_GET['search'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');

$allowedStatuses = [
    'pending',
    'approved',
    'rejected',
    'paid',
    'refunded'
];

if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}

/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

$stats = [
    'pending' => 0,
    'approved' => 0,
    'rejected' => 0,
    'paid' => 0,
    'refunded' => 0
];

$stmt = $pdo->query("
    SELECT status, COUNT(*) AS total
    FROM withdrawals
    GROUP BY status
");

foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    if (isset($stats[$row['status']])) {
        $stats[$row['status']] = (int)$row['total'];
    }
}

$totalPendingAmount = (float)$pdo->query("
    SELECT COALESCE(SUM(amount), 0)
    FROM withdrawals
    WHERE status = 'pending'
")->fetchColumn();

$totalApprovedAmount = (float)$pdo->query("
    SELECT COALESCE(SUM(amount), 0)
    FROM withdrawals
    WHERE status = 'approved'
")->fetchColumn();

/*
|--------------------------------------------------------------------------
| WITHDRAWAL LIST
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        w.*,
        u.full_name,
        u.username,
        u.email,
        u.phone,
        pm.method_name
    FROM withdrawals w
    LEFT JOIN users u ON u.id = w.user_id
    LEFT JOIN payment_methods pm ON pm.id = w.payment_method_id
    WHERE 1 = 1
";

$params = [];

if ($statusFilter !== '') {
    $sql .= " AND w.status = ?";
    $params[] = $statusFilter;
}

if ($search !== '') {
    $sql .= "
        AND (
            u.full_name LIKE ?
            OR u.username LIKE ?
            OR u.email LIKE ?
            OR u.phone LIKE ?
            OR w.payment_reference LIKE ?
            OR w.account_details LIKE ?
            OR CAST(w.id AS CHAR) LIKE ?
        )
    ";

    $term = '%' . $search . '%';

    for ($i = 0; $i < 7; $i++) {
        $params[] = $term;
    }
}

$sql .= " ORDER BY w.created_at DESC, w.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$withdrawals = $stmt->fetchAll(PDO::FETCH_ASSOC);

function statusClass(string $status): string
{
    return match ($status) {
        'pending' => 'status-pending',
        'approved' => 'status-approved',
        'rejected' => 'status-rejected',
        'paid' => 'status-paid',
        'refunded' => 'status-refunded',
        default => 'status-default'
    };
}

function formatMoney($amount): string
{
    return number_format((float)$amount, 2) . ' ETB';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdrawal Management | Digital Marketplace</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        :root {
            --navy: #102747;
            --navy-dark: #0a1b32;
            --gold: #d8aa45;
            --bg: #f4f6fa;
            --text: #243247;
            --muted: #7b8798;
            --border: #e8edf3;
        }

        * {
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: Arial, Helvetica, sans-serif;
        }

        .main-content {
            padding: 30px;
            max-width: 1600px;
            margin: auto;
        }

        .page-heading {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .page-heading h2 {
            color: var(--navy);
            font-size: 25px;
            font-weight: 800;
            margin: 0;
        }

        .page-heading p {
            color: var(--muted);
            margin: 6px 0 0;
            font-size: 14px;
        }

        .stat-card {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 15px;
            padding: 20px;
            height: 100%;
            box-shadow: 0 4px 16px rgba(16, 39, 71, .035);
        }

        .stat-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .stat-icon {
            width: 43px;
            height: 43px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .icon-pending {
            background: #fff4db;
            color: #b7791f;
        }

        .icon-approved {
            background: #e5f0ff;
            color: #2563eb;
        }

        .icon-rejected {
            background: #ffe9e9;
            color: #dc3545;
        }

        .icon-paid {
            background: #e2f7ec;
            color: #198754;
        }

        .icon-refunded {
            background: #eee9ff;
            color: #6f42c1;
        }

        .stat-label {
            color: var(--muted);
            font-size: 13px;
            margin-top: 15px;
        }

        .stat-value {
            font-size: 25px;
            font-weight: 800;
            color: var(--navy);
            margin-top: 3px;
        }

        .stat-sub {
            font-size: 12px;
            color: var(--muted);
            margin-top: 5px;
        }

        .content-card {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 16px rgba(16, 39, 71, .035);
        }

        .card-header-custom {
            padding: 20px 22px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            flex-wrap: wrap;
        }

        .card-header-custom h5 {
            margin: 0;
            color: var(--navy);
            font-size: 17px;
            font-weight: 800;
        }

        .filter-form {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .filter-form .form-control,
        .filter-form .form-select {
            min-width: 160px;
            border-color: var(--border);
            font-size: 13px;
            padding: 10px 12px;
        }

        .btn-navy {
            background: var(--navy);
            border-color: var(--navy);
            color: #fff;
        }

        .btn-navy:hover {
            background: var(--navy-dark);
            border-color: var(--navy-dark);
            color: #fff;
        }

        .table {
            margin: 0;
            vertical-align: middle;
        }

        .table thead th {
            background: #f8f9fc;
            color: #69778b;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: .5px;
            padding: 15px 14px;
            border-bottom: 1px solid var(--border);
            white-space: nowrap;
        }

        .table tbody td {
            padding: 16px 14px;
            border-color: #edf0f5;
            font-size: 13px;
        }

        .customer-name {
            font-weight: 700;
            color: var(--navy);
        }

        .customer-sub {
            font-size: 11px;
            color: var(--muted);
            margin-top: 4px;
        }

        .amount {
            font-weight: 800;
            color: var(--navy);
            white-space: nowrap;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 10px;
            border-radius: 30px;
            font-size: 11px;
            font-weight: 700;
            text-transform: capitalize;
        }

        .status-pending {
            background: #fff4db;
            color: #9a6700;
        }

        .status-approved {
            background: #e5f0ff;
            color: #1754a5;
        }

        .status-rejected {
            background: #ffe9e9;
            color: #b42318;
        }

        .status-paid {
            background: #e2f7ec;
            color: #137547;
        }

        .status-refunded {
            background: #eee9ff;
            color: #6741a5;
        }

        .status-default {
            background: #edf0f5;
            color: #555;
        }

        .btn-view {
            background: #eef2f8;
            color: var(--navy);
            border: 0;
            border-radius: 8px;
            padding: 7px 11px;
            font-size: 12px;
            font-weight: 700;
        }

        .btn-view:hover {
            background: var(--navy);
            color: #fff;
        }

        .empty-state {
            text-align: center;
            padding: 55px 20px;
            color: var(--muted);
        }

        .empty-state i {
            font-size: 40px;
            color: #c3ccda;
        }

        .empty-state h5 {
            margin-top: 12px;
            color: var(--navy);
            font-weight: 700;
        }

        .modal-content {
            border: 0;
            border-radius: 16px;
            overflow: hidden;
        }

        .modal-header {
            background: var(--navy);
            color: #fff;
            padding: 19px 22px;
        }

        .modal-header .btn-close {
            filter: invert(1);
        }

        .detail-label {
            font-size: 11px;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: .4px;
            margin-bottom: 5px;
        }

        .detail-value {
            color: var(--navy);
            font-size: 14px;
            font-weight: 700;
            overflow-wrap: anywhere;
        }

        .detail-box {
            background: #f8f9fc;
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 13px;
            height: 100%;
        }

        .action-form {
            border-top: 1px solid var(--border);
            padding-top: 18px;
            margin-top: 18px;
        }

        .action-form textarea,
        .action-form input {
            font-size: 13px;
        }

        .workflow-note {
            background: #f4f6fa;
            border-radius: 10px;
            padding: 13px;
            color: #59677a;
            font-size: 12px;
            line-height: 1.6;
        }

        @media(max-width: 768px) {
            .main-content {
                padding: 18px 12px;
            }

            .stat-value {
                font-size: 21px;
            }

            .card-header-custom {
                align-items: stretch;
            }

            .filter-form {
                width: 100%;
            }

            .filter-form .form-control,
            .filter-form .form-select {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<div class="main-content">

    <div class="page-heading">
        <div>
            <h2><i class="bi bi-wallet2 me-2"></i>Withdrawal Management</h2>
            <p>Review, approve, reject, refund and process customer withdrawals.</p>
        </div>

        <a href="dashboard.php" class="btn btn-navy">
            <i class="bi bi-arrow-left me-1"></i> Dashboard
        </a>
    </div>

    <?php if ($flash): ?>
        <div class="alert alert-<?= h($flash['type']) ?> alert-dismissible fade show" role="alert">
            <?= h($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- STATISTICS -->

    <div class="row g-3 mb-4">

        <div class="col-6 col-lg">
            <div class="stat-card">
                <div class="stat-top">
                    <span class="stat-label mt-0">Pending</span>
                    <div class="stat-icon icon-pending">
                        <i class="bi bi-clock-history"></i>
                    </div>
                </div>
                <div class="stat-value"><?= number_format($stats['pending']) ?></div>
                <div class="stat-sub">Awaiting review</div>
            </div>
        </div>

        <div class="col-6 col-lg">
            <div class="stat-card">
                <div class="stat-top">
                    <span class="stat-label mt-0">Approved</span>
                    <div class="stat-icon icon-approved">
                        <i class="bi bi-check2-circle"></i>
                    </div>
                </div>
                <div class="stat-value"><?= number_format($stats['approved']) ?></div>
                <div class="stat-sub"><?= formatMoney($totalApprovedAmount) ?></div>
            </div>
        </div>

        <div class="col-6 col-lg">
            <div class="stat-card">
                <div class="stat-top">
                    <span class="stat-label mt-0">Rejected</span>
                    <div class="stat-icon icon-rejected">
                        <i class="bi bi-exclamation-circle"></i>
                    </div>
                </div>
                <div class="stat-value"><?= number_format($stats['rejected']) ?></div>
                <div class="stat-sub">For further checking</div>
            </div>
        </div>

        <div class="col-6 col-lg">
            <div class="stat-card">
                <div class="stat-top">
                    <span class="stat-label mt-0">Paid</span>
                    <div class="stat-icon icon-paid">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                </div>
                <div class="stat-value"><?= number_format($stats['paid']) ?></div>
                <div class="stat-sub">Payment completed</div>
            </div>
        </div>

        <div class="col-6 col-lg">
            <div class="stat-card">
                <div class="stat-top">
                    <span class="stat-label mt-0">Refunded</span>
                    <div class="stat-icon icon-refunded">
                        <i class="bi bi-arrow-counterclockwise"></i>
                    </div>
                </div>
                <div class="stat-value"><?= number_format($stats['refunded']) ?></div>
                <div class="stat-sub">Money returned to wallets</div>
            </div>
        </div>

    </div>

    <!-- WITHDRAWAL TABLE -->

    <div class="content-card">

        <div class="card-header-custom">
            <h5><i class="bi bi-list-ul me-2"></i>Withdrawal Requests</h5>

            <form method="GET" class="filter-form">

                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Search customer or ID..."
                    value="<?= h($search) ?>"
                >

                <select name="status" class="form-select">
                    <option value="">All statuses</option>
                    <?php foreach ($allowedStatuses as $status): ?>
                        <option
                            value="<?= h($status) ?>"
                            <?= $statusFilter === $status ? 'selected' : '' ?>
                        >
                            <?= ucfirst($status) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <button type="submit" class="btn btn-navy">
                    <i class="bi bi-search me-1"></i> Search
                </button>

                <a href="withdrawals.php" class="btn btn-outline-secondary">
                    Reset
                </a>

            </form>
        </div>

        <div class="table-responsive">

            <table class="table">
                <thead>
                    <tr>
                        <th>Request</th>
                        <th>Customer</th>
                        <th>Amount</th>
                        <th>Wallet</th>
                        <th>Payment Method</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (!$withdrawals): ?>

                    <tr>
                        <td colspan="8">
                            <div class="empty-state">
                                <i class="bi bi-inbox"></i>
                                <h5>No withdrawal requests found</h5>
                                <p class="mb-0">Try changing your search or status filter.</p>
                            </div>
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($withdrawals as $w): ?>

                        <tr>
                            <td>
                                <strong>#WD-<?= (int)$w['id'] ?></strong>
                                <div class="customer-sub">
                                    User ID: <?= (int)$w['user_id'] ?>
                                </div>
                            </td>

                            <td>
                                <div class="customer-name">
                                    <?= h($w['full_name'] ?: $w['username'] ?: 'Unknown User') ?>
                                </div>
                                <div class="customer-sub">
                                    <?= h($w['email'] ?? '') ?>
                                </div>
                            </td>

                            <td>
                                <div class="amount">
                                    <?= formatMoney($w['amount']) ?>
                                </div>
                            </td>

                            <td>
                                <span class="text-capitalize">
                                    <?= h($w['wallet_type'] ?? 'N/A') ?>
                                </span>
                            </td>

                            <td>
                                <?= h($w['method_name'] ?? 'Not specified') ?>
                            </td>

                            <td>
                                <span class="status-badge <?= statusClass($w['status']) ?>">
                                    <?= h($w['status']) ?>
                                </span>
                            </td>

                            <td>
                                <?= !empty($w['created_at'])
                                    ? date('M d, Y', strtotime($w['created_at']))
                                    : 'N/A' ?>
                                <div class="customer-sub">
                                    <?= !empty($w['created_at'])
                                        ? date('h:i A', strtotime($w['created_at']))
                                        : '' ?>
                                </div>
                            </td>

                            <td>
                                <button
                                    type="button"
                                    class="btn-view"
                                    data-bs-toggle="modal"
                                    data-bs-target="#withdrawalModal"
                                    data-id="<?= (int)$w['id'] ?>"
                                    data-user="<?= h($w['full_name'] ?: $w['username'] ?: 'Unknown User') ?>"
                                    data-email="<?= h($w['email'] ?? '') ?>"
                                    data-phone="<?= h($w['phone'] ?? '') ?>"
                                    data-amount="<?= h($w['amount']) ?>"
                                    data-wallet="<?= h($w['wallet_type'] ?? '') ?>"
                                    data-method="<?= h($w['method_name'] ?? '') ?>"
                                    data-account="<?= h($w['account_details'] ?? '') ?>"
                                    data-status="<?= h($w['status']) ?>"
                                    data-reference="<?= h($w['payment_reference'] ?? '') ?>"
                                    data-note="<?= h($w['admin_note'] ?? '') ?>"
                                    data-date="<?= h($w['created_at'] ?? '') ?>"
                                >
                                    <i class="bi bi-eye me-1"></i> Details
                                </button>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>
            </table>

        </div>
    </div>

    <div class="workflow-note mt-3">
        <strong>Withdrawal workflow:</strong>
        Rejecting a request keeps the money reserved for further review.
        Refunding an unpaid request releases the reserved amount back to the user's available wallet.
        Approving does not move money. Paying deducts the amount from the allocated wallet or wallets.
    </div>

</div>

<!-- WITHDRAWAL DETAILS MODAL -->

<div class="modal fade" id="withdrawalModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <div>
                    <h5 class="modal-title fw-bold mb-1">
                        Withdrawal Details
                    </h5>
                    <small id="modalRequestId" class="opacity-75"></small>
                </div>

                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body p-4">

                <div class="row g-3">

                    <div class="col-md-6">
                        <div class="detail-box">
                            <div class="detail-label">Customer</div>
                            <div class="detail-value" id="modalUser"></div>
                            <div class="small text-muted mt-1" id="modalEmail"></div>
                            <div class="small text-muted" id="modalPhone"></div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="detail-box">
                            <div class="detail-label">Withdrawal Amount</div>
                            <div class="detail-value fs-5" id="modalAmount"></div>
                            <div class="small text-muted mt-1">
                                Wallet: <span id="modalWallet"></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="detail-box">
                            <div class="detail-label">Payment Method</div>
                            <div class="detail-value" id="modalMethod"></div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="detail-box">
                            <div class="detail-label">Current Status</div>
                            <div id="modalStatus"></div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="detail-box">
                            <div class="detail-label">Withdrawal Account Details</div>
                            <div class="detail-value" id="modalAccount"></div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="detail-box">
                            <div class="detail-label">Payment Reference</div>
                            <div class="detail-value" id="modalReference"></div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="detail-box">
                            <div class="detail-label">Request Date</div>
                            <div class="detail-value" id="modalDate"></div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="detail-box">
                            <div class="detail-label">Previous Admin Note</div>
                            <div class="detail-value" id="modalNote"></div>
                        </div>
                    </div>

                </div>

                <div class="action-form" id="actionArea">

                    <form method="POST" id="withdrawalActionForm">

                        <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
                        <input type="hidden" name="withdrawal_id" id="formWithdrawalId">

                        <div class="mb-3" id="paymentReferenceArea" style="display:none;">
                            <label class="form-label fw-bold">
                                Payment Transaction Reference
                            </label>

                            <input
                                type="text"
                                name="payment_reference"
                                id="paymentReference"
                                class="form-control"
                                placeholder="Enter bank or Telebirr transaction reference"
                            >
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">
                                Admin Note
                            </label>

                            <textarea
                                name="admin_note"
                                class="form-control"
                                rows="2"
                                placeholder="Enter review note or reason..."
                            ></textarea>
                        </div>

                        <div class="d-flex gap-2 flex-wrap" id="actionButtons"></div>

                    </form>

                    <div class="workflow-note mt-3" id="modalWorkflowNote"></div>

                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
const withdrawalModal = document.getElementById('withdrawalModal');

withdrawalModal.addEventListener('show.bs.modal', function (event) {

    const button = event.relatedTarget;

    const id = button.dataset.id;
    const status = button.dataset.status;

    document.getElementById('modalRequestId').textContent =
        'Request #WD-' + id;

    document.getElementById('modalUser').textContent =
        button.dataset.user || 'Unknown';

    document.getElementById('modalEmail').textContent =
        button.dataset.email || 'No email';

    document.getElementById('modalPhone').textContent =
        button.dataset.phone || 'No phone';

    document.getElementById('modalAmount').textContent =
        Number(button.dataset.amount || 0).toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }) + ' ETB';

    document.getElementById('modalWallet').textContent =
        button.dataset.wallet || 'N/A';

    document.getElementById('modalMethod').textContent =
        button.dataset.method || 'Not specified';

    document.getElementById('modalAccount').textContent =
        button.dataset.account || 'No account details';

    document.getElementById('modalReference').textContent =
        button.dataset.reference || 'Not paid';

    document.getElementById('modalDate').textContent =
        button.dataset.date || 'N/A';

    document.getElementById('modalNote').textContent =
        button.dataset.note || 'No previous note';

    document.getElementById('modalStatus').innerHTML =
        '<span class="status-badge status-' + status + '">' +
        status.charAt(0).toUpperCase() + status.slice(1) +
        '</span>';

    document.getElementById('formWithdrawalId').value = id;

    const buttons = document.getElementById('actionButtons');
    const referenceArea = document.getElementById('paymentReferenceArea');
    const referenceInput = document.getElementById('paymentReference');
    const workflowNote = document.getElementById('modalWorkflowNote');

    buttons.innerHTML = '';
    referenceArea.style.display = 'none';
    referenceInput.required = false;

    function addButton(action, label, color, icon, confirmation) {
        const buttonElement = document.createElement('button');

        buttonElement.type = 'submit';
        buttonElement.name = 'action';
        buttonElement.value = action;
        buttonElement.className = 'btn btn-' + color;
        buttonElement.innerHTML = '<i class="bi ' + icon + ' me-1"></i>' + label;

        if (confirmation) {
            buttonElement.addEventListener('click', function(e) {
                if (!confirm(confirmation)) {
                    e.preventDefault();
                }
            });
        }

        buttons.appendChild(buttonElement);
    }

    if (status === 'pending') {

        addButton(
            'approve',
            'Approve',
            'success',
            'bi-check-circle',
            'Approve this withdrawal request?'
        );

        addButton(
            'reject',
            'Reject for Review',
            'warning',
            'bi-exclamation-circle',
            'Reject this request for further checking? The money will remain reserved.'
        );

        addButton(
            'refund',
            'Refund',
            'outline-primary',
            'bi-arrow-counterclockwise',
            'Refund this unpaid withdrawal? The reserved money will return to the user available wallet.'
        );

        workflowNote.textContent =
            'Pending: Approve the request, reject it for further checking without releasing money, or refund it to release the reserved amount.';

    } else if (status === 'approved') {

        addButton(
            'pay',
            'Mark as Paid',
            'success',
            'bi-cash-coin',
            'Confirm that you have actually sent this payment?'
        );

        referenceArea.style.display = 'block';
        referenceInput.required = true;

        addButton(
            'reject',
            'Reject for Review',
            'warning',
            'bi-exclamation-circle',
            'Reject this request for further checking? Money will remain reserved.'
        );

        addButton(
            'refund',
            'Refund',
            'outline-primary',
            'bi-arrow-counterclockwise',
            'Refund this unpaid withdrawal and release the reserved money?'
        );

        workflowNote.textContent =
            'Approved: You can complete payment, return the request for further checking without releasing funds, or refund the unpaid amount.';

    } else if (status === 'rejected') {

        addButton(
            'approve',
            'Approve Again',
            'success',
            'bi-check-circle',
            'Approve this previously rejected request again?'
        );

        addButton(
            'refund',
            'Refund',
            'outline-primary',
            'bi-arrow-counterclockwise',
            'Refund this unpaid withdrawal and release the reserved money?'
        );

        workflowNote.textContent =
            'Rejected: The money remains reserved. You can approve the request again after checking it, or refund the unpaid amount.';

    } else if (status === 'paid') {

        workflowNote.textContent =
            'Paid: Payment has been completed. No refund or further wallet action is available from this page.';

    } else if (status === 'refunded') {

        workflowNote.textContent =
            'Refunded: The reserved money has already been returned to the user available wallet. No further action is available.';
    }
});
</script>

</body>
</html>
