
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

date_default_timezone_set('Africa/Addis_Ababa');

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../user/dashboard.php');
    exit;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection failed.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function flash($type, $message): void
{
    $_SESSION['setting_flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function redirectTo($url): void
{
    header('Location: ' . $url);
    exit;
}

/*
|--------------------------------------------------------------------------
| PAGE URL
|--------------------------------------------------------------------------
*/

$pageUrl = basename($_SERVER['PHP_SELF']);

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['settings_csrf'])) {
    $_SESSION['settings_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['settings_csrf'];

/*
|--------------------------------------------------------------------------
| CREATE SETTINGS TABLE
|--------------------------------------------------------------------------
*/

try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS app_settings (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            setting_key VARCHAR(100) NOT NULL,
            setting_value TEXT DEFAULT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_setting_key (setting_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
} catch (PDOException $exception) {
    error_log('Settings table error: ' . $exception->getMessage());
    die('Unable to initialize website settings.');
}

/*
|--------------------------------------------------------------------------
| DEFAULT SETTINGS
|--------------------------------------------------------------------------
*/

$defaults = [
    'site_name' => 'Digital Marketplace',
    'site_email' => '',
    'site_phone' => '',
    'currency' => 'ETB',
    'min_withdrawal' => '300'
];

foreach ($defaults as $key => $value) {
    $stmt = $pdo->prepare("
        INSERT IGNORE INTO app_settings (setting_key, setting_value)
        VALUES (?, ?)
    ");
    $stmt->execute([$key, $value]);
}

/*
|--------------------------------------------------------------------------
| HANDLE FORM SUBMISSIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $submittedToken = $_POST['csrf_token'] ?? '';

    if (!hash_equals($csrfToken, $submittedToken)) {
        flash('danger', 'Invalid security token. Please try again.');
        redirectTo($pageUrl);
    }

    $action = $_POST['action'] ?? '';

    /*
    |--------------------------------------------------------------------------
    | SAVE WEBSITE SETTINGS
    |--------------------------------------------------------------------------
    */

    if ($action === 'save_settings') {

        $siteName = trim($_POST['site_name'] ?? '');
        $siteEmail = trim($_POST['site_email'] ?? '');
        $sitePhone = trim($_POST['site_phone'] ?? '');
        $currency = trim($_POST['currency'] ?? '');
        $minimumWithdrawal = trim($_POST['min_withdrawal'] ?? '');

        if ($siteName === '') {
            flash('danger', 'Website name is required.');
            redirectTo($pageUrl . '#general-settings');
        }

        if ($siteEmail !== '' && !filter_var($siteEmail, FILTER_VALIDATE_EMAIL)) {
            flash('danger', 'Please enter a valid website email address.');
            redirectTo($pageUrl . '#general-settings');
        }

        if (!in_array($currency, ['ETB', 'USD', 'EUR', 'GBP'], true)) {
            flash('danger', 'Please select a valid currency.');
            redirectTo($pageUrl . '#general-settings');
        }

        if (!is_numeric($minimumWithdrawal) || (float)$minimumWithdrawal < 300) {
            flash('danger', 'Minimum withdrawal must be at least 300.');
            redirectTo($pageUrl . '#general-settings');
        }

        try {
            $settingsToSave = [
                'site_name' => $siteName,
                'site_email' => $siteEmail,
                'site_phone' => $sitePhone,
                'currency' => $currency,
                'min_withdrawal' => number_format((float)$minimumWithdrawal, 2, '.', '')
            ];

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                INSERT INTO app_settings (setting_key, setting_value)
                VALUES (?, ?)
                ON DUPLICATE KEY UPDATE
                    setting_value = VALUES(setting_value)
            ");

            foreach ($settingsToSave as $key => $value) {
                $stmt->execute([$key, $value]);
            }

            $pdo->commit();

            flash('success', 'Website settings updated successfully.');
            redirectTo($pageUrl . '#general-settings');

        } catch (Throwable $exception) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('Save settings error: ' . $exception->getMessage());

            flash('danger', 'Unable to save website settings.');
            redirectTo($pageUrl . '#general-settings');
        }
    }

    /*
    |--------------------------------------------------------------------------
    | RESET USER PASSWORD
    |--------------------------------------------------------------------------
    */

    if ($action === 'reset_password') {

        $targetUserId = (int)($_POST['target_user_id'] ?? 0);
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if ($targetUserId <= 0) {
            flash('danger', 'Please select a valid user.');
            redirectTo($pageUrl . '#password-reset');
        }

        if (strlen($newPassword) < 8) {
            flash('danger', 'Password must contain at least 8 characters.');
            redirectTo($pageUrl . '?selected_user=' . $targetUserId . '#password-reset');
        }

        if ($newPassword !== $confirmPassword) {
            flash('danger', 'The passwords do not match.');
            redirectTo($pageUrl . '?selected_user=' . $targetUserId . '#password-reset');
        }

        try {
            $stmt = $pdo->prepare("
                SELECT id, full_name, username, email, role, status
                FROM users
                WHERE id = ?
                LIMIT 1
            ");

            $stmt->execute([$targetUserId]);
            $targetUser = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$targetUser) {
                flash('danger', 'User account was not found.');
                redirectTo($pageUrl . '#password-reset');
            }

            $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("
                UPDATE users
                SET password = ?
                WHERE id = ?
                LIMIT 1
            ");

            $stmt->execute([$passwordHash, $targetUserId]);

            flash(
                'success',
                'Password successfully reset for ' .
                $targetUser['full_name'] .
                ' (@' . $targetUser['username'] . ').'
            );

            redirectTo($pageUrl . '#password-reset');

        } catch (Throwable $exception) {

            error_log('Password reset error: ' . $exception->getMessage());

            flash('danger', 'Unable to reset the user password.');
            redirectTo($pageUrl . '#password-reset');
        }
    }
}

/*
|--------------------------------------------------------------------------
| LOAD SETTINGS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT setting_key, setting_value
    FROM app_settings
");

$settings = $defaults;

foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

/*
|--------------------------------------------------------------------------
| SEARCH USERS
|--------------------------------------------------------------------------
*/

$search = trim($_GET['q'] ?? '');
$selectedUserId = (int)($_GET['selected_user'] ?? 0);

$searchResults = [];
$selectedUser = null;

if ($search !== '' && strlen($search) <= 100) {

    $stmt = $pdo->prepare("
        SELECT id, full_name, username, email, phone, role, status
        FROM users
        WHERE full_name LIKE ?
           OR username LIKE ?
           OR email LIKE ?
           OR phone LIKE ?
        ORDER BY id DESC
        LIMIT 30
    ");

    $searchTerm = '%' . $search . '%';

    $stmt->execute([
        $searchTerm,
        $searchTerm,
        $searchTerm,
        $searchTerm
    ]);

    $searchResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

if ($selectedUserId > 0) {

    $stmt = $pdo->prepare("
        SELECT id, full_name, username, email, phone, role, status
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$selectedUserId]);
    $selectedUser = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

/*
|--------------------------------------------------------------------------
| FLASH MESSAGE
|--------------------------------------------------------------------------
*/

$flashMessage = $_SESSION['setting_flash'] ?? null;
unset($_SESSION['setting_flash']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>System Settings | Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --navy: #102747;
            --navy-dark: #0a1b32;
            --gold: #d8aa45;
            --background: #f4f6fa;
            --text: #202b3c;
            --muted: #7b8494;
            --border: #e9edf3;
        }

        * {
            box-sizing: border-box;
        }

        body {
            background: var(--background);
            color: var(--text);
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            margin: 0;
        }

        .main-content {
            max-width: 1250px;
            padding: 32px 25px;
            margin: auto;
        }

        .top-navigation {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 14px 18px;
            margin-bottom: 27px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            box-shadow: 0 3px 14px rgba(16,39,71,.035);
        }

        .top-navigation .brand {
            color: var(--navy);
            font-weight: 800;
            font-size: 14px;
        }

        .top-navigation .brand i {
            color: var(--gold);
            margin-right: 8px;
        }

        .nav-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page-header {
            margin-bottom: 26px;
        }

        .page-header h2 {
            font-size: 25px;
            font-weight: 800;
            color: var(--navy);
            margin-bottom: 7px;
        }

        .page-header p {
            color: var(--muted);
            margin: 0;
        }

        .settings-card {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 14px;
            margin-bottom: 24px;
            overflow: hidden;
            box-shadow: 0 3px 14px rgba(16,39,71,.035);
        }

        .card-header-custom {
            padding: 20px 23px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 13px;
        }

        .header-icon {
            width: 43px;
            height: 43px;
            background: #edf2f8;
            color: var(--navy);
            border-radius: 11px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .card-header-custom h5 {
            font-size: 15px;
            font-weight: 800;
            color: var(--navy);
            margin: 0 0 4px;
        }

        .card-header-custom p {
            color: var(--muted);
            font-size: 12px;
            margin: 0;
        }

        .card-body-custom {
            padding: 24px;
        }

        .form-label {
            font-size: 12px;
            font-weight: 700;
            color: #39465a;
            margin-bottom: 8px;
        }

        .form-control,
        .form-select {
            border: 1px solid #e2e7ef;
            min-height: 44px;
            border-radius: 9px;
            font-size: 13px;
            box-shadow: none !important;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--gold);
        }

        .btn-main {
            background: var(--navy);
            color: #fff;
            border: 0;
            border-radius: 8px;
            padding: 11px 18px;
            font-weight: 700;
            font-size: 12px;
        }

        .btn-main:hover {
            background: var(--navy-dark);
            color: #fff;
        }

        .btn-gold {
            background: var(--gold);
            color: var(--navy-dark);
            border: 0;
            border-radius: 8px;
            padding: 11px 18px;
            font-weight: 800;
            font-size: 12px;
        }

        .btn-gold:hover {
            background: #c99b37;
            color: var(--navy-dark);
        }

        .user-result {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            padding: 15px;
            border: 1px solid var(--border);
            border-radius: 10px;
            margin-bottom: 10px;
        }

        .user-avatar {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #edf2f8;
            color: var(--navy);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 17px;
            flex-shrink: 0;
        }

        .user-info strong {
            display: block;
            font-size: 13px;
            color: var(--navy);
        }

        .user-info small {
            color: var(--muted);
            font-size: 11px;
        }

        .selected-user {
            background: #f6f8fc;
            border: 1px solid #e5eaf2;
            border-radius: 11px;
            padding: 17px;
            margin-bottom: 22px;
        }

        .security-note {
            background: #fff8e8;
            border: 1px solid #f4e4bd;
            color: #76571c;
            border-radius: 10px;
            padding: 14px;
            font-size: 12px;
            line-height: 1.6;
        }

        .section-label {
            color: var(--navy);
            font-size: 13px;
            font-weight: 800;
            margin-bottom: 18px;
        }

        .empty-state {
            text-align: center;
            color: var(--muted);
            padding: 30px 15px;
        }

        .empty-state i {
            display: block;
            font-size: 32px;
            margin-bottom: 10px;
        }

        @media(max-width: 600px) {
            .main-content {
                padding: 22px 13px;
            }

            .card-body-custom {
                padding: 17px;
            }

            .user-result {
                align-items: flex-start;
            }

            .page-header h2 {
                font-size: 21px;
            }

            .top-navigation {
                padding: 12px;
            }

            .top-navigation .brand {
                font-size: 12px;
            }

            .nav-actions .btn {
                padding: 9px 11px;
                font-size: 11px;
            }
        }
    </style>
</head>

<body>

<div class="main-content">

    <!-- TOP NAVIGATION -->

    <div class="top-navigation">

        <div class="brand">
            <i class="bi bi-shop"></i>
            DIGITAL MARKETPLACE
        </div>

        <div class="nav-actions">

            <a href="dashboard.php" class="btn btn-main">
                <i class="bi bi-house-door-fill me-1"></i>
                Home
            </a>

            <a
                href="../auth/logout.php"
                class="btn btn-outline-danger"
                onclick="return confirm('Are you sure you want to log out?');"
            >
                <i class="bi bi-box-arrow-right me-1"></i>
                Logout
            </a>

        </div>

    </div>

    <div class="page-header">
        <h2><i class="bi bi-gear-fill me-2"></i>System Settings</h2>
        <p>Manage your marketplace configuration and user account security.</p>
    </div>

    <?php if ($flashMessage): ?>
        <div class="alert alert-<?= e($flashMessage['type']) ?> alert-dismissible fade show" role="alert">
            <?= e($flashMessage['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- GENERAL SETTINGS -->

    <div class="settings-card" id="general-settings">

        <div class="card-header-custom">
            <div class="header-icon">
                <i class="bi bi-sliders"></i>
            </div>

            <div>
                <h5>General Website Settings</h5>
                <p>Configure your Digital Marketplace information.</p>
            </div>
        </div>

        <div class="card-body-custom">

            <form method="POST" action="<?= e($pageUrl) ?>">

                <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                <input type="hidden" name="action" value="save_settings">

                <div class="row g-3">

                    <div class="col-md-6">
                        <label class="form-label">Website Name</label>
                        <input
                            type="text"
                            name="site_name"
                            class="form-control"
                            value="<?= e($settings['site_name']) ?>"
                            required
                        >
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Website Email</label>
                        <input
                            type="email"
                            name="site_email"
                            class="form-control"
                            value="<?= e($settings['site_email']) ?>"
                            placeholder="support@example.com"
                        >
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Contact Phone</label>
                        <input
                            type="text"
                            name="site_phone"
                            class="form-control"
                            value="<?= e($settings['site_phone']) ?>"
                            placeholder="+251..."
                        >
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Currency</label>
                        <select name="currency" class="form-select" required>
                            <option value="ETB" <?= $settings['currency'] === 'ETB' ? 'selected' : '' ?>>ETB - Ethiopian Birr</option>
                            <option value="USD" <?= $settings['currency'] === 'USD' ? 'selected' : '' ?>>USD - US Dollar</option>
                            <option value="EUR" <?= $settings['currency'] === 'EUR' ? 'selected' : '' ?>>EUR - Euro</option>
                            <option value="GBP" <?= $settings['currency'] === 'GBP' ? 'selected' : '' ?>>GBP - British Pound</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Minimum Withdrawal Amount</label>
                        <div class="input-group">
                            <span class="input-group-text">ETB</span>
                            <input
                                type="number"
                                name="min_withdrawal"
                                class="form-control"
                                min="300"
                                step="0.01"
                                value="<?= e($settings['min_withdrawal']) ?>"
                                required
                            >
                        </div>
                        <small class="text-muted">Minimum allowed amount is 300 ETB.</small>
                    </div>

                </div>

                <div class="mt-4">
                    <button type="submit" class="btn-main">
                        <i class="bi bi-check-circle me-1"></i>
                        Save Settings
                    </button>
                </div>

            </form>

        </div>
    </div>

    <!-- USER PASSWORD RESET -->

    <div class="settings-card" id="password-reset">

        <div class="card-header-custom">
            <div class="header-icon">
                <i class="bi bi-shield-lock"></i>
            </div>

            <div>
                <h5>User Password Recovery</h5>
                <p>Find a registered account and securely reset its password.</p>
            </div>
        </div>

        <div class="card-body-custom">

            <div class="security-note mb-4">
                <i class="bi bi-info-circle-fill me-1"></i>
                Use this feature when a user has forgotten their password. The new password
                is securely hashed before being saved. Never share passwords with other people.
            </div>

            <div class="section-label">
                <i class="bi bi-search me-1"></i>
                Find User Account
            </div>

            <!-- SEARCH FORM -->

            <form method="GET" action="<?= e($pageUrl) ?>#password-reset">

                <div class="row g-2">

                    <div class="col-md-9">
                        <input
                            type="text"
                            name="q"
                            class="form-control"
                            value="<?= e($search) ?>"
                            placeholder="Search by full name, username, email, or phone..."
                            maxlength="100"
                            required
                        >
                    </div>

                    <div class="col-md-3">
                        <button type="submit" class="btn-main w-100">
                            <i class="bi bi-search me-1"></i>
                            Search Users
                        </button>
                    </div>

                </div>

            </form>

            <?php if ($search !== ''): ?>

                <div class="mt-4">

                    <div class="section-label">
                        Search Results
                        <span class="text-muted fw-normal">(<?= count($searchResults) ?> found)</span>
                    </div>

                    <?php if (empty($searchResults)): ?>

                        <div class="empty-state">
                            <i class="bi bi-person-x"></i>
                            No user accounts found matching your search.
                        </div>

                    <?php else: ?>

                        <?php foreach ($searchResults as $result): ?>

                            <div class="user-result">

                                <div class="d-flex align-items-center gap-3">

                                    <div class="user-avatar">
                                        <i class="bi bi-person-fill"></i>
                                    </div>

                                    <div class="user-info">
                                        <strong><?= e($result['full_name']) ?></strong>
                                        <small>
                                            @<?= e($result['username']) ?>
                                            &nbsp;|&nbsp;
                                            <?= e($result['email']) ?>
                                        </small>
                                        <br>
                                        <small>
                                            <?= e($result['phone']) ?>
                                            &nbsp;|&nbsp;
                                            <?= e(ucfirst($result['role'])) ?>
                                            &nbsp;|&nbsp;
                                            <?= e(ucfirst($result['status'])) ?>
                                        </small>
                                    </div>

                                </div>

                                <a
                                    href="<?= e($pageUrl) ?>?q=<?= urlencode($search) ?>&selected_user=<?= (int)$result['id'] ?>#password-reset"
                                    class="btn btn-sm btn-outline-primary"
                                >
                                    <i class="bi bi-person-check me-1"></i>
                                    Select User
                                </a>

                            </div>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </div>

            <?php endif; ?>

            <!-- SELECTED USER PASSWORD FORM -->

            <?php if ($selectedUser): ?>

                <hr class="my-4">

                <div class="section-label">
                    <i class="bi bi-key-fill me-1"></i>
                    Reset Selected User Password
                </div>

                <div class="selected-user">
                    <div class="d-flex align-items-center gap-3">

                        <div class="user-avatar">
                            <i class="bi bi-person-fill"></i>
                        </div>

                        <div class="user-info">
                            <strong><?= e($selectedUser['full_name']) ?></strong>
                            <small>
                                Username: @<?= e($selectedUser['username']) ?>
                            </small>
                            <br>
                            <small>
                                User ID: #<?= (int)$selectedUser['id'] ?>
                                &nbsp;|&nbsp;
                                <?= e($selectedUser['email']) ?>
                            </small>
                        </div>

                    </div>
                </div>

                <form
                    method="POST"
                    action="<?= e($pageUrl) ?>"
                    onsubmit="return confirmPasswordReset();"
                >

                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="target_user_id" value="<?= (int)$selectedUser['id'] ?>">

                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label">New Password</label>

                            <div class="input-group">
                                <input
                                    type="password"
                                    name="new_password"
                                    id="new_password"
                                    class="form-control"
                                    minlength="8"
                                    autocomplete="new-password"
                                    placeholder="Enter new password"
                                    required
                                >

                                <button
                                    type="button"
                                    class="btn btn-outline-secondary"
                                    onclick="togglePassword('new_password', this)"
                                >
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>

                            <small class="text-muted">At least 8 characters.</small>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Confirm New Password</label>

                            <div class="input-group">
                                <input
                                    type="password"
                                    name="confirm_password"
                                    id="confirm_password"
                                    class="form-control"
                                    minlength="8"
                                    autocomplete="new-password"
                                    placeholder="Confirm new password"
                                    required
                                >

                                <button
                                    type="button"
                                    class="btn btn-outline-secondary"
                                    onclick="togglePassword('confirm_password', this)"
                                >
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>
                        </div>

                    </div>

                    <div class="mt-4 d-flex flex-wrap gap-2">

                        <button type="submit" class="btn-gold">
                            <i class="bi bi-shield-check me-1"></i>
                            Reset User Password
                        </button>

                        <a href="<?= e($pageUrl) ?>#password-reset" class="btn btn-light border">
                            Cancel
                        </a>

                    </div>

                </form>

            <?php elseif ($selectedUserId > 0): ?>

                <div class="alert alert-warning mt-4">
                    Selected user account could not be found.
                </div>

            <?php endif; ?>

        </div>
    </div>

    <!-- SECURITY INFORMATION -->

    <div class="settings-card">

        <div class="card-header-custom">
            <div class="header-icon">
                <i class="bi bi-shield-check"></i>
            </div>

            <div>
                <h5>Security Information</h5>
                <p>Important information about administrator password recovery.</p>
            </div>
        </div>

        <div class="card-body-custom">

            <div class="row g-3">

                <div class="col-md-4">
                    <div class="d-flex gap-3">
                        <i class="bi bi-lock-fill text-success fs-4"></i>
                        <div>
                            <strong>Secure Hashing</strong>
                            <p class="text-muted small mb-0">
                                Passwords are stored using PHP's secure password hashing.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="d-flex gap-3">
                        <i class="bi bi-person-check-fill text-primary fs-4"></i>
                        <div>
                            <strong>Admin Only</strong>
                            <p class="text-muted small mb-0">
                                Only authenticated administrators can access this feature.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="d-flex gap-3">
                        <i class="bi bi-shield-lock-fill text-warning fs-4"></i>
                        <div>
                            <strong>Password Confirmation</strong>
                            <p class="text-muted small mb-0">
                                New passwords must be confirmed before they are saved.
                            </p>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);

    if (!input) {
        return;
    }

    if (input.type === 'password') {
        input.type = 'text';
        button.innerHTML = '<i class="bi bi-eye-slash"></i>';
    } else {
        input.type = 'password';
        button.innerHTML = '<i class="bi bi-eye"></i>';
    }
}

function confirmPasswordReset() {
    const password = document.getElementById('new_password').value;
    const confirmation = document.getElementById('confirm_password').value;

    if (password.length < 8) {
        alert('Password must contain at least 8 characters.');
        return false;
    }

    if (password !== confirmation) {
        alert('The passwords do not match.');
        return false;
    }

    return confirm('Are you sure you want to reset this user password?');
}
</script>

</body>
</html>
