
<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/../config/database.php';

// =====================================================
// 1. AUTHENTICATION
// =====================================================
if (empty($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$currentUserId = (int) $_SESSION['user_id'];

// Get current user's actual role from database
$auth = $pdo->prepare("
    SELECT id, full_name, role, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$auth->execute([$currentUserId]);

$currentUser = $auth->fetch(PDO::FETCH_ASSOC);

if (
    !$currentUser ||
    $currentUser['role'] !== 'admin' ||
    $currentUser['status'] !== 'active'
) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

// =====================================================
// 2. HELPERS
// =====================================================
function e($value): string {
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$success = '';
$error = '';

// =====================================================
// 3. HANDLE ADMIN ACTIONS
// =====================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals(
            $_SESSION['csrf_token'],
            $_POST['csrf_token'] ?? ''
        )) {
            throw new Exception('Security verification failed. Refresh the page.');
        }

        $action = $_POST['action'] ?? '';
        $userId = (int)($_POST['user_id'] ?? 0);

        if ($userId <= 0) {
            throw new Exception('Invalid user ID.');
        }

        if ($userId === $currentUserId) {
            throw new Exception('You cannot modify your own account here.');
        }

        // Check target user
        $check = $pdo->prepare("
            SELECT id, role FROM users WHERE id = ?
        ");
        $check->execute([$userId]);
        $targetUser = $check->fetch(PDO::FETCH_ASSOC);

        if (!$targetUser) {
            throw new Exception('User not found.');
        }

        // CHANGE ACCOUNT STATUS
        if ($action === 'change_status') {
            $newStatus = $_POST['status'] ?? '';

            $allowedStatuses = [
                'active',
                'inactive',
                'suspended'
            ];

            if (!in_array($newStatus, $allowedStatuses, true)) {
                throw new Exception('Invalid account status.');
            }

            $stmt = $pdo->prepare("
                UPDATE users
                SET status = ?
                WHERE id = ?
            ");

            $stmt->execute([$newStatus, $userId]);

            $success = 'User account status updated successfully.';
        }

        // CHANGE USER ROLE
        elseif ($action === 'change_role') {
            $newRole = $_POST['role'] ?? '';

            if (!in_array($newRole, ['admin', 'user'], true)) {
                throw new Exception('Invalid user role.');
            }

            // Prevent removing the final active administrator
            if (
                $targetUser['role'] === 'admin' &&
                $newRole !== 'admin'
            ) {
                $count = $pdo->query("
                    SELECT COUNT(*)
                    FROM users
                    WHERE role = 'admin'
                    AND status = 'active'
                ")->fetchColumn();

                if ((int)$count <= 1) {
                    throw new Exception(
                        'You cannot remove the last active administrator.'
                    );
                }
            }

            $stmt = $pdo->prepare("
                UPDATE users
                SET role = ?
                WHERE id = ?
            ");

            $stmt->execute([$newRole, $userId]);

            $success = 'User role updated successfully.';
        }

        else {
            throw new Exception('Invalid action.');
        }

    } catch (Throwable $ex) {
        $error = $ex->getMessage();
    }
}

// =====================================================
// 4. SEARCH AND FILTER
// =====================================================
$search = trim($_GET['search'] ?? '');
$roleFilter = $_GET['role'] ?? '';
$statusFilter = $_GET['status'] ?? '';

$sql = "
    SELECT
        id,
        full_name,
        username,
        email,
        phone,
        role,
        status,
        referral_code,
        created_at
    FROM users
    WHERE 1=1
";

$params = [];

if ($search !== '') {
    $sql .= "
        AND (
            full_name LIKE ?
            OR username LIKE ?
            OR email LIKE ?
            OR phone LIKE ?
        )
    ";

    $term = '%' . $search . '%';

    array_push($params, $term, $term, $term, $term);
}

if (in_array($roleFilter, ['admin', 'user'], true)) {
    $sql .= " AND role = ?";
    $params[] = $roleFilter;
}

if (in_array(
    $statusFilter,
    ['active', 'inactive', 'suspended'],
    true
)) {
    $sql .= " AND status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// =====================================================
// 5. STATISTICS
// =====================================================
$totalUsers = (int)$pdo->query("
    SELECT COUNT(*) FROM users
")->fetchColumn();

$activeUsers = (int)$pdo->query("
    SELECT COUNT(*) FROM users WHERE status = 'active'
")->fetchColumn();

$inactiveUsers = (int)$pdo->query("
    SELECT COUNT(*) FROM users WHERE status = 'inactive'
")->fetchColumn();

$suspendedUsers = (int)$pdo->query("
    SELECT COUNT(*) FROM users WHERE status = 'suspended'
")->fetchColumn();

$adminCount = (int)$pdo->query("
    SELECT COUNT(*) FROM users WHERE role = 'admin'
")->fetchColumn();

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Manage Users | DigitalMarket</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f4f6fb;
    color: #1e293b;
}

.header {
    background: #102747;
    color: white;
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}

.header h2 {
    font-size: 21px;
}

.header a {
    text-decoration: none;
    color: #102747;
    background: #e5b34c;
    padding: 11px 17px;
    border-radius: 7px;
    font-weight: bold;
}

.container {
    max-width: 1350px;
    margin: 30px auto;
    padding: 0 20px;
}

.heading {
    margin-bottom: 25px;
}

.heading h1 {
    font-size: 28px;
    margin-bottom: 7px;
}

.heading p {
    color: #64748b;
}

.stats {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 16px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 21px;
    box-shadow: 0 3px 12px rgba(0,0,0,.04);
}

.stat-card span {
    color: #64748b;
    font-size: 13px;
}

.stat-card h2 {
    font-size: 27px;
    margin-top: 10px;
}

.panel {
    background: white;
    padding: 24px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,.04);
}

.panel h2 {
    font-size: 20px;
    margin-bottom: 20px;
}

.alert {
    padding: 14px 17px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.success {
    background: #dcfce7;
    color: #166534;
}

.error {
    background: #fee2e2;
    color: #991b1b;
}

.filters {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 20px;
}

input, select {
    padding: 11px 13px;
    border: 1px solid #dce2ea;
    border-radius: 7px;
    font-size: 13px;
    outline: none;
}

.filters input {
    flex: 1;
    min-width: 220px;
}

input:focus, select:focus {
    border-color: #2563eb;
}

.btn {
    border: none;
    padding: 10px 13px;
    border-radius: 7px;
    cursor: pointer;
    font-size: 12px;
    font-weight: bold;
    text-decoration: none;
    display: inline-block;
}

.primary {
    background: #102747;
    color: white;
}

.secondary {
    background: #e2e8f0;
    color: #334155;
}

.green {
    background: #dcfce7;
    color: #166534;
}

.orange {
    background: #fef3c7;
    color: #92400e;
}

.red {
    background: #fee2e2;
    color: #991b1b;
}

.table-wrap {
    overflow-x: auto;
}

table {
    width: 100%;
    min-width: 1050px;
    border-collapse: collapse;
}

th, td {
    padding: 14px 12px;
    border-bottom: 1px solid #edf0f5;
    text-align: left;
    font-size: 13px;
}

th {
    background: #f8fafc;
    color: #475569;
}

.user-name {
    font-weight: bold;
    margin-bottom: 4px;
}

.user-email {
    color: #64748b;
    font-size: 12px;
}

.role-badge, .status-badge {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
}

.role-badge {
    background: #e0e7ff;
    color: #3730a3;
}

.active {
    background: #dcfce7;
    color: #166534;
}

.inactive {
    background: #e2e8f0;
    color: #475569;
}

.suspended {
    background: #fee2e2;
    color: #991b1b;
}

.action-group {
    display: flex;
    gap: 7px;
    align-items: center;
    flex-wrap: wrap;
}

.action-group form {
    display: flex;
    gap: 5px;
    align-items: center;
}

.action-group select {
    padding: 8px;
    max-width: 115px;
}

.empty {
    text-align: center;
    padding: 35px;
    color: #64748b;
}

.current {
    color: #64748b;
    font-size: 12px;
}

@media(max-width: 1000px) {
    .stats {
        grid-template-columns: repeat(3, 1fr);
    }
}

@media(max-width: 650px) {
    .stats {
        grid-template-columns: repeat(2, 1fr);
    }

    .header {
        padding: 18px;
    }

    .container {
        padding: 0 12px;
    }

    .panel {
        padding: 15px;
    }
}
</style>
</head>

<body>

<header class="header">
    <h2>DigitalMarket | Admin Panel</h2>
    <a href="dashboard.php">Back to Dashboard</a>
</header>

<main class="container">

    <section class="heading">
        <h1>User Management</h1>
        <p>Manage registered users, account access and administrator roles.</p>
    </section>

    <?php if ($success): ?>
        <div class="alert success"><?= e($success) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert error"><?= e($error) ?></div>
    <?php endif; ?>

    <section class="stats">

        <div class="stat-card">
            <span>Total Users</span>
            <h2><?= number_format($totalUsers) ?></h2>
        </div>

        <div class="stat-card">
            <span>Active Accounts</span>
            <h2><?= number_format($activeUsers) ?></h2>
        </div>

        <div class="stat-card">
            <span>Inactive Accounts</span>
            <h2><?= number_format($inactiveUsers) ?></h2>
        </div>

        <div class="stat-card">
            <span>Suspended Accounts</span>
            <h2><?= number_format($suspendedUsers) ?></h2>
        </div>

        <div class="stat-card">
            <span>Administrators</span>
            <h2><?= number_format($adminCount) ?></h2>
        </div>

    </section>

    <section class="panel">

        <h2>Registered Users</h2>

        <form method="GET" class="filters">

            <input
                type="text"
                name="search"
                placeholder="Search name, username, email or phone..."
                value="<?= e($search) ?>"
            >

            <select name="role">
                <option value="">All Roles</option>
                <option value="admin" <?= $roleFilter === 'admin' ? 'selected' : '' ?>>
                    Administrator
                </option>
                <option value="user" <?= $roleFilter === 'user' ? 'selected' : '' ?>>
                    User
                </option>
            </select>

            <select name="status">
                <option value="">All Statuses</option>
                <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>
                    Active
                </option>
                <option value="inactive" <?= $statusFilter === 'inactive' ? 'selected' : '' ?>>
                    Inactive
                </option>
                <option value="suspended" <?= $statusFilter === 'suspended' ? 'selected' : '' ?>>
                    Suspended
                </option>
            </select>

            <button class="btn primary" type="submit">Search</button>

            <a href="users.php" class="btn secondary">Reset</a>

        </form>

        <div class="table-wrap">

            <table>

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User Information</th>
                        <th>Username</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Registered</th>
                        <th>Manage</th>
                    </tr>
                </thead>

                <tbody>

                <?php if ($users): ?>

                    <?php foreach ($users as $user): ?>

                        <tr>

                            <td><?= (int)$user['id'] ?></td>

                            <td>
                                <div class="user-name">
                                    <?= e($user['full_name']) ?>
                                </div>

                                <div class="user-email">
                                    <?= e($user['email']) ?>
                                </div>
                            </td>

                            <td><?= e($user['username']) ?></td>

                            <td><?= e($user['phone']) ?></td>

                            <td>
                                <span class="role-badge">
                                    <?= e(ucfirst($user['role'])) ?>
                                </span>
                            </td>

                            <td>
                                <span class="status-badge <?= e($user['status']) ?>">
                                    <?= e(ucfirst($user['status'])) ?>
                                </span>
                            </td>

                            <td><?= e($user['created_at']) ?></td>

                            <td>
                                <?php if ((int)$user['id'] !== $currentUserId): ?>

                                    <div class="action-group">

                                        <!-- CHANGE STATUS -->
                                        <form method="POST">
                                            <input type="hidden"
                                                name="csrf_token"
                                                value="<?= e($_SESSION['csrf_token']) ?>">

                                            <input type="hidden"
                                                name="user_id"
                                                value="<?= (int)$user['id'] ?>">

                                            <input type="hidden"
                                                name="action"
                                                value="change_status">

                                            <select name="status">
                                                <option value="active"
                                                    <?= $user['status'] === 'active' ? 'selected' : '' ?>>
                                                    Active
                                                </option>

                                                <option value="inactive"
                                                    <?= $user['status'] === 'inactive' ? 'selected' : '' ?>>
                                                    Inactive
                                                </option>

                                                <option value="suspended"
                                                    <?= $user['status'] === 'suspended' ? 'selected' : '' ?>>
                                                    Suspended
                                                </option>
                                            </select>

                                            <button class="btn orange" type="submit">
                                                Status
                                            </button>
                                        </form>

                                        <!-- CHANGE ROLE -->
                                        <form method="POST"
                                            onsubmit="return confirm('Change this user role?');">

                                            <input type="hidden"
                                                name="csrf_token"
                                                value="<?= e($_SESSION['csrf_token']) ?>">

                                            <input type="hidden"
                                                name="user_id"
                                                value="<?= (int)$user['id'] ?>">

                                            <input type="hidden"
                                                name="action"
                                                value="change_role">

                                            <select name="role">
                                                <option value="user"
                                                    <?= $user['role'] === 'user' ? 'selected' : '' ?>>
                                                    User
                                                </option>

                                                <option value="admin"
                                                    <?= $user['role'] === 'admin' ? 'selected' : '' ?>>
                                                    Admin
                                                </option>
                                            </select>

                                            <button class="btn primary" type="submit">
                                                Role
                                            </button>
                                        </form>

                                    </div>

                                <?php else: ?>

                                    <span class="current">Your account</span>

                                <?php endif; ?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="8" class="empty">
                            No registered users found.
                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

</main>

</body>
</html>
