
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection failed. Check config/database.php.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| ADMIN AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$auth = $pdo->prepare("
    SELECT id, role, status
    FROM users
    WHERE id = ?
    LIMIT 1
");

$auth->execute([(int)$_SESSION['user_id']]);
$admin = $auth->fetch();

if (
    !$admin ||
    $admin['role'] !== 'admin' ||
    $admin['status'] !== 'active'
) {
    session_unset();
    session_destroy();
    header('Location: ../auth/login.php');
    exit;
}

$adminId = (int)$admin['id'];

/*
|--------------------------------------------------------------------------
| HELPER FUNCTIONS
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function money($amount): string
{
    return number_format((float)$amount, 2);
}

function paymentMethodField(
    array $columns,
    string $alias,
    array $candidates,
    string $fallback = 'NULL'
): string {
    foreach ($candidates as $candidate) {
        if (in_array($candidate, $columns, true)) {
            return $alias . '.`' . $candidate . '`';
        }
    }

    return $fallback;
}

/*
|--------------------------------------------------------------------------
| DETECT PAYMENT METHODS TABLE STRUCTURE
|--------------------------------------------------------------------------
*/

try {
    $pmColumns = $pdo->query(
        "SHOW COLUMNS FROM `payment_methods`"
    )->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    die('Cannot read payment_methods table. Please verify that the table exists.');
}

if (!in_array('id', $pmColumns, true)) {
    die('The payment_methods table must contain an id column.');
}

$pmName = paymentMethodField(
    $pmColumns,
    'pm',
    ['name', 'method_name', 'payment_method', 'title', 'method'],
    "CONCAT('Payment Method #', d.payment_method_id)"
);

$pmAccountName = paymentMethodField(
    $pmColumns,
    'pm',
    ['account_name', 'account_holder', 'holder_name']
);

$pmAccountNumber = paymentMethodField(
    $pmColumns,
    'pm',
    ['account_number', 'account_no', 'account', 'phone_number']
);

$pmInstructions = paymentMethodField(
    $pmColumns,
    'pm',
    ['instructions', 'description', 'details']
);

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['deposits_csrf'])) {
    $_SESSION['deposits_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['deposits_csrf'];

$message = '';
$messageType = 'success';
$minimumDeposit = 500;

/*
|--------------------------------------------------------------------------
| APPROVE OR REJECT DEPOSIT
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {
        $token = $_POST['csrf_token'] ?? '';

        if (!is_string($token) || !hash_equals($csrfToken, $token)) {
            throw new RuntimeException('Security verification failed. Please refresh the page.');
        }

        $action = $_POST['action'] ?? '';

        $depositId = filter_var(
            $_POST['deposit_id'] ?? '',
            FILTER_VALIDATE_INT
        );

        if (!$depositId || $depositId < 1) {
            throw new RuntimeException('Invalid deposit ID.');
        }

        if (!in_array($action, ['approve', 'reject'], true)) {
            throw new RuntimeException('Invalid action.');
        }

        $pdo->beginTransaction();

        /*
         * Lock deposit to prevent simultaneous approval.
         */

        $stmt = $pdo->prepare("
            SELECT
                id,
                user_id,
                amount,
                transaction_id,
                status
            FROM deposits
            WHERE id = ?
            FOR UPDATE
        ");

        $stmt->execute([$depositId]);
        $deposit = $stmt->fetch();

        if (!$deposit) {
            throw new RuntimeException('Deposit request not found.');
        }

        if ($deposit['status'] !== 'pending') {
            throw new RuntimeException('This deposit has already been reviewed.');
        }

        /*
        |--------------------------------------------------------------------------
        | APPROVE DEPOSIT
        |--------------------------------------------------------------------------
        */

        if ($action === 'approve') {

            $amount = (float)$deposit['amount'];

            if ($amount < $minimumDeposit) {
                throw new RuntimeException(
                    'Deposit amount is below the minimum of 500 ETB.'
                );
            }

            if ($amount <= 0) {
                throw new RuntimeException('Invalid deposit amount.');
            }

            /*
             * Unique key for this particular deposit approval.
             * This prevents the same deposit from being credited twice.
             */

            $idempotencyKey = 'deposit_approval_' . $depositId;

            /*
             * Create wallet if it does not exist.
             * INSERT IGNORE handles concurrent wallet creation safely
             * when the user_id + wallet_type unique key exists.
             */

            $createWallet = $pdo->prepare("
                INSERT IGNORE INTO wallet_accounts
                    (user_id, wallet_type, balance, reserved_balance)
                VALUES
                    (?, 'purchase', 0.00, 0.00)
            ");

            $createWallet->execute([
                (int)$deposit['user_id']
            ]);

            /*
             * Find and lock purchase wallet.
             */

            $walletStmt = $pdo->prepare("
                SELECT id, balance
                FROM wallet_accounts
                WHERE user_id = ?
                  AND wallet_type = 'purchase'
                LIMIT 1
                FOR UPDATE
            ");

            $walletStmt->execute([
                (int)$deposit['user_id']
            ]);

            $wallet = $walletStmt->fetch();

            if (!$wallet) {
                throw new RuntimeException(
                    'Could not create or locate the customer purchase wallet.'
                );
            }

            $walletId = (int)$wallet['id'];

            /*
             * Check whether this deposit has already been credited.
             */

            $existingLedgerStmt = $pdo->prepare("
                SELECT
                    id,
                    wallet_id,
                    transaction_type,
                    amount
                FROM wallet_transactions
                WHERE idempotency_key = ?
                LIMIT 1
                FOR UPDATE
            ");

            $existingLedgerStmt->execute([$idempotencyKey]);
            $existingLedger = $existingLedgerStmt->fetch();

            if ($existingLedger) {

                /*
                 * If a matching transaction exists, do not credit again.
                 * Verify that it belongs to this wallet and deposit.
                 */

                if (
                    (int)$existingLedger['wallet_id'] !== $walletId ||
                    $existingLedger['transaction_type'] !== 'credit' ||
                    abs((float)$existingLedger['amount'] - $amount) > 0.001
                ) {
                    throw new RuntimeException(
                        'A conflicting wallet transaction already exists for this deposit. Please investigate it.'
                    );
                }

            } else {

                /*
                 * Credit the purchase wallet.
                 */

                $credit = $pdo->prepare("
                    UPDATE wallet_accounts
                    SET balance = balance + ?
                    WHERE id = ?
                ");

                $credit->execute([
                    $amount,
                    $walletId
                ]);

                if ($credit->rowCount() !== 1) {
                    throw new RuntimeException(
                        'Could not update customer wallet.'
                    );
                }

                /*
                 * Read the updated balance for the transaction ledger.
                 */

                $balanceStmt = $pdo->prepare("
                    SELECT balance
                    FROM wallet_accounts
                    WHERE id = ?
                    LIMIT 1
                ");

                $balanceStmt->execute([$walletId]);
                $newBalance = $balanceStmt->fetchColumn();

                if ($newBalance === false) {
                    throw new RuntimeException(
                        'Could not verify the updated wallet balance.'
                    );
                }

                /*
                 * Record wallet transaction.
                 *
                 * IMPORTANT:
                 * idempotency_key is now populated with a unique value.
                 * balance_after records the resulting wallet balance.
                 */

                $ledger = $pdo->prepare("
                    INSERT INTO wallet_transactions
                    (
                        wallet_id,
                        transaction_type,
                        amount,
                        balance_after,
                        reference_type,
                        reference_id,
                        idempotency_key,
                        description,
                        created_at
                    )
                    VALUES
                    (?, 'credit', ?, ?, 'deposit', ?, ?, ?, NOW())
                ");

                $ledger->execute([
                    $walletId,
                    $amount,
                    $newBalance,
                    $depositId,
                    $idempotencyKey,
                    'Manual deposit approved. Transaction: ' .
                        $deposit['transaction_id']
                ]);
            }

            /*
             * Mark deposit approved.
             */

            $update = $pdo->prepare("
                UPDATE deposits
                SET
                    status = 'approved',
                    reviewed_by = ?,
                    reviewed_at = NOW()
                WHERE id = ?
                  AND status = 'pending'
            ");

            $update->execute([
                $adminId,
                $depositId
            ]);

            if ($update->rowCount() !== 1) {
                throw new RuntimeException(
                    'Could not approve the deposit.'
                );
            }

            $pdo->commit();

            header('Location: deposits.php?success=approved');
            exit;
        }

        /*
        |--------------------------------------------------------------------------
        | REJECT DEPOSIT
        |--------------------------------------------------------------------------
        */

        if ($action === 'reject') {

            $update = $pdo->prepare("
                UPDATE deposits
                SET
                    status = 'rejected',
                    reviewed_by = ?,
                    reviewed_at = NOW()
                WHERE id = ?
                  AND status = 'pending'
            ");

            $update->execute([
                $adminId,
                $depositId
            ]);

            if ($update->rowCount() !== 1) {
                throw new RuntimeException('Could not reject the deposit.');
            }

            $pdo->commit();

            header('Location: deposits.php?success=rejected');
            exit;
        }

    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $message = $e->getMessage();
        $messageType = 'error';
    }
}

/*
|--------------------------------------------------------------------------
| SUCCESS MESSAGES
|--------------------------------------------------------------------------
*/

if (($_GET['success'] ?? '') === 'approved') {
    $message = 'Deposit approved and purchase wallet credited successfully.';
}

if (($_GET['success'] ?? '') === 'rejected') {
    $message = 'Deposit request rejected successfully.';
}

/*
|--------------------------------------------------------------------------
| SEARCH AND FILTER
|--------------------------------------------------------------------------
*/

$search = trim((string)($_GET['search'] ?? ''));
$statusFilter = $_GET['status'] ?? '';

$allowedStatuses = ['pending', 'approved', 'rejected'];

$where = [];
$params = [];

if ($search !== '') {

    $where[] = "(
        d.transaction_id LIKE ?
        OR CAST(d.id AS CHAR) LIKE ?
        OR u.username LIKE ?
        OR u.full_name LIKE ?
    )";

    $term = '%' . $search . '%';

    $params = [$term, $term, $term, $term];
}

if (in_array($statusFilter, $allowedStatuses, true)) {
    $where[] = "d.status = ?";
    $params[] = $statusFilter;
}

/*
|--------------------------------------------------------------------------
| FETCH DEPOSIT REQUESTS
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        d.id,
        d.user_id,
        d.payment_method_id,
        d.amount,
        d.transaction_id,
        d.proof_path,
        d.status,
        d.reviewed_by,
        d.reviewed_at,
        d.created_at,

        u.username,
        u.full_name,

        $pmName AS payment_method_name,
        $pmAccountName AS account_name,
        $pmAccountNumber AS account_number,

        reviewer.username AS reviewer_username

    FROM deposits d

    LEFT JOIN users u
        ON u.id = d.user_id

    LEFT JOIN payment_methods pm
        ON pm.id = d.payment_method_id

    LEFT JOIN users reviewer
        ON reviewer.id = d.reviewed_by
";

if ($where) {
    $sql .= " WHERE " . implode(' AND ', $where);
}

$sql .= " ORDER BY d.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$deposits = $stmt->fetchAll();

/*
|--------------------------------------------------------------------------
| DEPOSIT STATISTICS
|--------------------------------------------------------------------------
*/

$stats = $pdo->query("
    SELECT
        COUNT(*) AS total_deposits,

        COALESCE(
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END), 0
        ) AS pending_count,

        COALESCE(
            SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END), 0
        ) AS approved_count,

        COALESCE(
            SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END), 0
        ) AS rejected_count,

        COALESCE(
            SUM(CASE WHEN status = 'approved' THEN amount ELSE 0 END), 0
        ) AS approved_amount,

        COALESCE(
            SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END), 0
        ) AS pending_amount

    FROM deposits
")->fetch();

/*
|--------------------------------------------------------------------------
| VIEW SINGLE DEPOSIT
|--------------------------------------------------------------------------
*/

$viewDeposit = null;

if (isset($_GET['view'])) {

    $viewId = filter_var($_GET['view'], FILTER_VALIDATE_INT);

    if ($viewId) {

        $viewStmt = $pdo->prepare("
            SELECT
                d.*,
                u.username,
                u.full_name,

                $pmName AS payment_method_name,
                $pmAccountName AS account_name,
                $pmAccountNumber AS account_number,
                $pmInstructions AS instructions,

                reviewer.username AS reviewer_username

            FROM deposits d

            LEFT JOIN users u
                ON u.id = d.user_id

            LEFT JOIN payment_methods pm
                ON pm.id = d.payment_method_id

            LEFT JOIN users reviewer
                ON reviewer.id = d.reviewed_by

            WHERE d.id = ?
            LIMIT 1
        ");

        $viewStmt->execute([$viewId]);
        $viewDeposit = $viewStmt->fetch();
    }
}

/*
|--------------------------------------------------------------------------
| PAYMENT PROOF PATH
|--------------------------------------------------------------------------
*/

function paymentProofUrl($path): ?string
{
    if (!$path) {
        return null;
    }

    $path = str_replace('\\', '/', trim((string)$path));
    $path = ltrim($path, '/');

    if (
        strpos($path, 'storage/payment_proofs/') !== 0 ||
        strpos($path, '..') !== false
    ) {
        return null;
    }

    return '../' . $path;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Deposit Management | DigitalMarket</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f3f5f9;
    color: #17243b;
}

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 245px;
    height: 100vh;
    background: #102747;
    color: white;
    padding: 28px 18px;
}

.brand {
    font-size: 23px;
    font-weight: bold;
    margin-bottom: 40px;
    padding-left: 10px;
}

.brand span {
    color: #e5b34c;
}

.nav-label {
    font-size: 11px;
    color: #9caec4;
    text-transform: uppercase;
    margin: 22px 10px 12px;
    letter-spacing: 1px;
}

.sidebar a {
    display: block;
    padding: 13px 12px;
    color: #dce5f1;
    text-decoration: none;
    font-size: 14px;
    border-radius: 7px;
    margin-bottom: 5px;
}

.sidebar a:hover,
.sidebar a.active {
    background: #203d62;
    color: white;
}

.sidebar a.active {
    border-left: 3px solid #e5b34c;
}

.main {
    margin-left: 245px;
    padding: 30px;
}

.topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    margin-bottom: 28px;
}

.topbar h1 {
    font-size: 25px;
    margin-bottom: 7px;
}

.topbar p {
    color: #78869b;
    font-size: 13px;
}

.admin-info {
    padding: 12px 16px;
    background: white;
    border: 1px solid #e8edf4;
    border-radius: 8px;
    font-size: 13px;
}

.stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
    margin-bottom: 24px;
}

.stat-card {
    background: white;
    padding: 20px;
    border: 1px solid #e8edf4;
    border-radius: 11px;
}

.stat-card small {
    color: #77869b;
    font-size: 12px;
}

.stat-card h2 {
    margin-top: 10px;
    font-size: 25px;
}

.stat-card.highlight {
    background: #102747;
    color: white;
}

.stat-card.highlight small {
    color: #d0d9e6;
}

.panel {
    background: white;
    border: 1px solid #e8edf4;
    border-radius: 11px;
    padding: 22px;
    margin-bottom: 24px;
}

.panel-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-bottom: 20px;
}

.panel-heading h2 {
    font-size: 17px;
}

.alert {
    padding: 13px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 13px;
}

.alert.success {
    background: #e8f8ef;
    color: #187545;
}

.alert.error {
    background: #fff0f0;
    color: #b52e2e;
}

.filter-row {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 20px;
}

input,
select {
    padding: 11px 12px;
    border: 1px solid #dce3ed;
    border-radius: 7px;
    outline: none;
    background: white;
    font-size: 12px;
}

input:focus,
select:focus {
    border-color: #315c91;
}

.filter-row input {
    min-width: 250px;
}

.btn {
    display: inline-block;
    padding: 10px 14px;
    border: none;
    border-radius: 7px;
    font-size: 12px;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;
    text-align: center;
}

.btn-primary {
    background: #102747;
    color: white;
}

.btn-primary:hover {
    background: #203d62;
}

.btn-success {
    background: #16834b;
    color: white;
}

.btn-danger {
    background: #bd3434;
    color: white;
}

.btn-light {
    background: #eef2f7;
    color: #263b56;
}

.btn-small {
    padding: 7px 10px;
    font-size: 11px;
}

.table-wrap {
    overflow-x: auto;
}

table {
    width: 100%;
    min-width: 1000px;
    border-collapse: collapse;
}

th {
    background: #f6f8fb;
    padding: 14px 12px;
    text-align: left;
    font-size: 11px;
    color: #687991;
    text-transform: uppercase;
}

td {
    padding: 14px 12px;
    border-bottom: 1px solid #edf0f5;
    font-size: 12px;
    vertical-align: middle;
}

.sub-text {
    display: block;
    color: #8491a4;
    font-size: 11px;
    margin-top: 5px;
}

.amount {
    font-weight: bold;
    color: #18395e;
}

.badge {
    display: inline-block;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: bold;
    text-transform: capitalize;
}

.badge.pending {
    background: #fff4d9;
    color: #a16a00;
}

.badge.approved {
    background: #e5f8ed;
    color: #16834b;
}

.badge.rejected {
    background: #fff0f0;
    color: #bd3434;
}

.actions {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
}

.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}

.detail-item {
    padding: 15px;
    border: 1px solid #edf0f5;
    border-radius: 8px;
    overflow-wrap: anywhere;
}

.detail-item small {
    display: block;
    color: #8491a4;
    font-size: 11px;
    margin-bottom: 8px;
}

.detail-item strong {
    font-size: 13px;
}

.proof-image {
    display: block;
    max-width: 100%;
    max-height: 450px;
    margin-top: 12px;
    border: 1px solid #e8edf4;
    border-radius: 8px;
}

.empty {
    text-align: center;
    padding: 35px;
    color: #8290a4;
}

.detail-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 22px;
}

@media(max-width: 1000px) {
    .sidebar {
        width: 200px;
    }

    .main {
        margin-left: 200px;
        padding: 20px;
    }

    .stats {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media(max-width: 650px) {
    .sidebar {
        position: static;
        width: 100%;
        height: auto;
    }

    .main {
        margin-left: 0;
        padding: 15px;
    }

    .stats,
    .detail-grid {
        grid-template-columns: 1fr;
    }

    .topbar {
        align-items: flex-start;
        flex-direction: column;
    }

    .filter-row input {
        width: 100%;
    }
}
</style>
</head>

<body>

<aside class="sidebar">

    <div class="brand">
        Digital<span>Market</span>
    </div>

    <div class="nav-label">Main Menu</div>

    <a href="dashboard.php">Dashboard</a>
    <a href="deposits.php" class="active">Deposits</a>
    <a href="../auth/logout.php">Logout</a>

</aside>

<main class="main">

    <div class="topbar">

        <div>
            <h1>Deposit Management</h1>
            <p>Review manual recharge requests and manage customer wallet credits.</p>
        </div>

        <div class="admin-info">
            Administrator:
            <strong><?= h($_SESSION['login_name'] ?? 'Administrator') ?></strong>
        </div>

    </div>

    <?php if ($message !== ''): ?>
        <div class="alert <?= h($messageType) ?>">
            <?= h($message) ?>
        </div>
    <?php endif; ?>

    <section class="stats">

        <div class="stat-card">
            <small>Total Deposit Requests</small>
            <h2><?= (int)$stats['total_deposits'] ?></h2>
        </div>

        <div class="stat-card">
            <small>Pending Requests</small>
            <h2><?= (int)$stats['pending_count'] ?></h2>
        </div>

        <div class="stat-card">
            <small>Approved Requests</small>
            <h2><?= (int)$stats['approved_count'] ?></h2>
        </div>

        <div class="stat-card">
            <small>Rejected Requests</small>
            <h2><?= (int)$stats['rejected_count'] ?></h2>
        </div>

        <div class="stat-card highlight">
            <small>Total Approved Deposits (ETB)</small>
            <h2><?= money($stats['approved_amount']) ?></h2>
        </div>

        <div class="stat-card">
            <small>Pending Deposit Value (ETB)</small>
            <h2><?= money($stats['pending_amount']) ?></h2>
        </div>

    </section>

    <?php if (isset($_GET['view'])): ?>

    <section class="panel">

        <div class="panel-heading">
            <h2>Deposit Request Details</h2>

            <a href="deposits.php" class="btn btn-light">
                Back to Deposits
            </a>
        </div>

        <?php if (!$viewDeposit): ?>

            <p class="empty">Deposit request not found.</p>

        <?php else: ?>

            <div class="detail-grid">

                <div class="detail-item">
                    <small>Deposit ID</small>
                    <strong>#<?= (int)$viewDeposit['id'] ?></strong>
                </div>

                <div class="detail-item">
                    <small>Customer</small>
                    <strong>
                        <?= h($viewDeposit['full_name'] ?? 'Unknown customer') ?>
                        (<?= h($viewDeposit['username'] ?? '') ?>)
                    </strong>
                </div>

                <div class="detail-item">
                    <small>Amount</small>
                    <strong><?= money($viewDeposit['amount']) ?> ETB</strong>
                </div>

                <div class="detail-item">
                    <small>Payment Method</small>
                    <strong><?= h($viewDeposit['payment_method_name'] ?? 'Unknown') ?></strong>
                </div>

                <div class="detail-item">
                    <small>Transaction ID</small>
                    <strong><?= h($viewDeposit['transaction_id']) ?></strong>
                </div>

                <div class="detail-item">
                    <small>Payment Account Name</small>
                    <strong><?= h($viewDeposit['account_name'] ?? 'Not available') ?></strong>
                </div>

                <div class="detail-item">
                    <small>Payment Account Number</small>
                    <strong><?= h($viewDeposit['account_number'] ?? 'Not available') ?></strong>
                </div>

                <div class="detail-item">
                    <small>Deposit Status</small>
                    <strong>
                        <span class="badge <?= h($viewDeposit['status']) ?>">
                            <?= h($viewDeposit['status']) ?>
                        </span>
                    </strong>
                </div>

                <div class="detail-item">
                    <small>Submitted At</small>
                    <strong><?= h($viewDeposit['created_at']) ?></strong>
                </div>

                <div class="detail-item">
                    <small>Reviewed By</small>
                    <strong><?= h($viewDeposit['reviewer_username'] ?? 'Not reviewed') ?></strong>
                </div>

                <div class="detail-item">
                    <small>Reviewed At</small>
                    <strong><?= h($viewDeposit['reviewed_at'] ?? 'Not reviewed') ?></strong>
                </div>

                <div class="detail-item">
                    <small>Payment Instructions</small>
                    <strong><?= h($viewDeposit['instructions'] ?? 'Not available') ?></strong>
                </div>

            </div>

            <div style="margin-top:22px;">

                <h3 style="font-size:15px;margin-bottom:10px;">
                    Payment Screenshot / Proof
                </h3>

                <?php
                $proofUrl = paymentProofUrl(
                    $viewDeposit['proof_path'] ?? null
                );
                ?>

                <?php if ($proofUrl): ?>

                    <a href="<?= h($proofUrl) ?>"
                       target="_blank"
                       rel="noopener">
                        View Uploaded Payment Proof
                    </a>

                    <img
                        src="<?= h($proofUrl) ?>"
                        alt="Payment proof"
                        class="proof-image"
                        loading="lazy"
                    >

                <?php else: ?>

                    <p class="sub-text">
                        No valid payment proof file is available.
                    </p>

                <?php endif; ?>

            </div>

            <?php if ($viewDeposit['status'] === 'pending'): ?>

                <div class="detail-actions">

                    <form method="POST"
                          onsubmit="return confirm('Verify the payment and credit <?= h(money($viewDeposit['amount'])) ?> ETB to this customer purchase wallet?');">

                        <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
                        <input type="hidden" name="deposit_id" value="<?= (int)$viewDeposit['id'] ?>">
                        <input type="hidden" name="action" value="approve">

                        <button type="submit" class="btn btn-success">
                            Approve Deposit
                        </button>

                    </form>

                    <form method="POST"
                          onsubmit="return confirm('Are you sure you want to reject this deposit request?');">

                        <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
                        <input type="hidden" name="deposit_id" value="<?= (int)$viewDeposit['id'] ?>">
                        <input type="hidden" name="action" value="reject">

                        <button type="submit" class="btn btn-danger">
                            Reject Deposit
                        </button>

                    </form>

                </div>

            <?php else: ?>

                <p class="sub-text" style="margin-top:20px;">
                    This deposit has already been reviewed and cannot be processed again.
                </p>

            <?php endif; ?>

        <?php endif; ?>

    </section>

    <?php endif; ?>

    <section class="panel">

        <div class="panel-heading">

            <h2>All Deposit Requests</h2>

            <span class="sub-text">
                <?= count($deposits) ?> request(s) found
            </span>

        </div>

        <form method="GET" class="filter-row">

            <input
                type="text"
                name="search"
                placeholder="Search transaction ID, customer or deposit ID..."
                value="<?= h($search) ?>"
            >

            <select name="status">
                <option value="">All Statuses</option>

                <?php foreach ($allowedStatuses as $status): ?>
                    <option
                        value="<?= h($status) ?>"
                        <?= $statusFilter === $status ? 'selected' : '' ?>
                    >
                        <?= ucfirst($status) ?>
                    </option>
                <?php endforeach; ?>

            </select>

            <button type="submit" class="btn btn-primary">
                Filter
            </button>

            <a href="deposits.php" class="btn btn-light">
                Reset
            </a>

        </form>

        <div class="table-wrap">

            <table>

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Customer</th>
                        <th>Amount</th>
                        <th>Payment Method</th>
                        <th>Transaction ID</th>
                        <th>Status</th>
                        <th>Submitted</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (!$deposits): ?>

                    <tr>
                        <td colspan="8" class="empty">
                            No deposit requests found.
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($deposits as $deposit): ?>

                    <tr>

                        <td>#<?= (int)$deposit['id'] ?></td>

                        <td>
                            <strong>
                                <?= h($deposit['full_name'] ?? 'Unknown customer') ?>
                            </strong>

                            <span class="sub-text">
                                @<?= h($deposit['username'] ?? '') ?>
                            </span>
                        </td>

                        <td>
                            <span class="amount">
                                <?= money($deposit['amount']) ?> ETB
                            </span>
                        </td>

                        <td>
                            <?= h($deposit['payment_method_name'] ?? 'Unknown') ?>
                        </td>

                        <td>
                            <?= h($deposit['transaction_id']) ?>
                        </td>

                        <td>
                            <span class="badge <?= h($deposit['status']) ?>">
                                <?= h($deposit['status']) ?>
                            </span>
                        </td>

                        <td>
                            <?= h($deposit['created_at']) ?>
                        </td>

                        <td>
                            <a
                                href="deposits.php?view=<?= (int)$deposit['id'] ?>"
                                class="btn btn-primary btn-small"
                            >
                                View
                            </a>
                        </td>

                    </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

</main>

</body>
</html>
