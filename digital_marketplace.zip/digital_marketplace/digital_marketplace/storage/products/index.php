
<?php

session_start();
require_once __DIR__ . '/../../config/database.php';
$pageTitle = 'Explore Products';

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$search = trim((string)($_GET['q'] ?? ''));
$sort = (string)($_GET['sort'] ?? 'newest');

$allowedSorts = [
    'newest' => 'created_at DESC, id DESC',
    'price_low' => 'price ASC, id DESC',
    'price_high' => 'price DESC, id DESC',
    'name' => 'product_name ASC'
];

$orderBy = $allowedSorts[$sort] ?? $allowedSorts['newest'];

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 9;

$where = "status = 'active'";
$params = [];

if ($search !== '') {
    $where .= " AND (product_name LIKE :search_name OR description LIKE :search_description)";
    $params['search_name'] = '%' . $search . '%';
    $params['search_description'] = '%' . $search . '%';
}

$countStmt = $pdo->prepare(
    "SELECT COUNT(*) FROM products WHERE {$where}"
);
$countStmt->execute($params);

$totalProducts = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalProducts / $perPage));

$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$listStmt = $pdo->prepare(
    "SELECT id, product_name, description, price,
            commission_rate, image_path, created_at
     FROM products
     WHERE {$where}
     ORDER BY {$orderBy}
     LIMIT :limit OFFSET :offset"
);

foreach ($params as $key => $value) {
    $listStmt->bindValue(':' . $key, $value, PDO::PARAM_STR);
}

$listStmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$listStmt->bindValue(':offset', $offset, PDO::PARAM_INT);

$listStmt->execute();
$products = $listStmt->fetchAll(PDO::FETCH_ASSOC);

function pageUrl(int $page, string $search, string $sort): string {
    return '?' . http_build_query([
        'q' => $search,
        'sort' => $sort,
        'page' => $page
    ]);
}

$isLoggedIn = !empty($_SESSION['user_id']);

$loginUrl = '../auth/login.php';
$registerUrl = '../auth/register.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= e($pageTitle) ?> | DigitalMarket</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <link href="../assets/css/style.css" rel="stylesheet">

    <style>
        body {
            background: #f5f7fb;
        }

        .market-hero {
            background: linear-gradient(120deg, #0b1d34, #1b416c);
            color: #fff;
            padding: 58px 0 48px;
        }

        .market-hero h1 {
            font-weight: 800;
            letter-spacing: -.7px;
        }

        .market-hero p {
            color: #d6e0ed;
            max-width: 620px;
        }

        .catalog-wrap {
            padding: 42px 0 70px;
        }

        .filter-panel {
            background: #fff;
            border: 1px solid #e8edf4;
            border-radius: 15px;
            padding: 16px;
            box-shadow: 0 8px 25px rgba(16,39,71,.04);
        }

        .product-card {
            height: 100%;
            background: #fff;
            border: 1px solid #e9edf3;
            border-radius: 16px;
            overflow: hidden;
            transition: .2s ease;
            box-shadow: 0 7px 24px rgba(16,39,71,.045);
        }

        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 32px rgba(16,39,71,.10);
        }

        .product-image {
            height: 190px;
            background: #edf2f8;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .product-placeholder {
            font-size: 48px;
            color: #9aaabe;
        }

        .product-body {
            padding: 20px;
        }

        .product-title {
            color: #142b49;
            font-weight: 750;
            font-size: 1.08rem;
        }

        .product-description {
            color: #68788d;
            font-size: .92rem;
            min-height: 66px;
        }

        .product-price {
            font-size: 1.25rem;
            font-weight: 800;
            color: #142b49;
        }

        .commission-pill {
            background: #edf8f2;
            color: #197447;
            font-size: .76rem;
            font-weight: 700;
            border-radius: 30px;
            padding: 6px 10px;
        }

        .btn-market {
            background: #d8aa45;
            color: #152b46;
            border: 0;
            font-weight: 700;
        }

        .btn-market:hover {
            background: #c99a35;
            color: #102747;
        }

        .empty-state {
            background: #fff;
            border: 1px dashed #cbd5e1;
            border-radius: 16px;
            padding: 55px 20px;
            text-align: center;
        }

        .site-footer {
            background: #0b1d34;
            color: #fff;
        }

        .site-footer a {
            color: #d6e0ed;
            text-decoration: none;
        }

        .site-footer a:hover {
            color: #fff;
        }

        .pagination .page-link {
            color: #17385f;
        }

        .pagination .active .page-link {
            background: #17385f;
            border-color: #17385f;
        }
    </style>
</head>

<body>

<!-- NAVIGATION -->
<nav class="navbar navbar-expand-lg navbar-dark main-navbar sticky-top">
    <div class="container">

        <a class="navbar-brand fw-bold" href="../home.php">
            <i class="bi bi-layers-fill me-2"></i>
            Digital<span>Market</span>
        </a>

        <button class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#mainNavigation">

            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNavigation">

            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">

                <li class="nav-item">
                    <a class="nav-link" href="../home.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="../about.php">About</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Products</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="../contact.php">Contact</a>
                </li>

            </ul>

            <div class="d-flex gap-2">

                <?php if ($isLoggedIn): ?>

                    <a href="../user/dashboard.php"
                       class="btn btn-outline-light btn-sm px-3">
                        My Dashboard
                    </a>

                <?php else: ?>

                    <a href="<?= e($loginUrl) ?>"
                       class="btn btn-outline-light btn-sm px-3">
                        Login
                    </a>

                    <a href="<?= e($registerUrl) ?>"
                       class="btn btn-market btn-sm px-3">
                        Get Started
                    </a>

                <?php endif; ?>

            </div>
        </div>
    </div>
</nav>


<!-- HERO -->
<section class="market-hero">
    <div class="container">

        <div class="row align-items-center g-4">

            <div class="col-lg-8">

                <span class="badge rounded-pill text-bg-light mb-3 px-3 py-2">
                    DIGITAL MARKETPLACE
                </span>

                <h1 class="display-5 mb-3">
                    Explore digital products
                </h1>

                <p class="mb-0">
                    Find useful digital resources, compare products,
                    and choose what helps you learn, create, and grow.
                </p>

            </div>

            <div class="col-lg-4 text-lg-end">

                <div class="d-inline-flex align-items-center gap-3 rounded-4 px-4 py-3"
                     style="background:rgba(255,255,255,.10)">

                    <i class="bi bi-grid-3x3-gap fs-2"
                       style="color:#e3b653"></i>

                    <div class="text-start">

                        <div class="fw-bold fs-4">
                            <?= number_format($totalProducts) ?>
                        </div>

                        <small class="text-white-50">
                            Available products
                        </small>

                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


<!-- PRODUCTS -->
<main class="catalog-wrap">

    <div class="container">

        <!-- SEARCH AND FILTER -->
        <form method="get" class="filter-panel mb-4">

            <div class="row g-3 align-items-end">

                <div class="col-lg-7">

                    <label for="q" class="form-label fw-semibold">
                        Search products
                    </label>

                    <div class="input-group">

                        <span class="input-group-text bg-white">
                            <i class="bi bi-search"></i>
                        </span>

                        <input type="search"
                               class="form-control"
                               id="q"
                               name="q"
                               value="<?= e($search) ?>"
                               placeholder="Search by product name or description...">

                    </div>
                </div>

                <div class="col-lg-3">

                    <label for="sort" class="form-label fw-semibold">
                        Sort by
                    </label>

                    <select class="form-select" id="sort" name="sort">

                        <option value="newest"
                            <?= $sort === 'newest' ? 'selected' : '' ?>>
                            Newest first
                        </option>

                        <option value="price_low"
                            <?= $sort === 'price_low' ? 'selected' : '' ?>>
                            Price: low to high
                        </option>

                        <option value="price_high"
                            <?= $sort === 'price_high' ? 'selected' : '' ?>>
                            Price: high to low
                        </option>

                        <option value="name"
                            <?= $sort === 'name' ? 'selected' : '' ?>>
                            Product name
                        </option>

                    </select>
                </div>

                <div class="col-lg-2 d-grid">

                    <button class="btn btn-market" type="submit">
                        <i class="bi bi-sliders me-1"></i>
                        Apply
                    </button>

                </div>

            </div>
        </form>


        <!-- PRODUCT HEADING -->
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">

            <div>

                <h2 class="h4 fw-bold mb-1">
                    Browse products
                </h2>

                <p class="text-secondary mb-0 small">

                    <?= $totalProducts ?>
                    product<?= $totalProducts === 1 ? '' : 's' ?> found

                    <?= $search !== '' ? ' for “' . e($search) . '”' : '' ?>

                </p>

            </div>

            <?php if ($search !== ''): ?>

                <a href="index.php"
                   class="btn btn-sm btn-outline-secondary">

                    <i class="bi bi-x-circle me-1"></i>
                    Clear search

                </a>

            <?php endif; ?>

        </div>


        <!-- EMPTY STATE -->
        <?php if (!$products): ?>

            <div class="empty-state">

                <i class="bi bi-box-seam display-4 text-secondary"></i>

                <h3 class="h5 fw-bold mt-3">
                    No products found
                </h3>

                <p class="text-secondary mb-3">

                    <?= $search !== ''
                        ? 'Try a different search term.'
                        : 'There are no active products available at the moment. Please check again later.' ?>

                </p>

                <?php if ($search !== ''): ?>

                    <a href="index.php" class="btn btn-market px-4">
                        View all products
                    </a>

                <?php endif; ?>

            </div>

        <?php else: ?>


            <!-- PRODUCT GRID -->
            <div class="row g-4">

                <?php foreach ($products as $product): ?>

                    <?php

                    $imagePath = trim((string)($product['image_path'] ?? ''));

                    $imageUrl = $imagePath !== ''
                        ? '../' . ltrim($imagePath, '/')
                        : '';

                    $description = trim(
                        strip_tags((string)($product['description'] ?? ''))
                    );

                    ?>

                    <div class="col-sm-6 col-lg-4">

                        <article class="product-card">

                            <!-- IMAGE -->
                            <div class="product-image">

                                <?php if ($imageUrl !== ''): ?>

                                    <img src="<?= e($imageUrl) ?>"
                                         alt="<?= e($product['product_name']) ?>"
                                         loading="lazy"
                                         onerror="this.style.display='none';this.nextElementSibling.style.display='block';">

                                    <i class="bi bi-file-earmark-richtext product-placeholder"
                                       style="display:none"></i>

                                <?php else: ?>

                                    <i class="bi bi-file-earmark-richtext product-placeholder"></i>

                                <?php endif; ?>

                            </div>


                            <!-- PRODUCT DETAILS -->
                            <div class="product-body">

                                <div class="d-flex justify-content-between align-items-start gap-2 mb-2">

                                    <h3 class="product-title mb-0">
                                        <?= e($product['product_name']) ?>
                                    </h3>

                                    <?php if ((float)$product['commission_rate'] > 0): ?>

                                        <span class="commission-pill">

                                            <?= number_format(
                                                (float)$product['commission_rate'],
                                                2
                                            ) ?>% commission

                                        </span>

                                    <?php endif; ?>

                                </div>


                                <p class="product-description mb-3">

                                    <?= e(
                                        $description !== ''
                                            ? mb_strimwidth($description, 0, 125, '…', 'UTF-8')
                                            : 'A digital product available in the marketplace.'
                                    ) ?>

                                </p>


                                <div class="d-flex justify-content-between align-items-center gap-2">

                                    <div>

                                        <small class="text-secondary d-block">
                                            Price
                                        </small>

                                        <div class="product-price">
                                            <?= number_format(
                                                (float)$product['price'],
                                                2
                                            ) ?>
                                        </div>

                                    </div>

                                    <?php if ($isLoggedIn): ?>

                                        <a href="../user/dashboard.php"
                                           class="btn btn-market px-3">

                                            View in account
                                            <i class="bi bi-arrow-right ms-1"></i>

                                        </a>

                                    <?php else: ?>

                                        <a href="<?= e($loginUrl) ?>"
                                           class="btn btn-market px-3">

                                            Login to buy
                                            <i class="bi bi-arrow-right ms-1"></i>

                                        </a>

                                    <?php endif; ?>

                                </div>

                            </div>

                        </article>

                    </div>

                <?php endforeach; ?>

            </div>


            <!-- PAGINATION -->
            <?php if ($totalPages > 1): ?>

                <nav class="mt-5" aria-label="Product pages">

                    <ul class="pagination justify-content-center flex-wrap">

                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">

                            <a class="page-link"
                               href="<?= e(pageUrl(max(1, $page - 1), $search, $sort)) ?>">
                                Previous
                            </a>

                        </li>

                        <?php for ($p = 1; $p <= $totalPages; $p++): ?>

                            <li class="page-item <?= $p === $page ? 'active' : '' ?>">

                                <a class="page-link"
                                   href="<?= e(pageUrl($p, $search, $sort)) ?>">
                                    <?= $p ?>
                                </a>

                            </li>

                        <?php endfor; ?>

                        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">

                            <a class="page-link"
                               href="<?= e(pageUrl(min($totalPages, $page + 1), $search, $sort)) ?>">
                                Next
                            </a>

                        </li>

                    </ul>

                </nav>

            <?php endif; ?>

        <?php endif; ?>

    </div>

</main>


<!-- FOOTER -->
<footer class="site-footer">

    <div class="container py-4">

        <div class="row align-items-center gy-3">

            <div class="col-md-6">

                <div class="fw-bold fs-5">
                    Digital<span style="color:#e3b653">Market</span>
                </div>

                <small class="text-white-50">
                    Discover digital products. Access them with ease.
                </small>

            </div>

            <div class="col-md-6 text-md-end">

                <a class="me-3" href="../home.php">Home</a>

                <a class="me-3" href="../about.php">About</a>

                <a href="../contact.php">Contact</a>

            </div>

        </div>

        <hr class="border-secondary my-3">

        <small class="text-white-50">
            &copy; <?= date('Y') ?> DigitalMarket. All rights reserved.
        </small>

    </div>

</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
