
<footer class="site-footer">
    <div class="container py-5">
        <div class="row g-4">
            <div class="col-lg-4">
                <h4 class="footer-brand">Digital<span>Market</span></h4>
                <p class="footer-text">
                    A digital marketplace where customers can discover and
                    purchase digital products, while affiliates can earn
                    commissions from qualifying referred sales.
                </p>
            </div>

            <div class="col-6 col-lg-2">
                <h6>Quick Links</h6>
                <ul class="footer-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </div>

            <div class="col-6 col-lg-3">
                <h6>Our Platform</h6>
                <ul class="footer-links">
                    <li><a href="how-it-works.php">How It Works</a></li>
                    <li><a href="auth/register.php">Create Account</a></li>
                    <li><a href="auth/login.php">Login</a></li>
                </ul>
            </div>

            <div class="col-lg-3">
                <h6>Important</h6>
                <p class="footer-text small">
                    Affiliate commissions depend on eligible completed sales
                    and the platform's applicable commission rules.
                    Earnings are not guaranteed.
                </p>
            </div>
        </div>

        <hr class="footer-divider">

        <div class="d-flex flex-column flex-md-row justify-content-between gap-2">
            <p class="footer-text mb-0">
                &copy; <?= date('Y') ?> DigitalMarket. All rights reserved.
            </p>
            <p class="footer-text mb-0">Digital products. Simple access.</p>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
