
<?php
$pageTitle = 'Home';
$activePage = 'home';
include 'includes/header.php';
?>

<!-- HERO SECTION -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-7">
                <span class="badge rounded-pill text-bg-light mb-3 px-3 py-2">
                    Welcome to DigitalMarket
                </span>

                <h1>
                    Discover Digital Products.
                    <span>Share Opportunities.</span>
                </h1>

                <p class="mt-4 mb-4">
                    Explore useful digital products in one place.
                    Purchase what you need and become an affiliate to earn
                    commissions from eligible sales you refer.
                </p>

                <div class="d-flex flex-wrap gap-3 justify-content-center justify-content-lg-start">
                    <a href="products.php" class="btn btn-gold btn-lg px-4">
                        Explore Products <i class="bi bi-arrow-right ms-2"></i>
                    </a>

                    <a href="about.php" class="btn btn-outline-light btn-lg px-4">
                        Learn More
                    </a>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="hero-visual">
                    <div class="hero-icon">
                        <i class="bi bi-laptop"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FEATURES -->
<section class="section-padding">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-heading">Everything in One Platform</h2>
            <p class="section-subtitle">
                A simple platform designed to make digital product purchasing
                and affiliate participation easier.
            </p>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="bi bi-bag-check"></i>
                    </div>
                    <h5>Digital Products</h5>
                    <p class="text-secondary mb-0">
                        Discover and purchase digital products from one
                        organized marketplace.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="bi bi-share"></i>
                    </div>
                    <h5>Affiliate Program</h5>
                    <p class="text-secondary mb-0">
                        Share your referral link and qualify for commissions
                        when eligible referred purchases are completed.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="bi bi-wallet2"></i>
                    </div>
                    <h5>Account Wallet</h5>
                    <p class="text-secondary mb-0">
                        Manage your purchase funds and approved affiliate
                        commissions separately.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- HOW IT WORKS -->
<section class="section-padding light-section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-heading">How It Works</h2>
            <p class="section-subtitle">
                Get started with a few simple steps.
            </p>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="info-card">
                    <div class="step-number">01</div>
                    <h5>Create an Account</h5>
                    <p class="text-secondary mb-0">
                        Register for an account to access marketplace
                        features and your personal dashboard.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="info-card">
                    <div class="step-number">02</div>
                    <h5>Explore and Purchase</h5>
                    <p class="text-secondary mb-0">
                        Browse available digital products and purchase
                        the products you need.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="info-card">
                    <div class="step-number">03</div>
                    <h5>Share and Refer</h5>
                    <p class="text-secondary mb-0">
                        Share your referral link. Eligible completed sales
                        may generate affiliate commissions.
                    </p>
                </div>
            </div>
        </div>

        <div class="text-center mt-5">
            <a href="how-it-works.php" class="btn btn-outline-primary px-4">
                Read Full Process
            </a>
        </div>
    </div>
</section>

<!-- CALL TO ACTION -->
<section class="cta-section">
    <div class="container text-center">
        <h2 class="fw-bold mb-3">Ready to Get Started?</h2>
        <p class="mb-4">
            Create your account and explore the digital marketplace.
        </p>
        <a href="auth/register.php" class="btn btn-gold btn-lg px-4">
            Create Your Account <i class="bi bi-arrow-right ms-2"></i>
        </a>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
