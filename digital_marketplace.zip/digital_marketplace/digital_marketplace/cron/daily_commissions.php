
<?php
/**
 * DigitalMarket - Daily Commission Processor
 *
 * Commission:
 *   5% of original purchase price per day
 *   365 days
 *
 * Execution:
 *   1. Windows Task Scheduler / Command Prompt
 *   2. Logged-in administrator through browser (POST only)
 */

date_default_timezone_set('Africa/Addis_Ababa');

$isCli = (PHP_SAPI === 'cli');
$messages = [];
$errors = [];
$processed = 0;
$skipped = 0;
$failed = 0;

function outputMessage(string $message, bool $isCli): void
{
    global $messages;

    $messages[] = $message;

    if ($isCli) {
        echo $message . PHP_EOL;
    }
}

function outputError(string $message, bool $isCli): void
{
    global $errors;

    $errors[] = $message;

    if ($isCli) {
        echo 'ERROR: ' . $message . PHP_EOL;
    }
}

/*
|--------------------------------------------------------------------------
| Browser administrator authentication
|--------------------------------------------------------------------------
*/

if (!$isCli) {
    session_start();

    if (
        !isset($_SESSION['user_id']) ||
        ($_SESSION['user_role'] ?? '') !== 'admin'
    ) {
        http_response_code(403);
        exit('Administrator access required.');
    }

    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Daily Commission Processor - DigitalMarket</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
                  rel="stylesheet">
        </head>
        <body class="bg-light">
        <div class="container py-5">
            <div class="card shadow-sm mx-auto" style="max-width:600px">
                <div class="card-body p-4">
                    <h3>Daily Commission Processor</h3>
                    <p class="text-muted">
                        This will process today's eligible daily commissions
                        and credit users' commission wallets.
                    </p>

                    <div class="alert alert-warning">
                        Each eligible schedule is paid only once per date.
                        Review your commission rules before proceeding.
                    </div>

                    <form method="POST">
                        <input type="hidden" name="csrf_token"
                               value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">

                        <button type="submit" class="btn btn-primary">
                            Process Today's Commissions
                        </button>

                        <a href="../admin/dashboard.php"
                           class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
        </body>
        </html>
        <?php
        exit;
    }

    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !hash_equals($_SESSION['csrf_token'], $submittedToken)
    ) {
        http_response_code(403);
        exit('Invalid security token. Refresh and try again.');
    }
}

/*
|--------------------------------------------------------------------------
| Database connection
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable. Check config/database.php.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$today = date('Y-m-d');

outputMessage('DigitalMarket Daily Commission Processor', $isCli);
outputMessage('Processing date: ' . $today, $isCli);
outputMessage('------------------------------------------', $isCli);

/*
|--------------------------------------------------------------------------
| Load eligible schedules
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->prepare("
        SELECT id
        FROM daily_commission_schedules
        WHERE status = 'active'
          AND start_date <= ?
          AND end_date >= ?
        ORDER BY id ASC
    ");

    $stmt->execute([$today, $today]);

    $scheduleIds = $stmt->fetchAll(PDO::FETCH_COLUMN);

} catch (Throwable $e) {
    outputError('Unable to load commission schedules: ' . $e->getMessage(), $isCli);
    $scheduleIds = [];
}

/*
|--------------------------------------------------------------------------
| Process each schedule
|--------------------------------------------------------------------------
*/

foreach ($scheduleIds as $scheduleId) {
    try {
        $pdo->beginTransaction();

        /*
         * Lock schedule to prevent simultaneous processing.
         */
        $stmt = $pdo->prepare("
            SELECT *
            FROM daily_commission_schedules
            WHERE id = ?
              AND status = 'active'
            FOR UPDATE
        ");

        $stmt->execute([(int)$scheduleId]);

        $schedule = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$schedule) {
            $pdo->commit();
            $skipped++;
            continue;
        }

        /*
         * Verify schedule dates again.
         */
        if (
            $today < $schedule['start_date'] ||
            $today > $schedule['end_date']
        ) {
            $pdo->commit();
            $skipped++;
            continue;
        }

        /*
         * Prevent duplicate daily commission.
         */
        $stmt = $pdo->prepare("
            SELECT id
            FROM daily_commission_logs
            WHERE schedule_id = ?
              AND commission_date = ?
            LIMIT 1
        ");

        $stmt->execute([
            (int)$schedule['id'],
            $today
        ]);

        if ($stmt->fetch()) {
            $pdo->commit();
            $skipped++;
            continue;
        }

        /*
         * Calculate 5% of the original purchase price.
         */
        $purchasePrice = (float)$schedule['purchase_price'];
        $dailyRate = (float)$schedule['daily_rate'];

        $amount = round(
            $purchasePrice * ($dailyRate / 100),
            2
        );

        if ($purchasePrice <= 0 || $amount <= 0) {
            throw new RuntimeException('Invalid purchase price or commission amount.');
        }

        $userId = (int)$schedule['user_id'];

        /*
         * Find and lock commission wallet.
         */
        $stmt = $pdo->prepare("
            SELECT id, balance, reserved_balance
            FROM wallet_accounts
            WHERE user_id = ?
              AND wallet_type = 'commission'
            LIMIT 1
            FOR UPDATE
        ");

        $stmt->execute([$userId]);

        $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

        /*
         * Create wallet if it does not exist.
         */
        if (!$wallet) {
            $stmt = $pdo->prepare("
                INSERT INTO wallet_accounts
                    (user_id, wallet_type, balance, reserved_balance)
                VALUES (?, 'commission', 0.00, 0.00)
            ");

            $stmt->execute([$userId]);

            $walletId = (int)$pdo->lastInsertId();
            $currentBalance = 0.00;

        } else {
            $walletId = (int)$wallet['id'];
            $currentBalance = (float)$wallet['balance'];
        }

        $newBalance = round($currentBalance + $amount, 2);

        /*
         * Credit commission wallet.
         */
        $stmt = $pdo->prepare("
            UPDATE wallet_accounts
            SET balance = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");

        $stmt->execute([
            $newBalance,
            $walletId
        ]);

        /*
         * Insert daily commission log.
         */
        $stmt = $pdo->prepare("
            INSERT INTO daily_commission_logs
                (
                    schedule_id,
                    user_id,
                    commission_date,
                    amount,
                    wallet_id,
                    balance_after
                )
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            (int)$schedule['id'],
            $userId,
            $today,
            $amount,
            $walletId,
            $newBalance
        ]);

        $logId = (int)$pdo->lastInsertId();

        /*
         * Insert wallet transaction.
         */
        $idempotencyKey = 'daily_commission_' .
            (int)$schedule['id'] . '_' . $today;

        $description = 'Daily product commission (' .
            number_format($dailyRate, 2) . '%)';

        $stmt = $pdo->prepare("
            INSERT INTO wallet_transactions
                (
                    wallet_id,
                    transaction_type,
                    amount,
                    balance_after,
                    reference_type,
                    reference_id,
                    idempotency_key,
                    description
                )
            VALUES (?, 'credit', ?, ?, 'daily_commission', ?, ?, ?)
        ");

        $stmt->execute([
            $walletId,
            $amount,
            $newBalance,
            $logId,
            $idempotencyKey,
            $description
        ]);

        /*
         * Mark completed after final earning date.
         */
        if ($today >= $schedule['end_date']) {
            $stmt = $pdo->prepare("
                UPDATE daily_commission_schedules
                SET status = 'completed'
                WHERE id = ?
            ");

            $stmt->execute([(int)$schedule['id']]);
        }

        /*
         * Commit all operations together.
         */
        $pdo->commit();

        $processed++;

        outputMessage(
            'SUCCESS: User #' . $userId .
            ' received ' . number_format($amount, 2) .
            ' ETB. Schedule #' . $scheduleId,
            $isCli
        );

    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $failed++;

        outputError(
            'Schedule #' . $scheduleId . ': ' . $e->getMessage(),
            $isCli
        );
    }
}

/*
|--------------------------------------------------------------------------
| Final summary
|--------------------------------------------------------------------------
*/

outputMessage('------------------------------------------', $isCli);
outputMessage('Processing completed.', $isCli);
outputMessage('Paid: ' . $processed, $isCli);
outputMessage('Skipped: ' . $skipped, $isCli);
outputMessage('Failed: ' . $failed, $isCli);

if (!$isCli) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Commission Processing Results</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
              rel="stylesheet">
    </head>
    <body class="bg-light">
    <div class="container py-5">
        <div class="card shadow-sm mx-auto" style="max-width:700px">
            <div class="card-body p-4">
                <h3>Daily Commission Results</h3>
                <p class="text-muted">
                    Processing date: <?= htmlspecialchars($today, ENT_QUOTES, 'UTF-8') ?>
                </p>

                <div class="row g-3 mb-4">
                    <div class="col-4">
                        <div class="alert alert-success mb-0">
                            <strong><?= $processed ?></strong><br>Paid
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="alert alert-secondary mb-0">
                            <strong><?= $skipped ?></strong><br>Skipped
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="alert alert-danger mb-0">
                            <strong><?= $failed ?></strong><br>Failed
                        </div>
                    </div>
                </div>

                <h5>Details</h5>
                <ul class="list-group mb-4">
                    <?php foreach ($messages as $message): ?>
                        <li class="list-group-item">
                            <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
                        </li>
                    <?php endforeach; ?>

                    <?php foreach ($errors as $error): ?>
                        <li class="list-group-item list-group-item-danger">
                            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <a href="../admin/dashboard.php" class="btn btn-primary">
                    Back to Admin Dashboard
                </a>
            </div>
        </div>
    </div>
    </body>
    </html>
    <?php
}
