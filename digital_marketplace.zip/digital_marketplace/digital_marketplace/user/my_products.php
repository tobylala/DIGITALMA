
<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection failed.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/* AUTHENTICATION */

$userId = (int)($_SESSION['user_id'] ?? 0);

if ($userId <= 0) {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT id, full_name, username, role, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || $user['role'] !== 'user' || $user['status'] !== 'active') {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

/* HELPERS */

function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function money($amount): string
{
    return number_format((float)$amount, 2) . ' ETB';
}

/* SEARCH */

$search = trim($_GET['search'] ?? '');

$where = ["status = 'active'"];
$params = [];

if ($search !== '') {
    $where[] = "(product_name LIKE ? OR description LIKE ?)";
    $params[] = '%' . $search . '%';
    $params[] = '%' . $search . '%';
}

$whereSQL = 'WHERE ' . implode(' AND ', $where);

/* PAGINATION */

$perPage = 12;
$page = max(1, (int)($_GET['page'] ?? 1));

$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM products
    $whereSQL
");
$stmt->execute($params);

$totalProducts = (int)$stmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalProducts / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

/* FETCH PRODUCTS */

$stmt = $pdo->prepare("
    SELECT
        id,
        product_name,
        description,
        price,
        commission_rate,
        image_path,
        created_at
    FROM products
    $whereSQL
    ORDER BY id DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);

$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

function pageUrl(int $page): string
{
    $query = $_GET;
    $query['page'] = $page;
    return '?' . http_build_query($query);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Browse Products | DigitalMarket</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
    --navy: #102747;
    --dark: #0a1b32;
    --gold: #d8aa45;
    --light: #f4f6fa;
}

body {
    background: var(--light);
    font-family: Arial, sans-serif;
}

.sidebar {
    width: 250px;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    background: var(--dark);
    padding: 24px 16px;
    color: white;
    overflow-y: auto;
}

.brand {
    font-size: 22px;
    font-weight: 800;
    color: var(--gold);
    margin-bottom: 35px;
    padding: 0 12px;
}

.sidebar a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 14px;
    color: #d9e1ec;
    text-decoration: none;
    border-radius: 8px;
    margin-bottom: 7px;
}

.sidebar a:hover,
.sidebar a.active {
    background: var(--navy);
    color: var(--gold);
}

.main {
    margin-left: 250px;
    padding: 30px;
}

.page-title {
    color: var(--navy);
    font-weight: 750;
}

.filter-box,
.product-card {
    background: white;
    border: 1px solid #e9edf3;
    border-radius: 13px;
}

.filter-box {
    padding: 18px;
    margin-bottom: 25px;
}

.product-card {
    overflow: hidden;
    height: 100%;
    transition: .2s;
}

.product-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0,0,0,.08);
}

.product-image {
    height: 190px;
    background: #edf1f6;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.no-image {
    font-size: 48px;
    color: #aab5c4;
}

.product-body {
    padding: 18px;
}

.product-name {
    font-size: 17px;
    font-weight: 700;
    color: var(--navy);
    margin: 8px 0;
}

.product-description {
    font-size: 13px;
    color: #718096;
    min-height: 42px;
}

.product-price {
    font-size: 20px;
    font-weight: 800;
    color: var(--navy);
}

.btn-market {
    background: var(--navy);
    color: white;
    border: none;
}

.btn-market:hover {
    background: var(--dark);
    color: var(--gold);
}

@media(max-width: 900px) {
    .sidebar {
        width: 75px;
        padding: 20px 10px;
    }

    .brand {
        font-size: 0;
        padding: 0;
        text-align: center;
    }

    .brand:after {
        content: "DM";
        font-size: 19px;
    }

    .sidebar a {
        justify-content: center;
        font-size: 0;
    }

    .sidebar a i {
        font-size: 21px;
    }

    .main {
        margin-left: 75px;
        padding: 20px;
    }
}

@media(max-width: 576px) {
    .main {
        padding: 15px;
    }
}
</style>
</head>

<body>

<aside class="sidebar">

    <div class="brand">
        <i class="bi bi-shop"></i> DigitalMarket
    </div>

    <a href="dashboard.php"><i class="bi bi-grid"></i> Dashboard</a>
    <a href="products.php" class="active"><i class="bi bi-bag"></i> Browse Products</a>
    
    <a href="../auth/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>

</aside>

<main class="main">

    <div class="mb-4">
        <h3 class="page-title">Digital Products</h3>
        <p class="text-secondary">
            Discover and purchase digital products from DigitalMarket.
        </p>
    </div>

    <div class="filter-box">

        <form method="GET" class="row g-3">

            <div class="col-md-9">
                <input
                    type="search"
                    name="search"
                    class="form-control"
                    placeholder="Search products..."
                    value="<?= e($search) ?>">
            </div>

            <div class="col-md-3">
                <button class="btn btn-market w-100">
                    <i class="bi bi-search me-1"></i> Search
                </button>
            </div>

        </form>

    </div>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold">Available Products</h5>
        <span class="text-secondary small">
            <?= $totalProducts ?> product(s)
        </span>
    </div>

    <div class="row g-4">

        <?php if ($products): ?>

            <?php foreach ($products as $product): ?>

                <?php
                    $image = trim((string)($product['image_path'] ?? ''));

                    $safeImage = '';

                    if (
                        $image !== '' &&
                        !preg_match('/[\x00-\x1F\x7F]/', $image) &&
                        (
                            preg_match('#^https?://#i', $image) ||
                            (
                                !preg_match('#^[a-z][a-z0-9+.-]*:#i', $image) &&
                                !str_starts_with($image, '//') &&
                                !str_contains($image, '..')
                            )
                        )
                    ) {
                        $safeImage = $image;
                    }
                ?>

                <div class="col-xl-3 col-lg-4 col-md-6">

                    <div class="product-card">

                        <div class="product-image">

                            <?php if ($safeImage !== ''): ?>

                                <img
                                    src="<?= e($safeImage) ?>"
                                    alt="<?= e($product['product_name']) ?>"
                                    onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">

                                <div class="no-image" style="display:none;">
                                    <i class="bi bi-image"></i>
                                </div>

                            <?php else: ?>

                                <div class="no-image">
                                    <i class="bi bi-image"></i>
                                </div>

                            <?php endif; ?>

                        </div>

                        <div class="product-body">

                            <div class="product-name">
                                <?= e($product['product_name']) ?>
                            </div>

                            <div class="product-description">
                                <?= e(mb_strimwidth(
                                    (string)$product['description'],
                                    0,
                                    95,
                                    '...'
                                )) ?>
                            </div>

                            <hr>

                            <div class="d-flex justify-content-between align-items-center">

                                <div class="product-price">
                                    <?= money($product['price']) ?>
                                </div>

                                <a
                                    href="product_details.php?id=<?= (int)$product['id'] ?>"
                                    class="btn btn-market btn-sm">
                                    View Details
                                </a>

                            </div>

                        </div>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="col-12">
                <div class="bg-white rounded-3 text-center p-5">

                    <i class="bi bi-bag-x display-4 text-secondary"></i>

                    <h5 class="mt-3">No Products Found</h5>

                    <p class="text-secondary">
                        No active products are currently available.
                    </p>

                    <a href="products.php" class="btn btn-market">
                        View All Products
                    </a>

                </div>
            </div>

        <?php endif; ?>

    </div>

    <?php if ($totalPages > 1): ?>

        <nav class="mt-4">
            <ul class="pagination justify-content-center">

                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="<?= e(pageUrl(max(1, $page - 1))) ?>">
                        Previous
                    </a>
                </li>

                <?php for ($i = 1; $i <= $totalPages; $i++): ?>

                    <li class="page-item <?= $page === $i ? 'active' : '' ?>">
                        <a class="page-link" href="<?= e(pageUrl($i)) ?>">
                            <?= $i ?>
                        </a>
                    </li>

                <?php endfor; ?>

                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="<?= e(pageUrl(min($totalPages, $page + 1))) ?>">
                        Next
                    </a>
                </li>

            </ul>
        </nav>

    <?php endif; ?>

    <footer class="text-center text-secondary small mt-5">
        &copy; <?= date('Y') ?> DigitalMarket. All rights reserved.
    </footer>

</main>

</body>
</html>
