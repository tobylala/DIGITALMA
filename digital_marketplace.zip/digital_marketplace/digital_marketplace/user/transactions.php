
<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection is not available.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$userId = (int)$_SESSION['user_id'];

function e($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function money($amount): string {
    return number_format((float)$amount, 2) . ' ETB';
}

function dateTime($date): string {
    return $date ? date('d M Y, h:i A', strtotime($date)) : '-';
}

function statusInfo($status): array {
    switch (strtolower((string)$status)) {
        case 'approved':
        case 'paid':
        case 'completed':
            return ['Completed', 'success'];

        case 'rejected':
        case 'cancelled':
        case 'refunded':
            return ['Rejected', 'danger'];

        case 'pending':
        case 'processing':
            return ['Processing', 'warning'];

        default:
            return [ucfirst((string)$status), 'secondary'];
    }
}

/*
|--------------------------------------------------------------------------
| USER
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT id, full_name, username, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || $user['status'] !== 'active') {
    session_destroy();
    header('Location: ../auth/login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| WALLET BALANCES
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT wallet_type, balance, reserved_balance
    FROM wallet_accounts
    WHERE user_id = ?
");
$stmt->execute([$userId]);

$wallets = [
    'purchase' => ['balance' => 0, 'reserved' => 0],
    'commission' => ['balance' => 0, 'reserved' => 0]
];

foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    if (isset($wallets[$row['wallet_type']])) {
        $wallets[$row['wallet_type']] = [
            'balance' => (float)$row['balance'],
            'reserved' => (float)$row['reserved_balance']
        ];
    }
}

$purchaseBalance = $wallets['purchase']['balance'];
$commissionBalance = $wallets['commission']['balance'];

$purchaseAvailable = max(0, $purchaseBalance - $wallets['purchase']['reserved']);
$commissionAvailable = max(0, $commissionBalance - $wallets['commission']['reserved']);

$totalBalance = $purchaseBalance + $commissionBalance;
$totalReserved = $wallets['purchase']['reserved'] + $wallets['commission']['reserved'];
$totalAvailable = $purchaseAvailable + $commissionAvailable;

/*
|--------------------------------------------------------------------------
| TOTAL CREDITED
| Actual wallet credit transactions only.
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT COALESCE(SUM(wt.amount), 0)
    FROM wallet_transactions wt
    INNER JOIN wallet_accounts wa ON wa.id = wt.wallet_id
    WHERE wa.user_id = ?
      AND wt.transaction_type = 'credit'
");
$stmt->execute([$userId]);
$totalCredited = (float)$stmt->fetchColumn();

/*
|--------------------------------------------------------------------------
| TOTAL WITHDRAWN
| Only withdrawals that have actually been paid.
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT COALESCE(SUM(amount), 0)
    FROM withdrawals
    WHERE user_id = ?
      AND status = 'paid'
");
$stmt->execute([$userId]);
$totalWithdrawn = (float)$stmt->fetchColumn();

/*
|--------------------------------------------------------------------------
| DEPOSIT HISTORY
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        d.id,
        d.amount,
        d.transaction_id,
        d.status,
        d.admin_note,
        d.created_at,
        pm.method_name
    FROM deposits d
    LEFT JOIN payment_methods pm
        ON pm.id = d.payment_method_id
    WHERE d.user_id = ?
    ORDER BY d.created_at DESC, d.id DESC
    LIMIT 50
");
$stmt->execute([$userId]);
$deposits = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| WITHDRAWAL HISTORY
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        w.id,
        w.wallet_type,
        w.amount,
        w.account_details,
        w.status,
        w.admin_note,
        w.payment_reference,
        w.paid_at,
        w.created_at,
        pm.method_name
    FROM withdrawals w
    LEFT JOIN payment_methods pm
        ON pm.id = w.payment_method_id
    WHERE w.user_id = ?
    ORDER BY w.created_at DESC, w.id DESC
    LIMIT 50
");
$stmt->execute([$userId]);
$withdrawals = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| RECENT WALLET ACTIVITY
|--------------------------------------------------------------------------
*/

$search = trim($_GET['search'] ?? '');
$typeFilter = trim($_GET['type'] ?? '');
$walletFilter = trim($_GET['wallet'] ?? '');

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$offset = ($page - 1) * $perPage;

$where = ['wa.user_id = ?'];
$params = [$userId];

if ($search !== '') {
    $where[] = "(
        wt.description LIKE ?
        OR wt.reference_type LIKE ?
        OR CAST(wt.reference_id AS CHAR) LIKE ?
    )";

    $term = '%' . $search . '%';
    array_push($params, $term, $term, $term);
}

if (in_array($typeFilter, ['credit', 'debit', 'reserve', 'release'], true)) {
    $where[] = 'wt.transaction_type = ?';
    $params[] = $typeFilter;
}

if (in_array($walletFilter, ['purchase', 'commission'], true)) {
    $where[] = 'wa.wallet_type = ?';
    $params[] = $walletFilter;
}

$whereSql = implode(' AND ', $where);

$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM wallet_transactions wt
    INNER JOIN wallet_accounts wa ON wa.id = wt.wallet_id
    WHERE $whereSql
");
$stmt->execute($params);

$totalRows = (int)$stmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalRows / $perPage));

$stmt = $pdo->prepare("
    SELECT
        wt.id,
        wt.transaction_type,
        wt.amount,
        wt.balance_after,
        wt.reference_type,
        wt.reference_id,
        wt.description,
        wt.created_at,
        wa.wallet_type
    FROM wallet_transactions wt
    INNER JOIN wallet_accounts wa ON wa.id = wt.wallet_id
    WHERE $whereSql
    ORDER BY wt.created_at DESC, wt.id DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

function pageUrl($pageNumber): string {
    $query = $_GET;
    $query['page'] = $pageNumber;
    return '?' . http_build_query($query);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>My Transactions | DigitalMarket</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>
:root {
    --navy: #102b50;
    --blue: #1768ac;
    --green: #168653;
    --red: #d44754;
    --muted: #7b8798;
    --border: #e8edf3;
    --background: #f4f7fb;
}

* { box-sizing: border-box; }

body {
    margin: 0;
    background: var(--background);
    color: #26364a;
    font-family: Inter, sans-serif;
    font-size: 13px;
}

.sidebar {
    position: fixed;
    inset: 0 auto 0 0;
    width: 250px;
    padding: 24px 17px;
    color: white;
    background: linear-gradient(180deg,#102b50,#0b1e38);
    z-index: 1000;
}

.brand {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 0 8px 25px;
    border-bottom: 1px solid #ffffff20;
    margin-bottom: 23px;
}

.brand-icon {
    width: 43px;
    height: 43px;
    border-radius: 12px;
    background: #d6a943;
    color: #102b50;
    display: grid;
    place-items: center;
    font-size: 23px;
}

.brand-name { font-size: 17px; font-weight: 800; }
.brand-sub { font-size: 9px; color: #b9c9dc; margin-top: 3px; }

.nav-label {
    color: #91a9c4;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1px;
    padding: 12px;
}

.side-link {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 12px;
    margin: 4px 0;
    border-radius: 8px;
    color: #d5e0ed;
    text-decoration: none;
    font-weight: 500;
}

.side-link i { font-size: 17px; }

.side-link:hover,
.side-link.active {
    color: white;
    background: #ffffff19;
}

.side-link.active { border-left: 3px solid #d6a943; }

.main { margin-left: 250px; min-height: 100vh; }

.topbar {
    height: 72px;
    background: white;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 30px;
}

.topbar-title { font-size: 15px; font-weight: 800; color: var(--navy); }

.profile {
    display: flex;
    align-items: center;
    gap: 10px;
}

.avatar {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: #eaf3fb;
    color: var(--navy);
    display: grid;
    place-items: center;
    font-weight: 800;
}

.content {
    max-width: 1450px;
    padding: 27px;
    margin: auto;
}

.heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
    margin-bottom: 22px;
}

.heading h2 {
    color: var(--navy);
    font-size: 23px;
    font-weight: 800;
    margin: 0 0 6px;
}

.heading p { color: var(--muted); margin: 0; }

.print-btn {
    background: white;
    color: var(--navy);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 10px 15px;
    font-weight: 700;
    font-size: 12px;
}

.balance-card {
    background: linear-gradient(115deg,#102b50,#1768ac);
    color: white;
    border-radius: 16px;
    padding: 25px;
    margin-bottom: 20px;
    position: relative;
    overflow: hidden;
}

.balance-card:after {
    content: "";
    position: absolute;
    width: 240px;
    height: 240px;
    border: 35px solid #ffffff10;
    border-radius: 50%;
    right: -60px;
    top: -125px;
}

.balance-label {
    color: #d8e6f5;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: .7px;
}

.balance-amount {
    font-size: 32px;
    font-weight: 800;
    margin: 8px 0 22px;
}

.balance-bottom {
    display: flex;
    flex-wrap: wrap;
    gap: 35px;
}

.balance-bottom small {
    display: block;
    color: #d8e6f5;
    font-size: 10px;
    margin-bottom: 5px;
}

.balance-bottom strong { font-size: 14px; }

.stats {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 15px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 19px;
    display: flex;
    align-items: center;
    gap: 13px;
    min-width: 0;
}

.stat-icon {
    width: 45px;
    height: 45px;
    border-radius: 12px;
    display: grid;
    place-items: center;
    font-size: 21px;
    flex-shrink: 0;
}

.stat-icon.credit { background: #e7f6ee; color: var(--green); }
.stat-icon.withdraw { background: #fdebed; color: var(--red); }
.stat-icon.available { background: #eaf3fb; color: var(--blue); }

.stat-card small {
    display: block;
    color: var(--muted);
    font-size: 10px;
    margin-bottom: 6px;
}

.stat-card strong {
    display: block;
    font-size: 17px;
    font-weight: 800;
    color: var(--navy);
    overflow-wrap: anywhere;
}

.section {
    background: white;
    border: 1px solid var(--border);
    border-radius: 12px;
    margin-bottom: 22px;
    overflow: hidden;
}

.section-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 18px 20px;
    border-bottom: 1px solid var(--border);
    gap: 12px;
    flex-wrap: wrap;
}

.section-head h5 {
    color: var(--navy);
    font-weight: 800;
    font-size: 14px;
    margin: 0;
}

.section-head p {
    color: var(--muted);
    font-size: 11px;
    margin: 4px 0 0;
}

.section-icon {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    display: grid;
    place-items: center;
    font-size: 18px;
}

.section-title {
    display: flex;
    align-items: center;
    gap: 11px;
}

.credit-bg { background: #e7f6ee; color: var(--green); }
.withdraw-bg { background: #fdebed; color: var(--red); }
.blue-bg { background: #eaf3fb; color: var(--blue); }

.table-responsive { width: 100%; }

.bank-table {
    width: 100%;
    border-collapse: collapse;
    white-space: nowrap;
}

.bank-table th {
    background: #f8fafc;
    padding: 13px 17px;
    text-align: left;
    color: #7b8798;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: .5px;
    border-bottom: 1px solid var(--border);
}

.bank-table td {
    padding: 14px 17px;
    border-bottom: 1px solid #edf0f4;
    font-size: 12px;
    vertical-align: middle;
}

.bank-table tbody tr:hover { background: #fafcff; }
.bank-table tbody tr:last-child td { border-bottom: 0; }

.ref {
    font-weight: 800;
    color: var(--navy);
}

.sub {
    display: block;
    color: var(--muted);
    font-size: 10px;
    margin-top: 4px;
}

.amount {
    font-size: 13px;
    font-weight: 800;
    white-space: nowrap;
}

.amount.credit { color: var(--green); }
.amount.debit { color: var(--red); }

.status {
    display: inline-flex;
    padding: 6px 9px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 800;
}

.status.success { background: #e7f6ee; color: var(--green); }
.status.warning { background: #fff5df; color: #a36b08; }
.status.danger { background: #fdebed; color: var(--red); }
.status.secondary { background: #eef1f5; color: #64748b; }

.empty {
    padding: 35px 20px;
    text-align: center;
    color: var(--muted);
}

.empty i {
    display: block;
    font-size: 32px;
    margin-bottom: 9px;
    color: #b5c3d3;
}

.filter {
    padding: 16px 18px;
    background: #fbfcfe;
    border-bottom: 1px solid var(--border);
}

.form-control, .form-select {
    font-size: 12px;
    padding: 10px 12px;
    border-color: #dce3ec;
}

.btn-search {
    background: var(--navy);
    color: white;
    border: 0;
    border-radius: 7px;
    padding: 10px 15px;
    font-size: 12px;
    font-weight: 700;
}

.btn-search:hover { background: var(--blue); color: white; }

.pagination-area {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 18px;
    border-top: 1px solid var(--border);
    flex-wrap: wrap;
    gap: 10px;
}

.pagination-area a {
    display: inline-block;
    text-decoration: none;
    color: var(--navy);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 7px 10px;
    margin-left: 3px;
    font-size: 11px;
}

.pagination-area a.current {
    color: white;
    background: var(--navy);
}

.footer {
    text-align: center;
    color: #8b98a8;
    font-size: 10px;
    padding: 15px;
}

.mobile-menu {
    display: none;
    background: none;
    border: 0;
    color: var(--navy);
    font-size: 23px;
}

@media(max-width:1100px) {
    .stats { grid-template-columns: repeat(2,1fr); }
}

@media(max-width:768px) {
    .sidebar { display: none; }
    .main { margin-left: 0; }
    .mobile-menu { display: block; }
    .topbar { padding: 0 14px; }
    .content { padding: 18px 12px; }
    .stats { grid-template-columns: 1fr; gap: 10px; }
    .balance-card { padding: 21px; }
    .balance-amount { font-size: 27px; }
    .balance-bottom { gap: 22px; }
    .heading h2 { font-size: 20px; }
}

@media print {
    .sidebar, .topbar, .filter, .pagination-area, .no-print, .footer {
        display: none !important;
    }
    .main { margin: 0; }
    .content { padding: 0; }
    body { background: white; }
}
</style>
</head>

<body>

<aside class="sidebar">
    <div class="brand">
        <div class="brand-icon"><i class="bi bi-bank2"></i></div>
        <div>
            <div class="brand-name">DigitalMarket</div>
            <div class="brand-sub">DIGITAL FINANCIAL SERVICES</div>
        </div>
    </div>

    <div class="nav-label">MAIN MENU</div>
    <a href="dashboard.php" class="side-link"><i class="bi bi-grid"></i> Dashboard</a>
    <a href="products.php" class="side-link"><i class="bi bi-bag"></i> Products</a>
    <a href="orders.php" class="side-link"><i class="bi bi-receipt"></i> My Orders</a>

    <div class="nav-label">FINANCIAL SERVICES</div>
    <a href="wallet.php" class="side-link"><i class="bi bi-wallet2"></i> My Wallet</a>
    <a href="deposits.php" class="side-link"><i class="bi bi-arrow-down-circle"></i> Deposit</a>
    <a href="withdraw.php" class="side-link"><i class="bi bi-arrow-up-circle"></i> Withdraw</a>
    <a href="transactions.php" class="side-link active"><i class="bi bi-clock-history"></i> Transactions</a>
    <a href="commissions.php" class="side-link"><i class="bi bi-graph-up-arrow"></i> Commissions</a>

    <div class="nav-label">ACCOUNT</div>
    <a href="profile.php" class="side-link"><i class="bi bi-person"></i> My Profile</a>
    <a href="../auth/logout.php" class="side-link"><i class="bi bi-box-arrow-left"></i> Logout</a>
</aside>

<main class="main">

    <header class="topbar">
        <div class="d-flex align-items-center gap-3">
            <button class="mobile-menu" onclick="toggleSidebar()">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-title">My Account Activity</div>
        </div>

        <div class="profile">
            <div class="text-end">
                <strong style="font-size:12px;color:#102b50"><?= e($user['full_name']) ?></strong>
                <div style="font-size:10px;color:#8491a2">DigitalMarket Account</div>
            </div>
            <div class="avatar"><?= e(strtoupper(substr($user['full_name'], 0, 1))) ?></div>
        </div>
    </header>

    <div class="content">

        <div class="heading">
            <div>
                <h2>Transactions</h2>
                <p>Monitor your credited funds, withdrawals and account activity.</p>
            </div>
            <button class="print-btn no-print" onclick="window.print()">
                <i class="bi bi-printer me-1"></i> Print Statement
            </button>
        </div>

        <!-- BALANCE -->
        <div class="balance-card">
            <div class="balance-label">
                <i class="bi bi-shield-check me-1"></i>
                TOTAL WALLET BALANCE
            </div>

            <div class="balance-amount"><?= money($totalBalance) ?></div>

            <div class="balance-bottom">
                <div>
                    <small>Available Balance</small>
                    <strong><?= money($totalAvailable) ?></strong>
                </div>

                <div>
                    <small>Reserved Balance</small>
                    <strong><?= money($totalReserved) ?></strong>
                </div>

                <div>
                    <small>Purchase Wallet</small>
                    <strong><?= money($purchaseAvailable) ?></strong>
                </div>

                <div>
                    <small>Commission Wallet</small>
                    <strong><?= money($commissionAvailable) ?></strong>
                </div>
            </div>
        </div>

        <!-- CREDIT / WITHDRAWN / AVAILABLE -->
        <div class="stats">

            <div class="stat-card">
                <div class="stat-icon credit">
                    <i class="bi bi-arrow-down-left"></i>
                </div>
                <div>
                    <small>TOTAL CREDITED</small>
                    <strong><?= money($totalCredited) ?></strong>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon withdraw">
                    <i class="bi bi-arrow-up-right"></i>
                </div>
                <div>
                    <small>TOTAL WITHDRAWN</small>
                    <strong><?= money($totalWithdrawn) ?></strong>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon available">
                    <i class="bi bi-wallet2"></i>
                </div>
                <div>
                    <small>AVAILABLE BALANCE</small>
                    <strong><?= money($totalAvailable) ?></strong>
                </div>
            </div>

        </div>

        <!-- DEPOSITS -->
        <section class="section">
            <div class="section-head">
                <div class="section-title">
                    <div class="section-icon credit-bg">
                        <i class="bi bi-arrow-down-left"></i>
                    </div>
                    <div>
                        <h5>Money Credited / Deposits</h5>
                        <p>Your deposit requests and their approval status</p>
                    </div>
                </div>
                <span class="text-secondary small"><?= count($deposits) ?> recent records</span>
            </div>

            <?php if (!$deposits): ?>
                <div class="empty">
                    <i class="bi bi-inbox"></i>
                    No deposit records available.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="bank-table">
                        <thead>
                            <tr>
                                <th>Transaction</th>
                                <th>Payment Method</th>
                                <th>Transaction ID</th>
                                <th>Date</th>
                                <th>Credited Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($deposits as $d):
                            [$label, $color] = statusInfo($d['status']);
                        ?>
                            <tr>
                                <td>
                                    <span class="ref">Deposit #<?= (int)$d['id'] ?></span>
                                    <span class="sub">Account deposit</span>
                                </td>
                                <td><?= e($d['method_name'] ?: 'Payment method') ?></td>
                                <td><?= e($d['transaction_id']) ?></td>
                                <td><?= dateTime($d['created_at']) ?></td>
                                <td>
                                    <span class="amount credit">
                                        + <?= money($d['amount']) ?>
                                    </span>
                                </td>
                                <td><span class="status <?= e($color) ?>"><?= e($label) ?></span></td>
                            </tr>
                            <?php if (!empty($d['admin_note'])): ?>
                            <tr>
                                <td colspan="6" style="background:#fbfcfe;color:#718096">
                                    <strong>Admin note:</strong> <?= e($d['admin_note']) ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

        <!-- WITHDRAWALS -->
        <section class="section">
            <div class="section-head">
                <div class="section-title">
                    <div class="section-icon withdraw-bg">
                        <i class="bi bi-arrow-up-right"></i>
                    </div>
                    <div>
                        <h5>Money Withdrawn</h5>
                        <p>Your withdrawal requests, payment progress and completed payments</p>
                    </div>
                </div>
                <span class="text-secondary small"><?= count($withdrawals) ?> recent records</span>
            </div>

            <?php if (!$withdrawals): ?>
                <div class="empty">
                    <i class="bi bi-wallet2"></i>
                    No withdrawal records available.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="bank-table">
                        <thead>
                            <tr>
                                <th>Transaction</th>
                                <th>Wallet</th>
                                <th>Payment Method</th>
                                <th>Request Date</th>
                                <th>Withdrawn Amount</th>
                                <th>Status</th>
                                <th>Paid Date</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($withdrawals as $w):
                            [$label, $color] = statusInfo($w['status']);
                        ?>
                            <tr>
                                <td>
                                    <span class="ref">Withdrawal #<?= (int)$w['id'] ?></span>
                                    <span class="sub"><?= e($w['payment_reference'] ?: 'Payment request') ?></span>
                                </td>
                                <td><?= e(ucfirst($w['wallet_type'])) ?></td>
                                <td><?= e($w['method_name'] ?: 'Payment method') ?></td>
                                <td><?= dateTime($w['created_at']) ?></td>
                                <td>
                                    <span class="amount debit">
                                        - <?= money($w['amount']) ?>
                                    </span>
                                </td>
                                <td><span class="status <?= e($color) ?>"><?= e($label) ?></span></td>
                                <td><?= dateTime($w['paid_at']) ?></td>
                            </tr>
                            <?php if (!empty($w['admin_note'])): ?>
                            <tr>
                                <td colspan="7" style="background:#fbfcfe;color:#718096">
                                    <strong>Admin note:</strong> <?= e($w['admin_note']) ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

        <!-- ACCOUNT ACTIVITY -->
        <section class="section">
            <div class="section-head">
                <div class="section-title">
                    <div class="section-icon blue-bg">
                        <i class="bi bi-journal-text"></i>
                    </div>
                    <div>
                        <h5>Account Activity</h5>
                        <p>Detailed wallet statement with credited and debited amounts</p>
                    </div>
                </div>
            </div>

            <div class="filter no-print">
                <form method="GET" class="row g-2">
                    <div class="col-lg-5">
                        <input
                            type="text"
                            name="search"
                            class="form-control"
                            placeholder="Search transaction description or reference"
                            value="<?= e($search) ?>"
                        >
                    </div>

                    <div class="col-lg-2">
                        <select name="type" class="form-select">
                            <option value="">All transactions</option>
                            <option value="credit" <?= $typeFilter === 'credit' ? 'selected' : '' ?>>Credited</option>
                            <option value="debit" <?= $typeFilter === 'debit' ? 'selected' : '' ?>>Debited</option>
                            <option value="reserve" <?= $typeFilter === 'reserve' ? 'selected' : '' ?>>Reserved</option>
                            <option value="release" <?= $typeFilter === 'release' ? 'selected' : '' ?>>Released</option>
                        </select>
                    </div>

                    <div class="col-lg-2">
                        <select name="wallet" class="form-select">
                            <option value="">All wallets</option>
                            <option value="purchase" <?= $walletFilter === 'purchase' ? 'selected' : '' ?>>Purchase</option>
                            <option value="commission" <?= $walletFilter === 'commission' ? 'selected' : '' ?>>Commission</option>
                        </select>
                    </div>

                    <div class="col-lg-3 d-flex gap-2">
                        <button class="btn-search flex-grow-1">
                            <i class="bi bi-search me-1"></i> Search
                        </button>
                        <a href="transactions.php" class="btn btn-light border">
                            <i class="bi bi-arrow-counterclockwise"></i>
                        </a>
                    </div>
                </form>
            </div>

            <?php if (!$transactions): ?>
                <div class="empty">
                    <i class="bi bi-journal-x"></i>
                    No wallet activity found.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="bank-table">
                        <thead>
                            <tr>
                                <th>Transaction ID</th>
                                <th>Description</th>
                                <th>Wallet</th>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Balance After</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($transactions as $t):
                            $type = $t['transaction_type'];

                            if ($type === 'credit') {
                                $amountClass = 'credit';
                                $sign = '+';
                                $label = 'Credited';
                            } elseif ($type === 'debit') {
                                $amountClass = 'debit';
                                $sign = '-';
                                $label = 'Debited';
                            } elseif ($type === 'reserve') {
                                $amountClass = 'debit';
                                $sign = '-';
                                $label = 'Reserved';
                            } else {
                                $amountClass = 'credit';
                                $sign = '+';
                                $label = 'Released';
                            }
                        ?>
                            <tr>
                                <td>
                                    <span class="ref">
                                        TXN-<?= str_pad((string)$t['id'], 7, '0', STR_PAD_LEFT) ?>
                                    </span>
                                </td>
                                <td>
                                    <?= e($t['description'] ?: $label) ?>
                                    <span class="sub">
                                        <?= e(ucfirst($t['reference_type'])) ?>
                                        <?= $t['reference_id'] ? '#' . (int)$t['reference_id'] : '' ?>
                                    </span>
                                </td>
                                <td><?= e(ucfirst($t['wallet_type'])) ?></td>
                                <td><?= dateTime($t['created_at']) ?></td>
                                <td>
                                    <span class="amount <?= $amountClass ?>">
                                        <?= $sign ?> <?= money($t['amount']) ?>
                                    </span>
                                    <span class="sub"><?= e($label) ?></span>
                                </td>
                                <td>
                                    <strong><?= money($t['balance_after']) ?></strong>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="pagination-area">
                    <span class="text-secondary small">
                        Showing <?= count($transactions) ?> of <?= $totalRows ?> transactions
                    </span>

                    <div>
                        <?php if ($page > 1): ?>
                            <a href="<?= e(pageUrl($page - 1)) ?>">
                                <i class="bi bi-chevron-left"></i>
                            </a>
                        <?php endif; ?>

                        <?php
                        $start = max(1, $page - 2);
                        $end = min($totalPages, $page + 2);
                        for ($i = $start; $i <= $end; $i++):
                        ?>
                            <a href="<?= e(pageUrl($i)) ?>"
                               class="<?= $i === $page ? 'current' : '' ?>">
                                <?= $i ?>
                            </a>
                        <?php endfor; ?>

                        <?php if ($page < $totalPages): ?>
                            <a href="<?= e(pageUrl($page + 1)) ?>">
                                <i class="bi bi-chevron-right"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </section>

        <div class="footer">
            © <?= date('Y') ?> DigitalMarket · Secure Account Activity
        </div>

    </div>
</main>

<script>
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');

    if (sidebar.style.display === 'block') {
        sidebar.style.display = 'none';
    } else {
        sidebar.style.display = 'block';
        sidebar.style.position = 'fixed';
        sidebar.style.width = '250px';
        sidebar.style.zIndex = '2000';
        sidebar.style.boxShadow = '5px 0 20px rgba(0,0,0,.2)';
    }
}
</script>

</body>
</html>
