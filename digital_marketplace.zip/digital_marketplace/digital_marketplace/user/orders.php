
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection failed.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/* =========================================
   AUTHENTICATION
========================================= */

$userId = (int)($_SESSION['user_id'] ?? 0);

if ($userId <= 0) {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT id, full_name, username, role, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$userId]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (
    !$user ||
    $user['role'] !== 'user' ||
    $user['status'] !== 'active'
) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

/* =========================================
   HELPER FUNCTIONS
========================================= */

function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function money($amount): string
{
    return number_format((float)$amount, 2) . ' ETB';
}

function statusBadge($status): string
{
    $classes = [
        'pending'   => 'warning',
        'completed' => 'success',
        'cancelled' => 'secondary',
        'refunded'  => 'info'
    ];

    $status = strtolower((string)$status);
    $class = $classes[$status] ?? 'secondary';

    return '<span class="badge bg-' . $class . '">' .
        e(ucfirst($status)) .
        '</span>';
}

function paymentBadge($status): string
{
    $classes = [
        'pending'  => 'warning',
        'paid'     => 'success',
        'failed'   => 'danger',
        'refunded' => 'info'
    ];

    $status = strtolower((string)$status);
    $class = $classes[$status] ?? 'secondary';

    return '<span class="badge bg-' . $class . '">' .
        e(ucfirst($status)) .
        '</span>';
}

/* =========================================
   SEARCH AND FILTER
========================================= */

$search = trim($_GET['search'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');

$allowedStatuses = [
    'pending',
    'completed',
    'cancelled',
    'refunded'
];

$where = ["o.user_id = ?"];
$params = [$userId];

if ($search !== '') {
    $where[] = "o.order_number LIKE ?";
    $params[] = '%' . $search . '%';
}

if (in_array($statusFilter, $allowedStatuses, true)) {
    $where[] = "o.status = ?";
    $params[] = $statusFilter;
}

$whereSQL = implode(' AND ', $where);

/* =========================================
   ORDER STATISTICS
========================================= */

$stmt = $pdo->prepare("
    SELECT
        COUNT(*) AS total_orders,

        SUM(
            CASE WHEN status = 'pending'
            THEN 1 ELSE 0 END
        ) AS pending_orders,

        SUM(
            CASE WHEN status = 'completed'
            THEN 1 ELSE 0 END
        ) AS completed_orders,

        SUM(
            CASE WHEN status = 'cancelled'
            THEN 1 ELSE 0 END
        ) AS cancelled_orders,

        COALESCE(
            SUM(
                CASE WHEN status = 'completed'
                THEN total_amount ELSE 0 END
            ), 0
        ) AS total_spent

    FROM orders
    WHERE user_id = ?
");

$stmt->execute([$userId]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

/* =========================================
   PAGINATION
========================================= */

$perPage = 10;

$page = max(1, (int)($_GET['page'] ?? 1));

$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM orders o
    WHERE $whereSQL
");

$stmt->execute($params);

$totalOrders = (int)$stmt->fetchColumn();

$totalPages = max(
    1,
    (int)ceil($totalOrders / $perPage)
);

$page = min($page, $totalPages);

$offset = ($page - 1) * $perPage;

/* =========================================
   FETCH ORDERS
========================================= */

$sql = "
    SELECT
        o.id,
        o.order_number,
        o.product_id,
        o.quantity,
        o.unit_price,
        o.total_amount,
        o.payment_method,
        o.payment_status,
        o.status,
        o.created_at,
        o.completed_at,

        p.product_name AS product_name

    FROM orders o

    LEFT JOIN products p
        ON p.id = o.product_id

    WHERE $whereSQL

    ORDER BY o.created_at DESC

    LIMIT $perPage OFFSET $offset
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================================
   PAGINATION URL
========================================= */

function pageUrl($page): string
{
    $query = $_GET;
    $query['page'] = $page;

    return '?' . http_build_query($query);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>My Orders | DigitalMarket</title>

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet">

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
    rel="stylesheet">

<style>

:root {
    --navy: #102747;
    --dark: #0a1b32;
    --gold: #d8aa45;
    --light: #f4f6fa;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: var(--light);
    font-family: Arial, sans-serif;
}

/* SIDEBAR */

.sidebar {
    width: 250px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    background: var(--dark);
    padding: 24px 16px;
    color: white;
    overflow-y: auto;
    z-index: 1000;
}

.brand {
    font-size: 21px;
    font-weight: 800;
    color: var(--gold);
    margin-bottom: 35px;
    padding: 0 10px;
}

.sidebar a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 14px;
    color: #d9e1ec;
    text-decoration: none;
    border-radius: 8px;
    margin-bottom: 7px;
    transition: .2s;
}

.sidebar a:hover,
.sidebar a.active {
    background: var(--navy);
    color: var(--gold);
}

.sidebar a i {
    font-size: 18px;
}

/* MAIN CONTENT */

.main {
    margin-left: 250px;
    padding: 30px;
}

.page-title {
    color: var(--navy);
    font-weight: 750;
}

/* STATISTICS */

.stat-card {
    background: white;
    padding: 20px;
    border-radius: 12px;
    border: 1px solid #e8edf4;
    height: 100%;
}

.stat-icon {
    width: 45px;
    height: 45px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 21px;
    background: #edf2f9;
    color: var(--navy);
}

.stat-number {
    font-size: 24px;
    font-weight: 800;
    color: var(--navy);
    margin-top: 12px;
}

.stat-label {
    color: #778397;
    font-size: 13px;
}

/* FILTER */

.filter-box {
    background: white;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 22px;
    border: 1px solid #e8edf4;
}

/* TABLE */

.table-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    border: 1px solid #e8edf4;
}

.table thead th {
    background: #f5f7fa;
    color: var(--navy);
    font-size: 13px;
    white-space: nowrap;
}

.table tbody td {
    vertical-align: middle;
    font-size: 14px;
}

.order-number {
    font-weight: 700;
    color: var(--navy);
}

.btn-market {
    background: var(--navy);
    color: white;
    border: none;
}

.btn-market:hover {
    background: var(--dark);
    color: var(--gold);
}

.empty-state {
    padding: 55px 20px;
    text-align: center;
}

.empty-state i {
    font-size: 55px;
    color: #b6c0ce;
}

/* RESPONSIVE */

@media(max-width: 900px) {

    .sidebar {
        width: 75px;
        padding: 20px 10px;
    }

    .brand {
        font-size: 0;
        text-align: center;
        padding: 0;
    }

    .brand:after {
        content: "DM";
        font-size: 19px;
    }

    .sidebar a {
        justify-content: center;
        font-size: 0;
        padding: 13px 5px;
    }

    .sidebar a i {
        font-size: 21px;
    }

    .main {
        margin-left: 75px;
        padding: 20px;
    }
}

@media(max-width: 576px) {

    .main {
        padding: 14px;
    }

    .stat-number {
        font-size: 20px;
    }

    .table-card {
        padding: 12px;
    }
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<aside class="sidebar">

    <div class="brand">
        <i class="bi bi-shop"></i>
        DigitalMarket
    </div>

    <a href="dashboard.php">
        <i class="bi bi-grid"></i>
        Dashboard
    </a>

    <a href="orders.php" class="active">
        <i class="bi bi-cart"></i>
        My Orders
    </a>

    
    <hr class="border-secondary">

    <a href="../auth/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        Logout
    </a>

</aside>

<!-- MAIN CONTENT -->

<main class="main">

    <!-- HEADER -->

    <div class="mb-4">

        <h3 class="page-title">
            My Orders
        </h3>

        <p class="text-secondary">
            View and track your digital product purchases.
        </p>

    </div>

    <!-- STATISTICS -->

    <div class="row g-3 mb-4">

        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="stat-icon">
                    <i class="bi bi-cart"></i>
                </div>

                <div class="stat-number">
                    <?= number_format((int)($stats['total_orders'] ?? 0)) ?>
                </div>

                <div class="stat-label">
                    Total Orders
                </div>

            </div>

        </div>

        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="stat-icon">
                    <i class="bi bi-clock-history"></i>
                </div>

                <div class="stat-number">
                    <?= number_format((int)($stats['pending_orders'] ?? 0)) ?>
                </div>

                <div class="stat-label">
                    Pending Orders
                </div>

            </div>

        </div>

        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="stat-icon">
                    <i class="bi bi-check-circle"></i>
                </div>

                <div class="stat-number">
                    <?= number_format((int)($stats['completed_orders'] ?? 0)) ?>
                </div>

                <div class="stat-label">
                    Completed Orders
                </div>

            </div>

        </div>

        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="stat-icon">
                    <i class="bi bi-wallet2"></i>
                </div>

                <div class="stat-number">
                    <?= money($stats['total_spent'] ?? 0) ?>
                </div>

                <div class="stat-label">
                    Total Completed Spending
                </div>

            </div>

        </div>

    </div>

    <!-- SEARCH AND FILTER -->

    <div class="filter-box">

        <form method="GET" class="row g-3">

            <div class="col-lg-6">

                <label class="form-label fw-semibold">
                    Search Order
                </label>

                <input
                    type="search"
                    name="search"
                    class="form-control"
                    placeholder="Enter order number..."
                    value="<?= e($search) ?>">

            </div>

            <div class="col-lg-3">

                <label class="form-label fw-semibold">
                    Order Status
                </label>

                <select name="status" class="form-select">

                    <option value="">All Statuses</option>

                    <?php foreach ($allowedStatuses as $status): ?>

                        <option
                            value="<?= e($status) ?>"
                            <?= $statusFilter === $status ? 'selected' : '' ?>>

                            <?= e(ucfirst($status)) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <div class="col-lg-3 d-flex align-items-end gap-2">

                <button type="submit" class="btn btn-market flex-grow-1">
                    <i class="bi bi-search me-1"></i>
                    Search
                </button>

                <a href="orders.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-counterclockwise"></i>
                </a>

            </div>

        </form>

    </div>

    <!-- ORDERS TABLE -->

    <div class="table-card">

        <div class="d-flex justify-content-between align-items-center mb-3">

            <h5 class="fw-bold mb-0">
                Order History
            </h5>

            <span class="text-secondary small">
                <?= $totalOrders ?> result(s)
            </span>

        </div>

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>

                    <tr>
                        <th>Order Number</th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total Amount</th>
                        <th>Payment</th>
                        <th>Order Status</th>
                        <th>Date</th>
                    </tr>

                </thead>

                <tbody>

                    <?php if (!empty($orders)): ?>

                        <?php foreach ($orders as $order): ?>

                            <tr>

                                <td>
                                    <span class="order-number">
                                        <?= e($order['order_number']) ?>
                                    </span>
                                </td>

                                <td>
                                    <?= e(
                                        $order['product_name']
                                        ?: 'Product no longer available'
                                    ) ?>
                                </td>

                                <td>
                                    <?= number_format((int)$order['quantity']) ?>
                                </td>

                                <td>
                                    <?= money($order['unit_price']) ?>
                                </td>

                                <td class="fw-bold">
                                    <?= money($order['total_amount']) ?>
                                </td>

                                <td>
                                    <div class="small mb-1">
                                        <?= e(ucfirst(
                                            str_replace(
                                                '_',
                                                ' ',
                                                (string)$order['payment_method']
                                            )
                                        )) ?>
                                    </div>

                                    <?= paymentBadge($order['payment_status']) ?>
                                </td>

                                <td>
                                    <?= statusBadge($order['status']) ?>
                                </td>

                                <td>
                                    <span class="text-secondary">
                                        <?= e(
                                            date(
                                                'M d, Y',
                                                strtotime($order['created_at'])
                                            )
                                        ) ?>
                                    </span>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="8">

                                <div class="empty-state">

                                    <i class="bi bi-cart-x"></i>

                                    <h5 class="mt-3">
                                        No Orders Found
                                    </h5>

                                    <p class="text-secondary">
                                        You have not placed any orders matching these filters.
                                    </p>

                                    <a
                                        href="products.php"
                                        class="btn btn-market">

                                        <i class="bi bi-bag me-1"></i>
                                        Browse Products

                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <!-- PAGINATION -->

        <?php if ($totalPages > 1): ?>

            <nav class="mt-4">

                <ul class="pagination justify-content-center">

                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">

                        <a
                            class="page-link"
                            href="<?= e(pageUrl(max(1, $page - 1))) ?>">

                            Previous

                        </a>

                    </li>

                    <?php for (
                        $i = 1;
                        $i <= $totalPages;
                        $i++
                    ): ?>

                        <li class="page-item <?= $page === $i ? 'active' : '' ?>">

                            <a
                                class="page-link"
                                href="<?= e(pageUrl($i)) ?>">

                                <?= $i ?>

                            </a>

                        </li>

                    <?php endfor; ?>

                    <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">

                        <a
                            class="page-link"
                            href="<?= e(pageUrl(min($totalPages, $page + 1))) ?>">

                            Next

                        </a>

                    </li>

                </ul>

            </nav>

        <?php endif; ?>

    </div>

    <!-- FOOTER -->

    <footer class="text-center text-secondary small mt-5">

        &copy; <?= date('Y') ?> DigitalMarket. All rights reserved.

    </footer>

</main>

</body>
</html>
