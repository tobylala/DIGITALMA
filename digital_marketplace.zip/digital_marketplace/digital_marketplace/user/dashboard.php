
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if (($_SESSION['user_role'] ?? '') === 'admin') {
    header('Location: ../admin/dashboard.php');
    exit;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    exit('Database connection is not available.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

$userId = (int) $_SESSION['user_id'];

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    $token = $_POST['csrf_token'] ?? '';

    if (!is_string($token) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        exit('Invalid security token.');
    }

    $_SESSION = [];
    session_destroy();

    header('Location: ../auth/login.php');
    exit;
}

function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function fetchAll(PDO $pdo, string $sql, array $params = []): array
{
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    } catch (PDOException $ex) {
        error_log('User dashboard: ' . $ex->getMessage());
        return [];
    }
}

function fetchValue(PDO $pdo, string $sql, array $params = [], $default = 0)
{
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $value = $stmt->fetchColumn();
        return ($value !== false && $value !== null) ? $value : $default;
    } catch (PDOException $ex) {
        error_log('User dashboard: ' . $ex->getMessage());
        return $default;
    }
}

function formatMoney($amount): string
{
    return number_format((float)$amount, 2);
}

function statusClass(string $status): string
{
    return match (strtolower($status)) {
        'completed', 'approved', 'active', 'paid' => 'success',
        'pending', 'processing' => 'warning',
        'rejected', 'failed', 'cancelled', 'suspended' => 'danger',
        default => 'secondary'
    };
}

/* USER */
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user || ($user['status'] ?? 'active') !== 'active') {
    $_SESSION = [];
    session_destroy();
    header('Location: ../auth/login.php');
    exit;
}

$fullName = $user['full_name'] ?? $user['username'] ?? 'User';
$username = $user['username'] ?? '';
$email = $user['email'] ?? '';
$referralCode = $user['referral_code'] ?? '';
$initials = strtoupper(substr($fullName, 0, 1));

/* WALLETS */
$walletRows = fetchAll(
    $pdo,
    "SELECT wallet_type, balance, reserved_balance
     FROM wallet_accounts
     WHERE user_id = ?",
    [$userId]
);

$purchaseBalance = 0;
$purchaseReserved = 0;
$commissionBalance = 0;
$commissionReserved = 0;

foreach ($walletRows as $wallet) {
    $type = strtolower($wallet['wallet_type'] ?? '');

    if ($type === 'commission') {
        $commissionBalance += (float)$wallet['balance'];
        $commissionReserved += (float)$wallet['reserved_balance'];
    } else {
        $purchaseBalance += (float)$wallet['balance'];
        $purchaseReserved += (float)$wallet['reserved_balance'];
    }
}

$purchaseAvailable = max(0, $purchaseBalance - $purchaseReserved);
$commissionAvailable = max(0, $commissionBalance - $commissionReserved);

$totalBalance = $purchaseBalance + $commissionBalance;
$totalReserved = $purchaseReserved + $commissionReserved;
$totalAvailable = $purchaseAvailable + $commissionAvailable;

/* ORDER STATISTICS */
$totalOrders = (int)fetchValue(
    $pdo,
    "SELECT COUNT(*) FROM orders WHERE user_id = ?",
    [$userId]
);

$completedOrders = (int)fetchValue(
    $pdo,
    "SELECT COUNT(*) FROM orders WHERE user_id = ? AND status = 'completed'",
    [$userId]
);

$pendingOrders = (int)fetchValue(
    $pdo,
    "SELECT COUNT(*) FROM orders WHERE user_id = ? AND status = 'pending'",
    [$userId]
);

/* PRODUCTS */
$totalProducts = (int)fetchValue(
    $pdo,
    "SELECT COUNT(*) FROM products WHERE status = 'active'"
);

$myProducts = (int)fetchValue(
    $pdo,
    "SELECT COUNT(*) FROM product_access WHERE user_id = ?",
    [$userId]
);

/* DAILY COMMISSIONS */
$dailyCommissionTotal = (float)fetchValue(
    $pdo,
    "SELECT COALESCE(SUM(amount),0)
     FROM daily_commission_logs
     WHERE user_id = ?",
    [$userId]
);

$dailyCommissionCount = (int)fetchValue(
    $pdo,
    "SELECT COUNT(*)
     FROM daily_commission_logs
     WHERE user_id = ?",
    [$userId]
);

$activeSchedules = (int)fetchValue(
    $pdo,
    "SELECT COUNT(*)
     FROM daily_commission_schedules
     WHERE user_id = ? AND status = 'active'",
    [$userId]
);

/* REFERRAL COMMISSIONS: separate from daily commissions */
$referralCommissionTotal = (float)fetchValue(
    $pdo,
    "SELECT COALESCE(SUM(amount),0)
     FROM commissions
     WHERE affiliate_id = ? AND status = 'approved'",
    [$userId]
);

$referralCommissionCount = (int)fetchValue(
    $pdo,
    "SELECT COUNT(*)
     FROM commissions
     WHERE affiliate_id = ?",
    [$userId]
);

/* NOTIFICATIONS */
$unreadNotifications = (int)fetchValue(
    $pdo,
    "SELECT COUNT(*) FROM notifications
     WHERE user_id = ? AND is_read = 0",
    [$userId]
);

/* RECENT ORDERS */
$recentOrders = fetchAll(
    $pdo,
    "SELECT *
     FROM orders
     WHERE user_id = ?
     ORDER BY created_at DESC
     LIMIT 5",
    [$userId]
);

/* AVAILABLE PRODUCTS */
$availableProducts = fetchAll(
    $pdo,
    "SELECT *
     FROM products
     WHERE status = 'active'
     ORDER BY created_at DESC
     LIMIT 6"
);

/* PURCHASED PRODUCTS */
$purchasedProducts = fetchAll(
    $pdo,
    "SELECT p.id, p.product_name, p.description, p.image_path,
            p.file_path, pa.granted_at
     FROM product_access pa
     INNER JOIN products p ON p.id = pa.product_id
     WHERE pa.user_id = ?
     ORDER BY pa.granted_at DESC
     LIMIT 6",
    [$userId]
);

/* TRANSACTIONS */
$transactions = fetchAll(
    $pdo,
    "SELECT wt.*
     FROM wallet_transactions wt
     INNER JOIN wallet_accounts wa ON wa.id = wt.wallet_id
     WHERE wa.user_id = ?
     ORDER BY wt.created_at DESC
     LIMIT 5",
    [$userId]
);

/* NOTIFICATIONS */
$notifications = fetchAll(
    $pdo,
    "SELECT *
     FROM notifications
     WHERE user_id = ?
     ORDER BY created_at DESC
     LIMIT 5",
    [$userId]
);

/* REFERRAL LINK */
$referralLink = '';

if ($referralCode !== '') {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        ? 'https://' : 'http://';

    $referralLink = $scheme .
        ($_SERVER['HTTP_HOST'] ?? 'localhost') .
        '/digital_marketplace/auth/register.php?ref=' .
        urlencode($referralCode);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>User Dashboard | Digital Marketplace</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>
:root {
    --primary:#635bff;
    --primary-dark:#5148e5;
    --sidebar:#171b2e;
    --sidebar-text:#aeb4c8;
    --background:#f5f6fa;
    --card-radius:16px;
}
* {box-sizing:border-box}
body {margin:0;background:var(--background);color:#24283b;font-family:Inter,sans-serif}
.sidebar {width:255px;height:100vh;position:fixed;top:0;left:0;background:var(--sidebar);color:white;padding:25px 17px;display:flex;flex-direction:column;z-index:1000;overflow-y:auto}
.brand {display:flex;align-items:center;gap:12px;padding:5px 10px 30px;font-size:19px;font-weight:800;color:white;text-decoration:none}
.brand-icon {width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;background:var(--primary);font-size:21px}
.sidebar-label {color:#737b98;font-size:10px;font-weight:700;letter-spacing:1.3px;padding:15px 12px 9px;text-transform:uppercase}
.sidebar-link {display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;color:var(--sidebar-text);text-decoration:none;font-size:13px;font-weight:500;margin-bottom:5px}
.sidebar-link i {font-size:17px}
.sidebar-link:hover,.sidebar-link.active {background:rgba(99,91,255,.18);color:white}
.sidebar-link.active {border-left:3px solid var(--primary)}
.sidebar-bottom {margin-top:auto;padding-top:20px}
.logout-btn {border:0;width:100%;background:rgba(239,68,68,.12);color:#ff8b8b;padding:12px 14px;border-radius:10px;text-align:left;font-size:13px;font-weight:600}
.logout-btn:hover {background:#dc3545;color:white}
.main-content {margin-left:255px;padding:30px;min-height:100vh}
.topbar {display:flex;align-items:center;justify-content:space-between;gap:20px;margin-bottom:30px}
.page-title {font-size:25px;font-weight:800;margin:0}
.page-subtitle {color:#85899b;font-size:13px;margin-top:6px}
.user-profile {display:flex;align-items:center;gap:11px;background:white;padding:9px 15px;border-radius:12px}
.avatar {width:39px;height:39px;background:#e9e7ff;color:var(--primary);display:flex;align-items:center;justify-content:center;border-radius:50%;font-weight:800}
.profile-name {font-size:13px;font-weight:700}
.profile-role {font-size:11px;color:#9296a7}
.welcome-card {background:linear-gradient(115deg,#635bff,#837bff);color:white;border-radius:var(--card-radius);padding:27px 30px;margin-bottom:25px;position:relative;overflow:hidden}
.welcome-card h2 {font-size:22px;font-weight:800;margin-bottom:8px}
.welcome-card p {margin:0;opacity:.85;font-size:13px}
.welcome-icon {position:absolute;right:35px;top:50%;transform:translateY(-50%);font-size:75px;opacity:.15}
.stat-card,.section-card {background:white;border-radius:var(--card-radius);padding:22px;height:100%;box-shadow:0 4px 18px rgba(20,25,50,.035);border:1px solid #f0f0f5}
.stat-top {display:flex;align-items:center;justify-content:space-between;margin-bottom:17px}
.stat-icon {width:45px;height:45px;border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:20px}
.purple {background:#eeedff;color:#635bff}
.green {background:#e5f9ef;color:#16a36a}
.orange {background:#fff2e3;color:#f39a37}
.blue {background:#e7f3ff;color:#3288dc}
.red {background:#ffe9e9;color:#e34e4e}
.stat-label {font-size:12px;color:#8a8ea0;font-weight:500}
.stat-value {font-size:23px;font-weight:800;margin-top:6px;overflow-wrap:anywhere}
.stat-note {color:#9296a7;font-size:11px;margin-top:7px}
.section-heading {display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:20px}
.section-heading h5 {font-size:15px;font-weight:800;margin:0}
.view-link {color:var(--primary);font-size:12px;text-decoration:none;font-weight:600}
.table {vertical-align:middle;margin-bottom:0}
.table thead th {color:#9296a7;font-size:11px;font-weight:600;border-bottom:1px solid #eeeef3;padding:12px 9px;white-space:nowrap}
.table tbody td {font-size:12px;padding:14px 9px;border-bottom:1px solid #f1f1f5}
.table tbody tr:last-child td {border-bottom:0}
.badge-status {padding:6px 10px;border-radius:20px;font-size:10px;font-weight:700}
.product-item {display:flex;align-items:center;gap:13px;padding:12px 0;border-bottom:1px solid #f0f0f5}
.product-item:last-child {border-bottom:0}
.product-image {width:48px;height:48px;border-radius:10px;background:#f0efff;object-fit:cover;display:flex;align-items:center;justify-content:center;color:var(--primary);font-size:20px;flex-shrink:0}
.product-name {font-size:12px;font-weight:700;margin-bottom:5px}
.product-description {font-size:11px;color:#9296a7}
.download-btn {background:#eeedff;color:var(--primary);border:0;border-radius:8px;padding:8px 11px;font-size:11px;text-decoration:none;font-weight:700;white-space:nowrap}
.download-btn:hover {background:var(--primary);color:white}
.notification-item {display:flex;gap:12px;padding:13px 0;border-bottom:1px solid #f0f0f5}
.notification-item:last-child {border-bottom:0}
.notification-icon {width:36px;height:36px;flex-shrink:0;border-radius:10px;background:#eeedff;color:var(--primary);display:flex;align-items:center;justify-content:center}
.notification-title {font-size:12px;font-weight:700}
.notification-message {font-size:11px;color:#85899b;margin-top:4px}
.referral-box {background:#f7f6ff;border:1px dashed #c8c4ff;padding:16px;border-radius:12px}
.referral-box input {font-size:11px;background:white}
.copy-btn {background:var(--primary);color:white;border:0;border-radius:7px;padding:9px 13px;font-size:12px;font-weight:600}
.copy-btn:hover {background:var(--primary-dark)}
.empty-state {text-align:center;padding:25px 10px;color:#9699a8;font-size:12px}
.empty-state i {font-size:28px;display:block;margin-bottom:8px;color:#c3c4d0}
.mobile-menu {display:none;background:white;border:0;border-radius:9px;padding:8px 12px;font-size:20px}
.financial-note {background:#eef4ff;border:1px solid #dce7ff;color:#344b73;padding:13px 16px;border-radius:12px;font-size:12px}
footer {text-align:center;color:#999dad;font-size:11px;padding:25px 10px 10px}
@media(max-width:991px) {
.sidebar {transform:translateX(-100%);transition:.25s}
.sidebar.show {transform:translateX(0)}
.main-content {margin-left:0;padding:22px 16px}
.mobile-menu {display:inline-block}
.welcome-icon {font-size:55px;right:15px}
}
@media(max-width:576px) {
.topbar {align-items:flex-start}
.page-title {font-size:20px}
.user-profile {padding:7px}
.user-profile .profile-details {display:none}
.welcome-card {padding:23px 20px}
.welcome-card h2 {font-size:19px}
.stat-value {font-size:19px}
}
</style>
</head>
<body>

<aside class="sidebar" id="sidebar">
    <a href="dashboard.php" class="brand">
        <span class="brand-icon"><i class="bi bi-shop"></i></span>
        <span>Digital Market</span>
    </a>

    <div class="sidebar-label">Main Menu</div>
    <a href="dashboard.php" class="sidebar-link active"><i class="bi bi-grid-1x2"></i> Dashboard</a>
    <a href="my_products.php" class="sidebar-link"><i class="bi bi-cloud-download"></i> My Products</a>
    <a href="orders.php" class="sidebar-link"><i class="bi bi-cart3"></i> My Orders</a>

    <div class="sidebar-label">My Wallet</div>
    <a href="wallet.php" class="sidebar-link"><i class="bi bi-wallet2"></i> Wallet</a>
    <a href="deposits.php" class="sidebar-link"><i class="bi bi-plus-circle"></i> Deposit</a>
    <a href="withdrawal.php" class="sidebar-link"><i class="bi bi-cash-stack"></i> Withdraw Money</a>
    <a href="transactions.php" class="sidebar-link"><i class="bi bi-arrow-left-right"></i> Transactions</a>
    <a href="commissions.php" class="sidebar-link"><i class="bi bi-graph-up-arrow"></i> Commissions</a>

    <div class="sidebar-label">Account</div>
    <a href="notifications.php" class="sidebar-link">
        <i class="bi bi-bell"></i> Notifications
        <?php if ($unreadNotifications > 0): ?>
            <span class="badge bg-danger ms-auto"><?= $unreadNotifications ?></span>
        <?php endif; ?>
    </a>
    <a href="profile.php" class="sidebar-link"><i class="bi bi-person-circle"></i> My Profile</a>

    <div class="sidebar-bottom">
        <form method="POST" action="dashboard.php">
            <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
            <button type="submit" name="logout" value="1" class="logout-btn"
                    onclick="return confirm('Are you sure you want to logout?');">
                <i class="bi bi-box-arrow-right me-2"></i> Logout
            </button>
        </form>
    </div>
</aside>

<main class="main-content">
    <div class="topbar">
        <div class="d-flex align-items-center gap-3">
            <button class="mobile-menu" type="button" onclick="toggleSidebar()"><i class="bi bi-list"></i></button>
            <div>
                <h1 class="page-title">Dashboard</h1>
                <div class="page-subtitle">Welcome to your digital marketplace account.</div>
            </div>
        </div>
        <div class="user-profile">
            <div class="avatar"><?= e($initials) ?></div>
            <div class="profile-details">
                <div class="profile-name"><?= e($fullName) ?></div>
                <div class="profile-role">Marketplace User</div>
            </div>
        </div>
    </div>

    <section class="welcome-card">
        <h2>Welcome back, <?= e($fullName) ?>!</h2>
        <p>Manage your purchases, wallet, digital products and account.</p>
        <i class="bi bi-rocket-takeoff welcome-icon"></i>
    </section>

    <h6 class="fw-bold mb-3">My Wallet Overview</h6>

    <div class="financial-note mb-3">
        <i class="bi bi-info-circle me-1"></i>
        Your available balance excludes reserved withdrawals. Daily commissions are credited to your commission wallet separately from referral commissions.
    </div>

    <div class="row g-3 mb-4">
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-top"><div class="stat-icon purple"><i class="bi bi-wallet2"></i></div></div>
                <div class="stat-label">Total Wallet Balance</div>
                <div class="stat-value"><?= formatMoney($totalBalance) ?></div>
                <div class="stat-note">Both wallets before reservations</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-top"><div class="stat-icon green"><i class="bi bi-check-circle"></i></div></div>
                <div class="stat-label">Total Available</div>
                <div class="stat-value"><?= formatMoney($totalAvailable) ?></div>
                <div class="stat-note">Available to use</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-top"><div class="stat-icon orange"><i class="bi bi-lock"></i></div></div>
                <div class="stat-label">Reserved Balance</div>
                <div class="stat-value"><?= formatMoney($totalReserved) ?></div>
                <div class="stat-note">Funds reserved for withdrawals</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-top"><div class="stat-icon blue"><i class="bi bi-cash-coin"></i></div></div>
                <div class="stat-label">Daily Commissions Earned</div>
                <div class="stat-value"><?= formatMoney($dailyCommissionTotal) ?></div>
                <div class="stat-note"><?= number_format($dailyCommissionCount) ?> daily payment records</div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <div class="stat-label">Purchase Wallet Available</div>
                <div class="stat-value"><?= formatMoney($purchaseAvailable) ?></div>
                <div class="stat-note">Balance: <?= formatMoney($purchaseBalance) ?></div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <div class="stat-label">Commission Wallet Available</div>
                <div class="stat-value"><?= formatMoney($commissionAvailable) ?></div>
                <div class="stat-note">Balance: <?= formatMoney($commissionBalance) ?></div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <div class="stat-label">Active Daily Schedules</div>
                <div class="stat-value"><?= number_format($activeSchedules) ?></div>
                <div class="stat-note">Current commission schedules</div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <div class="stat-label">Referral Commissions</div>
                <div class="stat-value"><?= formatMoney($referralCommissionTotal) ?></div>
                <div class="stat-note"><?= number_format($referralCommissionCount) ?> referral records</div>
            </div>
        </div>
    </div>

    <h6 class="fw-bold mb-3">Marketplace Activity</h6>
    <div class="row g-3 mb-4">
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-top"><div class="stat-icon orange"><i class="bi bi-cart-check"></i></div></div>
                <div class="stat-label">Total Orders</div>
                <div class="stat-value"><?= number_format($totalOrders) ?></div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-top"><div class="stat-icon green"><i class="bi bi-check-circle"></i></div></div>
                <div class="stat-label">Completed Orders</div>
                <div class="stat-value"><?= number_format($completedOrders) ?></div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-top"><div class="stat-icon blue"><i class="bi bi-cloud-download"></i></div></div>
                <div class="stat-label">My Digital Products</div>
                <div class="stat-value"><?= number_format($myProducts) ?></div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-top"><div class="stat-icon purple"><i class="bi bi-box-seam"></i></div></div>
                <div class="stat-label">Available Products</div>
                <div class="stat-value"><?= number_format($totalProducts) ?></div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-lg-8">
            <div class="section-card">
                <div class="section-heading">
                    <h5>Recent Orders</h5>
                    <a href="orders.php" class="view-link">View All <i class="bi bi-arrow-right"></i></a>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead><tr><th>Order Number</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
                        <tbody>
                        <?php if ($recentOrders): ?>
                            <?php foreach ($recentOrders as $order): ?>
                                <?php $orderStatus = (string)($order['status'] ?? 'pending'); $badge = statusClass($orderStatus); ?>
                                <tr>
                                    <td class="fw-semibold"><?= e($order['order_number'] ?? ('#'.$order['id'])) ?></td>
                                    <td><?= formatMoney($order['total_amount'] ?? 0) ?> ETB</td>
                                    <td><span class="badge bg-<?= e($badge) ?>-subtle text-<?= e($badge) ?> badge-status"><?= e(ucfirst($orderStatus)) ?></span></td>
                                    <td><?= e(!empty($order['created_at']) ? date('M d, Y', strtotime($order['created_at'])) : '-') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4"><div class="empty-state"><i class="bi bi-cart-x"></i>You have not placed any orders yet.</div></td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="section-card">
                <div class="section-heading">
                    <h5>Notifications</h5>
                    <a href="notifications.php" class="view-link">View All</a>
                </div>
                <?php if ($notifications): ?>
                    <?php foreach ($notifications as $notification): ?>
                        <div class="notification-item">
                            <div class="notification-icon"><i class="bi bi-bell"></i></div>
                            <div>
                                <div class="notification-title"><?= e($notification['title'] ?? 'Notification') ?></div>
                                <div class="notification-message"><?= e($notification['message'] ?? '') ?></div>
                                <?php if (!empty($notification['created_at'])): ?>
                                    <div class="text-muted mt-1" style="font-size:10px"><?= e(date('M d, Y', strtotime($notification['created_at']))) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state"><i class="bi bi-bell-slash"></i>No notifications available.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-lg-7">
            <div class="section-card">
                <div class="section-heading">
                    <h5>My Purchased Products</h5>
                    <a href="my_products.php" class="view-link">View All</a>
                </div>
                <?php if ($purchasedProducts): ?>
                    <?php foreach ($purchasedProducts as $product): ?>
                        <div class="product-item">
                            <?php if (!empty($product['image_path'])): ?>
                                <img src="../<?= e($product['image_path']) ?>" class="product-image" alt="Product">
                            <?php else: ?>
                                <div class="product-image"><i class="bi bi-file-earmark"></i></div>
                            <?php endif; ?>
                            <div class="flex-grow-1">
                                <div class="product-name"><?= e($product['product_name']) ?></div>
                                <div class="product-description">
                                    Purchased: <?= e(!empty($product['granted_at']) ? date('M d, Y', strtotime($product['granted_at'])) : '-') ?>
                                </div>
                            </div>
                            <?php if (!empty($product['file_path'])): ?>
                                <a href="download.php?product_id=<?= (int)$product['id'] ?>" class="download-btn">
                                    <i class="bi bi-download me-1"></i>Download
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state"><i class="bi bi-cloud-download"></i>You have not purchased any digital products yet.</div>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="section-card">
                <div class="section-heading">
                    <h5>Referral Program</h5>
                    <i class="bi bi-people text-primary fs-5"></i>
                </div>
                <p class="text-muted" style="font-size:12px;line-height:1.7">
                    Invite other people to join the marketplace using your referral link.
                </p>
                <?php if ($referralCode !== '' && $referralLink !== ''): ?>
                    <div class="referral-box">
                        <label class="form-label fw-semibold" style="font-size:11px">Your Referral Code</label>
                        <input type="text" class="form-control form-control-sm mb-3" value="<?= e($referralCode) ?>" readonly>
                        <label class="form-label fw-semibold" style="font-size:11px">Your Referral Link</label>
                        <div class="input-group">
                            <input type="text" id="referralLink" class="form-control form-control-sm" value="<?= e($referralLink) ?>" readonly>
                            <button type="button" class="copy-btn" onclick="copyReferralLink()">Copy</button>
                        </div>
                        <div id="copyMessage" class="text-success mt-2" style="font-size:11px;display:none">Referral link copied.</div>
                    </div>
                <?php else: ?>
                    <div class="empty-state"><i class="bi bi-link-45deg"></i>Your referral code is not available yet.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="section-card">
        <div class="section-heading">
            <h5>Explore Available Products</h5>
            <a href="products.php" class="view-link">Browse All Products <i class="bi bi-arrow-right"></i></a>
        </div>
        <div class="row g-3">
            <?php if ($availableProducts): ?>
                <?php foreach ($availableProducts as $product): ?>
                    <div class="col-sm-6 col-lg-4">
                        <div class="border rounded-3 p-3 h-100">
                            <?php if (!empty($product['image_path'])): ?>
                                <img src="../<?= e($product['image_path']) ?>" alt="<?= e($product['product_name']) ?>" class="w-100 rounded-3 mb-3" style="height:140px;object-fit:cover">
                            <?php else: ?>
                                <div class="rounded-3 mb-3 d-flex align-items-center justify-content-center" style="height:140px;background:#f0efff;color:#635bff">
                                    <i class="bi bi-box-seam" style="font-size:40px"></i>
                                </div>
                            <?php endif; ?>
                            <div class="fw-bold mb-2" style="font-size:13px"><?= e($product['product_name']) ?></div>
                            <div class="text-muted mb-3" style="font-size:11px">
                                <?= e(mb_strimwidth((string)($product['description'] ?? ''), 0, 85, '...')) ?>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <strong class="text-primary" style="font-size:14px"><?= formatMoney($product['price']) ?> ETB</strong>
                                <a href="product_details.php?id=<?= (int)$product['id'] ?>" class="btn btn-sm btn-outline-primary" style="font-size:11px">View Product</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12"><div class="empty-state"><i class="bi bi-box-seam"></i>No active products are currently available.</div></div>
            <?php endif; ?>
        </div>
    </div>

    <footer>&copy; <?= date('Y') ?> Digital Marketplace. All rights reserved.</footer>
</main>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('show');
}

function copyReferralLink() {
    const input = document.getElementById('referralLink');
    const message = document.getElementById('copyMessage');
    if (!input) return;

    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(input.value).then(() => {
            message.style.display = 'block';
        }).catch(() => fallbackCopy(input, message));
    } else {
        fallbackCopy(input, message);
    }
}

function fallbackCopy(input, message) {
    input.select();
    input.setSelectionRange(0, 99999);
    if (document.execCommand('copy')) {
        message.style.display = 'block';
    } else {
        alert('Please copy the referral link manually.');
    }
}
</script>
</body>
</html>
