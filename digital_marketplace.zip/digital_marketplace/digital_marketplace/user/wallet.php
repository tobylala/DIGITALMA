
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection failed.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/* =========================================
   AUTHENTICATION
========================================= */

$userId = (int)($_SESSION['user_id'] ?? 0);

if ($userId <= 0) {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT id, full_name, username, role, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$userId]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (
    !$user ||
    $user['role'] !== 'user' ||
    $user['status'] !== 'active'
) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

/* =========================================
   HELPER FUNCTIONS
========================================= */

function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function money($amount): string
{
    return number_format((float)$amount, 2) . ' ETB';
}

function transactionBadge($type): string
{
    $classes = [
        'credit'  => 'success',
        'debit'   => 'danger',
        'reserve' => 'warning',
        'release' => 'info'
    ];

    $type = strtolower((string)$type);
    $class = $classes[$type] ?? 'secondary';

    return '<span class="badge bg-' . $class . '">' .
        e(ucfirst($type)) .
        '</span>';
}

/* =========================================
   FETCH WALLET ACCOUNTS
========================================= */

$stmt = $pdo->prepare("
    SELECT
        wallet_type,
        balance,
        reserved_balance
    FROM wallet_accounts
    WHERE user_id = ?
");

$stmt->execute([$userId]);

$walletRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$wallets = [
    'purchase' => [
        'balance' => 0.00,
        'reserved_balance' => 0.00
    ],
    'commission' => [
        'balance' => 0.00,
        'reserved_balance' => 0.00
    ]
];

foreach ($walletRows as $wallet) {
    $type = $wallet['wallet_type'];

    if (isset($wallets[$type])) {
        $wallets[$type]['balance'] =
            (float)$wallet['balance'];

        $wallets[$type]['reserved_balance'] =
            (float)$wallet['reserved_balance'];
    }
}

/* =========================================
   WALLET CALCULATIONS
========================================= */

$purchaseBalance = $wallets['purchase']['balance'];
$purchaseReserved = $wallets['purchase']['reserved_balance'];

$commissionBalance = $wallets['commission']['balance'];
$commissionReserved = $wallets['commission']['reserved_balance'];

/*
|--------------------------------------------------------------------------
| TOTAL WALLET BALANCE
|--------------------------------------------------------------------------
*/

$totalBalance = $purchaseBalance + $commissionBalance;

/*
|--------------------------------------------------------------------------
| TOTAL RESERVED BALANCE
|--------------------------------------------------------------------------
*/

$totalReserved = $purchaseReserved + $commissionReserved;

/*
|--------------------------------------------------------------------------
| AVAILABLE BALANCES
|--------------------------------------------------------------------------
*/

$purchaseAvailable = max(
    0,
    $purchaseBalance - $purchaseReserved
);

$commissionAvailable = max(
    0,
    $commissionBalance - $commissionReserved
);

/*
|--------------------------------------------------------------------------
| MAIN WALLET BALANCE
|--------------------------------------------------------------------------
| Main Wallet Balance = Total Balance - Reserved Balance
|
| Example:
| Purchase wallet: 500 ETB
| Commission wallet: 25 ETB
| Total: 525 ETB
| Reserved: 300 ETB
| Main available balance: 225 ETB
*/

$totalAvailable = max(
    0,
    $totalBalance - $totalReserved
);

/* =========================================
   TRANSACTION FILTERS
========================================= */

$search = trim($_GET['search'] ?? '');
$typeFilter = trim($_GET['type'] ?? '');

$allowedTypes = [
    'credit',
    'debit',
    'reserve',
    'release'
];

$where = ["wa.user_id = ?"];
$params = [$userId];

if (in_array($typeFilter, $allowedTypes, true)) {
    $where[] = "wt.transaction_type = ?";
    $params[] = $typeFilter;
}

if ($search !== '') {
    $where[] = "(
        wt.description LIKE ?
        OR wt.reference_type LIKE ?
        OR wt.idempotency_key LIKE ?
    )";

    $keyword = '%' . $search . '%';

    $params[] = $keyword;
    $params[] = $keyword;
    $params[] = $keyword;
}

$whereSQL = implode(' AND ', $where);

/* =========================================
   TRANSACTION STATISTICS
========================================= */

$stmt = $pdo->prepare("
    SELECT
        COUNT(*) AS total_transactions,

        COALESCE(SUM(
            CASE
                WHEN wt.transaction_type = 'credit'
                THEN wt.amount
                ELSE 0
            END
        ), 0) AS total_credits,

        COALESCE(SUM(
            CASE
                WHEN wt.transaction_type = 'debit'
                THEN wt.amount
                ELSE 0
            END
        ), 0) AS total_debits,

        COALESCE(SUM(
            CASE
                WHEN wt.transaction_type = 'reserve'
                THEN wt.amount
                ELSE 0
            END
        ), 0) AS total_reserved_transactions

    FROM wallet_transactions wt

    INNER JOIN wallet_accounts wa
        ON wa.id = wt.wallet_id

    WHERE wa.user_id = ?
");

$stmt->execute([$userId]);

$transactionStats = $stmt->fetch(PDO::FETCH_ASSOC);

/* =========================================
   PAGINATION
========================================= */

$perPage = 10;

$page = max(1, (int)($_GET['page'] ?? 1));

$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM wallet_transactions wt

    INNER JOIN wallet_accounts wa
        ON wa.id = wt.wallet_id

    WHERE $whereSQL
");

$stmt->execute($params);

$totalTransactions = (int)$stmt->fetchColumn();

$totalPages = max(
    1,
    (int)ceil($totalTransactions / $perPage)
);

$page = min($page, $totalPages);

$offset = ($page - 1) * $perPage;

/* =========================================
   FETCH TRANSACTION HISTORY
========================================= */

$stmt = $pdo->prepare("
    SELECT
        wt.id,
        wt.transaction_type,
        wt.amount,
        wt.balance_after,
        wt.reference_type,
        wt.reference_id,
        wt.description,
        wt.created_at,
        wa.wallet_type

    FROM wallet_transactions wt

    INNER JOIN wallet_accounts wa
        ON wa.id = wt.wallet_id

    WHERE $whereSQL

    ORDER BY wt.created_at DESC, wt.id DESC

    LIMIT $perPage OFFSET $offset
");

$stmt->execute($params);

$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================================
   PAGINATION URL
========================================= */

function pageUrl($page): string
{
    $query = $_GET;
    $query['page'] = $page;

    return '?' . http_build_query($query);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>My Wallet | DigitalMarket</title>

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet">

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
    rel="stylesheet">

<style>

:root {
    --navy: #102747;
    --dark: #0a1b32;
    --gold: #d8aa45;
    --light: #f4f6fa;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: var(--light);
    font-family: Arial, sans-serif;
}

/* SIDEBAR */

.sidebar {
    width: 250px;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    background: var(--dark);
    padding: 24px 16px;
    color: white;
    overflow-y: auto;
    z-index: 1000;
}

.brand {
    font-size: 21px;
    font-weight: 800;
    color: var(--gold);
    margin-bottom: 35px;
    padding: 0 10px;
}

.sidebar a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 14px;
    color: #d9e1ec;
    text-decoration: none;
    border-radius: 8px;
    margin-bottom: 7px;
    transition: .2s;
}

.sidebar a:hover,
.sidebar a.active {
    background: var(--navy);
    color: var(--gold);
}

.sidebar a i {
    font-size: 18px;
}

/* MAIN */

.main {
    margin-left: 250px;
    padding: 30px;
}

.page-title {
    color: var(--navy);
    font-weight: 750;
}

/* WALLET CARDS */

.wallet-card {
    padding: 25px;
    border-radius: 14px;
    color: white;
    height: 100%;
    position: relative;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,.07);
}

.purchase-card {
    background: linear-gradient(135deg, #102747, #1b426d);
}

.commission-card {
    background: linear-gradient(135deg, #176b52, #0d4939);
}

.total-card {
    background: linear-gradient(135deg, #8b6927, #c29432);
}

.wallet-icon {
    width: 46px;
    height: 46px;
    background: rgba(255,255,255,.15);
    border-radius: 11px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
}

.wallet-title {
    margin-top: 18px;
    font-size: 14px;
    opacity: .9;
}

.wallet-amount {
    font-size: 27px;
    font-weight: 800;
    margin-top: 5px;
    overflow-wrap: anywhere;
}

.wallet-detail {
    font-size: 13px;
    margin-top: 12px;
    opacity: .95;
    line-height: 1.8;
}

/* STAT CARDS */

.stat-card {
    background: white;
    padding: 20px;
    border-radius: 12px;
    border: 1px solid #e8edf4;
    height: 100%;
}

.stat-number {
    font-size: 22px;
    font-weight: 800;
    color: var(--navy);
    margin-top: 12px;
}

.stat-label {
    font-size: 13px;
    color: #778397;
}

/* TRANSACTIONS */

.table-card {
    background: white;
    padding: 20px;
    border-radius: 12px;
    border: 1px solid #e8edf4;
}

.table thead th {
    background: #f5f7fa;
    color: var(--navy);
    font-size: 13px;
    white-space: nowrap;
}

.table tbody td {
    vertical-align: middle;
    font-size: 14px;
}

.positive {
    color: #198754;
    font-weight: 700;
}

.negative {
    color: #dc3545;
    font-weight: 700;
}

.filter-box {
    background: white;
    padding: 18px;
    border-radius: 12px;
    border: 1px solid #e8edf4;
}

.empty-state {
    padding: 45px 15px;
    text-align: center;
}

.empty-state i {
    font-size: 50px;
    color: #b6c0ce;
}

.btn-market {
    background: var(--navy);
    color: white;
    border: none;
}

.btn-market:hover {
    background: var(--dark);
    color: var(--gold);
}

.balance-note {
    background: #fff8e7;
    border: 1px solid #f0dfb4;
    border-radius: 10px;
    padding: 13px 16px;
    color: #755719;
    font-size: 13px;
}

/* RESPONSIVE */

@media(max-width: 900px) {

    .sidebar {
        width: 75px;
        padding: 20px 10px;
    }

    .brand {
        font-size: 0;
        text-align: center;
        padding: 0;
    }

    .brand:after {
        content: "DM";
        font-size: 19px;
    }

    .sidebar a {
        justify-content: center;
        font-size: 0;
        padding: 13px 5px;
    }

    .sidebar a i {
        font-size: 21px;
    }

    .main {
        margin-left: 75px;
        padding: 20px;
    }
}

@media(max-width: 576px) {

    .main {
        padding: 14px;
    }

    .wallet-amount {
        font-size: 22px;
    }

    .table-card {
        padding: 12px;
    }
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<aside class="sidebar">

    <div class="brand">
        <i class="bi bi-shop"></i>
        DigitalMarket
    </div>

    <a href="dashboard.php">
        <i class="bi bi-grid"></i>
        Dashboard
    </a>

    <a href="wallet.php" class="active">
        <i class="bi bi-wallet2"></i>
        My Wallet
    </a>

    <hr class="border-secondary">

    <a href="../auth/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        Logout
    </a>

</aside>

<!-- MAIN CONTENT -->

<main class="main">

    <div class="mb-4">

        <h3 class="page-title">
            My Wallet
        </h3>

        <p class="text-secondary">
            Manage your balances and monitor your wallet transactions.
        </p>

    </div>

    <!-- WALLET BALANCES -->

    <div class="row g-3 mb-4">

        <!-- PURCHASE WALLET -->

        <div class="col-xl-4 col-md-6">

            <div class="wallet-card purchase-card">

                <div class="wallet-icon">
                    <i class="bi bi-cart-check"></i>
                </div>

                <div class="wallet-title">
                    Purchase Wallet
                </div>

                <div class="wallet-amount">
                    <?= money($purchaseBalance) ?>
                </div>

                <div class="wallet-detail">
                    Available: <?= money($purchaseAvailable) ?>
                    <br>
                    Reserved: <?= money($purchaseReserved) ?>
                </div>

            </div>

        </div>

        <!-- COMMISSION WALLET -->

        <div class="col-xl-4 col-md-6">

            <div class="wallet-card commission-card">

                <div class="wallet-icon">
                    <i class="bi bi-graph-up-arrow"></i>
                </div>

                <div class="wallet-title">
                    Commission Wallet
                </div>

                <div class="wallet-amount">
                    <?= money($commissionBalance) ?>
                </div>

                <div class="wallet-detail">
                    Available: <?= money($commissionAvailable) ?>
                    <br>
                    Reserved: <?= money($commissionReserved) ?>
                </div>

            </div>

        </div>

        <!-- MAIN WALLET -->

        <div class="col-xl-4 col-md-6">

            <div class="wallet-card total-card">

                <div class="wallet-icon">
                    <i class="bi bi-wallet"></i>
                </div>

                <div class="wallet-title">
                    Main Wallet Balance
                </div>

                <div class="wallet-amount">
                    <?= money($totalAvailable) ?>
                </div>

                <div class="wallet-detail">
                    Total Balance: <?= money($totalBalance) ?>
                    <br>
                    Reserved: <?= money($totalReserved) ?>
                </div>

            </div>

        </div>

    </div>

    <div class="balance-note mb-4">
        <i class="bi bi-info-circle me-1"></i>
        Main Wallet Balance shows your available combined funds after deducting reserved amounts.
        Reserved withdrawals are not available for spending or another withdrawal.
    </div>

    <!-- QUICK ACTIONS -->

    <div class="d-flex flex-wrap gap-2 mb-4">

        <a href="deposits.php" class="btn btn-market">
            <i class="bi bi-plus-circle me-1"></i>
            Add Funds
        </a>

        <a href="withdrawals.php" class="btn btn-outline-success">
            <i class="bi bi-cash-stack me-1"></i>
            Withdraw
        </a>

        <a href="products.php" class="btn btn-outline-primary">
            <i class="bi bi-bag me-1"></i>
            Browse Products
        </a>

    </div>

    <!-- TRANSACTION STATISTICS -->

    <div class="row g-3 mb-4">

        <div class="col-md-4">

            <div class="stat-card">

                <div class="stat-label">
                    Total Transactions
                </div>

                <div class="stat-number">
                    <?= number_format(
                        (int)($transactionStats['total_transactions'] ?? 0)
                    ) ?>
                </div>

            </div>

        </div>

        <div class="col-md-4">

            <div class="stat-card">

                <div class="stat-label">
                    Total Credits
                </div>

                <div class="stat-number text-success">
                    <?= money($transactionStats['total_credits'] ?? 0) ?>
                </div>

            </div>

        </div>

        <div class="col-md-4">

            <div class="stat-card">

                <div class="stat-label">
                    Total Debits
                </div>

                <div class="stat-number text-danger">
                    <?= money($transactionStats['total_debits'] ?? 0) ?>
                </div>

            </div>

        </div>

    </div>

    <!-- TRANSACTION FILTERS -->

    <div class="filter-box mb-4">

        <form method="GET" class="row g-3">

            <div class="col-md-6">

                <label class="form-label fw-semibold">
                    Search Transactions
                </label>

                <input
                    type="search"
                    name="search"
                    class="form-control"
                    placeholder="Search description or reference..."
                    value="<?= e($search) ?>">

            </div>

            <div class="col-md-3">

                <label class="form-label fw-semibold">
                    Transaction Type
                </label>

                <select name="type" class="form-select">

                    <option value="">All Types</option>

                    <?php foreach ($allowedTypes as $type): ?>

                        <option
                            value="<?= e($type) ?>"
                            <?= $typeFilter === $type ? 'selected' : '' ?>>

                            <?= e(ucfirst($type)) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <div class="col-md-3 d-flex align-items-end gap-2">

                <button type="submit" class="btn btn-market flex-grow-1">
                    <i class="bi bi-search me-1"></i>
                    Filter
                </button>

                <a href="wallet.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-counterclockwise"></i>
                </a>

            </div>

        </form>

    </div>

    <!-- TRANSACTION HISTORY -->

    <div class="table-card">

        <div class="d-flex justify-content-between align-items-center mb-3">

            <h5 class="fw-bold mb-0">
                Transaction History
            </h5>

            <span class="text-secondary small">
                <?= number_format($totalTransactions) ?> transaction(s)
            </span>

        </div>

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>

                    <tr>
                        <th>Transaction ID</th>
                        <th>Wallet</th>
                        <th>Type</th>
                        <th>Description</th>
                        <th>Reference</th>
                        <th>Amount</th>
                        <th>Balance After</th>
                        <th>Date</th>
                    </tr>

                </thead>

                <tbody>

                    <?php if (!empty($transactions)): ?>

                        <?php foreach ($transactions as $transaction): ?>

                            <?php
                                $type = $transaction['transaction_type'];

                                $isPositive = in_array(
                                    $type,
                                    ['credit', 'release'],
                                    true
                                );
                            ?>

                            <tr>

                                <td>
                                    #<?= (int)$transaction['id'] ?>
                                </td>

                                <td>
                                    <span class="badge bg-light text-dark">
                                        <?= e(ucfirst($transaction['wallet_type'])) ?>
                                    </span>
                                </td>

                                <td>
                                    <?= transactionBadge($type) ?>
                                </td>

                                <td>
                                    <?= e(
                                        $transaction['description']
                                        ?: 'Wallet transaction'
                                    ) ?>
                                </td>

                                <td>
                                    <div class="small">
                                        <?= e(
                                            $transaction['reference_type'] ?: '-'
                                        ) ?>
                                    </div>

                                    <?php if ($transaction['reference_id'] !== null): ?>
                                        <span class="text-secondary small">
                                            #<?= (int)$transaction['reference_id'] ?>
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td class="<?= $isPositive ? 'positive' : 'negative' ?>">
                                    <?= $isPositive ? '+' : '-' ?>
                                    <?= money($transaction['amount']) ?>
                                </td>

                                <td class="fw-semibold">
                                    <?= money($transaction['balance_after']) ?>
                                </td>

                                <td>
                                    <span class="text-secondary small">
                                        <?= e(
                                            date(
                                                'M d, Y H:i',
                                                strtotime($transaction['created_at'])
                                            )
                                        ) ?>
                                    </span>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="8">

                                <div class="empty-state">

                                    <i class="bi bi-receipt"></i>

                                    <h5 class="mt-3">
                                        No Transactions Found
                                    </h5>

                                    <p class="text-secondary">
                                        Your wallet transactions will appear here.
                                    </p>

                                </div>

                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <!-- PAGINATION -->

        <?php if ($totalPages > 1): ?>

            <nav class="mt-4">

                <ul class="pagination justify-content-center">

                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">

                        <a
                            class="page-link"
                            href="<?= e(pageUrl(max(1, $page - 1))) ?>">

                            Previous

                        </a>

                    </li>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>

                        <li class="page-item <?= $page === $i ? 'active' : '' ?>">

                            <a
                                class="page-link"
                                href="<?= e(pageUrl($i)) ?>">

                                <?= $i ?>

                            </a>

                        </li>

                    <?php endfor; ?>

                    <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">

                        <a
                            class="page-link"
                            href="<?= e(pageUrl(min($totalPages, $page + 1))) ?>">

                            Next

                        </a>

                    </li>

                </ul>

            </nav>

        <?php endif; ?>

    </div>

    <footer class="text-center text-secondary small mt-5">
        &copy; <?= date('Y') ?> DigitalMarket. All rights reserved.
    </footer>

</main>

</body>
</html>
