
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection failed.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/* =========================================
   AUTHENTICATION
========================================= */

$userId = (int)($_SESSION['user_id'] ?? 0);

if ($userId <= 0) {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT *
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (
    !$user ||
    $user['role'] !== 'user' ||
    $user['status'] !== 'active'
) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

/* =========================================
   HELPERS
========================================= */

function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/* =========================================
   CSRF TOKEN
========================================= */

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];

$success = '';
$error = '';

/* =========================================
   PROCESS FORM
========================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        $error = 'Invalid request. Please refresh the page and try again.';

    } else {

        $action = $_POST['action'] ?? '';

        /* UPDATE PROFILE */

        if ($action === 'update_profile') {

            $fullName = trim($_POST['full_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $phone = trim($_POST['phone'] ?? '');

            if ($fullName === '' || $email === '') {

                $error = 'Full name and email are required.';

            } elseif (mb_strlen($fullName) > 150) {

                $error = 'Full name is too long.';

            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

                $error = 'Please enter a valid email address.';

            } elseif (mb_strlen($email) > 150) {

                $error = 'Email address is too long.';

            } elseif (mb_strlen($phone) > 30) {

                $error = 'Phone number is too long.';

            } else {

                /* CHECK DUPLICATE EMAIL */

                $stmt = $pdo->prepare("
                    SELECT id
                    FROM users
                    WHERE email = ?
                    AND id != ?
                    LIMIT 1
                ");

                $stmt->execute([$email, $userId]);

                if ($stmt->fetch()) {

                    $error = 'This email address is already registered.';

                } else {

                    try {

                        $stmt = $pdo->prepare("
                            UPDATE users
                            SET
                                full_name = ?,
                                email = ?,
                                phone = ?
                            WHERE id = ?
                        ");

                        $stmt->execute([
                            $fullName,
                            $email,
                            $phone !== '' ? $phone : null,
                            $userId
                        ]);

                        $success = 'Your profile information has been updated.';

                    } catch (PDOException $ex) {

                        $error = 'Unable to update your profile. Please try again.';

                    }

                }
            }
        }

        /* CHANGE PASSWORD */

        elseif ($action === 'change_password') {

            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';

            if (
                $currentPassword === '' ||
                $newPassword === '' ||
                $confirmPassword === ''
            ) {

                $error = 'Please complete all password fields.';

            } elseif (strlen($newPassword) < 8) {

                $error = 'Your new password must contain at least 8 characters.';

            } elseif ($newPassword !== $confirmPassword) {

                $error = 'New password and confirmation do not match.';

            } elseif (!password_verify($currentPassword, $user['password'])) {

                $error = 'Your current password is incorrect.';

            } else {

                try {

                    $newHash = password_hash(
                        $newPassword,
                        PASSWORD_DEFAULT
                    );

                    $stmt = $pdo->prepare("
                        UPDATE users
                        SET password = ?
                        WHERE id = ?
                    ");

                    $stmt->execute([$newHash, $userId]);

                    $success = 'Your password has been changed successfully.';

                } catch (PDOException $ex) {

                    $error = 'Unable to change your password. Please try again.';

                }

            }
        }

        else {

            $error = 'Invalid form submission.';

        }
    }

    /* REFRESH USER DATA */

    $stmt = $pdo->prepare("
        SELECT *
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    /* ROTATE CSRF TOKEN AFTER POST */

    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $csrfToken = $_SESSION['csrf_token'];
}

/* =========================================
   USER INITIALS
========================================= */

$fullName = trim($user['full_name'] ?? 'User');

$words = preg_split('/\s+/', $fullName);

$initials = '';

foreach (array_slice($words, 0, 2) as $word) {
    $initials .= mb_strtoupper(mb_substr($word, 0, 1));
}

if ($initials === '') {
    $initials = 'U';
}

$createdAt = $user['created_at'] ?? null;

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>My Profile | DigitalMarket</title>

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet">

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
    rel="stylesheet">

<style>

:root {
    --navy: #102747;
    --dark: #0a1b32;
    --gold: #d8aa45;
    --light: #f4f6fa;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: var(--light);
    font-family: Arial, sans-serif;
}

/* SIDEBAR */

.sidebar {
    width: 250px;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    background: var(--dark);
    padding: 24px 16px;
    color: white;
    overflow-y: auto;
    z-index: 1000;
}

.brand {
    font-size: 21px;
    font-weight: 800;
    color: var(--gold);
    margin-bottom: 35px;
    padding: 0 10px;
}

.sidebar a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 14px;
    color: #d9e1ec;
    text-decoration: none;
    border-radius: 8px;
    margin-bottom: 7px;
    transition: .2s;
}

.sidebar a:hover,
.sidebar a.active {
    background: var(--navy);
    color: var(--gold);
}

.sidebar a i {
    font-size: 18px;
}

/* MAIN */

.main {
    margin-left: 250px;
    padding: 30px;
}

.page-title {
    color: var(--navy);
    font-weight: 750;
}

/* PROFILE HEADER */

.profile-header {
    background: linear-gradient(135deg, #102747, #1c426d);
    padding: 30px;
    border-radius: 14px;
    color: white;
    display: flex;
    align-items: center;
    gap: 22px;
    margin-bottom: 25px;
}

.avatar {
    width: 85px;
    height: 85px;
    border-radius: 50%;
    background: var(--gold);
    color: var(--dark);
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 30px;
    font-weight: 800;
    flex-shrink: 0;
}

.profile-name {
    font-size: 24px;
    font-weight: 800;
}

.profile-meta {
    font-size: 14px;
    opacity: .85;
}

/* CONTENT CARDS */

.content-card {
    background: white;
    padding: 25px;
    border-radius: 13px;
    border: 1px solid #e8edf4;
    margin-bottom: 22px;
}

.section-title {
    color: var(--navy);
    font-size: 18px;
    font-weight: 750;
    margin-bottom: 20px;
}

.form-label {
    font-weight: 600;
    color: #35445b;
    font-size: 14px;
}

.form-control {
    padding: 11px 13px;
}

.form-control:focus {
    border-color: var(--gold);
    box-shadow: 0 0 0 .2rem rgba(216,170,69,.15);
}

.btn-market {
    background: var(--navy);
    color: white;
    border: none;
    padding: 11px 20px;
}

.btn-market:hover {
    background: var(--dark);
    color: var(--gold);
}

/* ACCOUNT INFORMATION */

.info-item {
    padding: 13px 0;
    border-bottom: 1px solid #edf0f4;
}

.info-item:last-child {
    border-bottom: none;
}

.info-label {
    color: #7a8798;
    font-size: 13px;
}

.info-value {
    color: var(--navy);
    font-weight: 700;
    margin-top: 4px;
    overflow-wrap: anywhere;
}

/* RESPONSIVE */

@media(max-width: 900px) {

    .sidebar {
        width: 75px;
        padding: 20px 10px;
    }

    .brand {
        font-size: 0;
        text-align: center;
        padding: 0;
    }

    .brand:after {
        content: "DM";
        font-size: 19px;
    }

    .sidebar a {
        justify-content: center;
        font-size: 0;
        padding: 13px 5px;
    }

    .sidebar a i {
        font-size: 21px;
    }

    .main {
        margin-left: 75px;
        padding: 20px;
    }
}

@media(max-width: 576px) {

    .main {
        padding: 14px;
    }

    .profile-header {
        padding: 20px;
        gap: 14px;
    }

    .avatar {
        width: 65px;
        height: 65px;
        font-size: 23px;
    }

    .profile-name {
        font-size: 19px;
    }

    .content-card {
        padding: 18px;
    }
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<aside class="sidebar">

    <div class="brand">
        <i class="bi bi-shop"></i>
        DigitalMarket
    </div>

    <a href="dashboard.php">
        <i class="bi bi-grid"></i>
        Dashboard
    </a>

    

    <a href="profile.php" class="active">
        <i class="bi bi-person"></i>
        My Profile
    </a>

    <hr class="border-secondary">

    <a href="../auth/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        Logout
    </a>

</aside>

<!-- MAIN CONTENT -->

<main class="main">

    <div class="mb-4">

        <h3 class="page-title">
            My Profile
        </h3>

        <p class="text-secondary">
            Manage your personal information and account security.
        </p>

    </div>

    <!-- ALERTS -->

    <?php if ($success): ?>

        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle me-2"></i>
            <?= e($success) ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert">
            </button>
        </div>

    <?php endif; ?>

    <?php if ($error): ?>

        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-circle me-2"></i>
            <?= e($error) ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert">
            </button>
        </div>

    <?php endif; ?>

    <!-- PROFILE HEADER -->

    <div class="profile-header">

        <div class="avatar">
            <?= e($initials) ?>
        </div>

        <div>

            <div class="profile-name">
                <?= e($user['full_name']) ?>
            </div>

            <div class="profile-meta">
                <i class="bi bi-person-circle me-1"></i>
                @<?= e($user['username']) ?>
            </div>

            <div class="profile-meta mt-1">
                <i class="bi bi-patch-check me-1"></i>
                Active User Account
            </div>

        </div>

    </div>

    <div class="row g-4">

        <!-- PROFILE FORM -->

        <div class="col-xl-7">

            <div class="content-card">

                <h5 class="section-title">
                    <i class="bi bi-person-lines-fill me-2"></i>
                    Personal Information
                </h5>

                <form method="POST">

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e($csrfToken) ?>">

                    <input
                        type="hidden"
                        name="action"
                        value="update_profile">

                    <div class="mb-3">

                        <label class="form-label">
                            Full Name
                        </label>

                        <input
                            type="text"
                            name="full_name"
                            class="form-control"
                            maxlength="150"
                            value="<?= e($user['full_name']) ?>"
                            required>

                    </div>

                    <div class="mb-3">

                        <label class="form-label">
                            Username
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= e($user['username']) ?>"
                            readonly>

                        <small class="text-secondary">
                            Your username cannot be changed here.
                        </small>

                    </div>

                    <div class="mb-3">

                        <label class="form-label">
                            Email Address
                        </label>

                        <input
                            type="email"
                            name="email"
                            class="form-control"
                            maxlength="150"
                            value="<?= e($user['email']) ?>"
                            required>

                    </div>

                    <div class="mb-4">

                        <label class="form-label">
                            Phone Number
                        </label>

                        <input
                            type="text"
                            name="phone"
                            class="form-control"
                            maxlength="30"
                            value="<?= e($user['phone']) ?>"
                            placeholder="Enter your phone number">

                    </div>

                    <button type="submit" class="btn btn-market">

                        <i class="bi bi-save me-1"></i>
                        Save Changes

                    </button>

                </form>

            </div>

            <!-- CHANGE PASSWORD -->

            <div class="content-card">

                <h5 class="section-title">
                    <i class="bi bi-shield-lock me-2"></i>
                    Change Password
                </h5>

                <form method="POST">

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e($csrfToken) ?>">

                    <input
                        type="hidden"
                        name="action"
                        value="change_password">

                    <div class="mb-3">

                        <label class="form-label">
                            Current Password
                        </label>

                        <input
                            type="password"
                            name="current_password"
                            class="form-control"
                            autocomplete="current-password"
                            required>

                    </div>

                    <div class="mb-3">

                        <label class="form-label">
                            New Password
                        </label>

                        <input
                            type="password"
                            name="new_password"
                            class="form-control"
                            minlength="8"
                            autocomplete="new-password"
                            required>

                        <small class="text-secondary">
                            Use at least 8 characters.
                        </small>

                    </div>

                    <div class="mb-4">

                        <label class="form-label">
                            Confirm New Password
                        </label>

                        <input
                            type="password"
                            name="confirm_password"
                            class="form-control"
                            minlength="8"
                            autocomplete="new-password"
                            required>

                    </div>

                    <button type="submit" class="btn btn-market">

                        <i class="bi bi-key me-1"></i>
                        Update Password

                    </button>

                </form>

            </div>

        </div>

        <!-- ACCOUNT DETAILS -->

        <div class="col-xl-5">

            <div class="content-card">

                <h5 class="section-title">
                    <i class="bi bi-info-circle me-2"></i>
                    Account Information
                </h5>

                <div class="info-item">

                    <div class="info-label">
                        Account ID
                    </div>

                    <div class="info-value">
                        #<?= (int)$user['id'] ?>
                    </div>

                </div>

                <div class="info-item">

                    <div class="info-label">
                        Username
                    </div>

                    <div class="info-value">
                        <?= e($user['username']) ?>
                    </div>

                </div>

                <div class="info-item">

                    <div class="info-label">
                        Account Role
                    </div>

                    <div class="info-value">
                        <?= e(ucfirst($user['role'])) ?>
                    </div>

                </div>

                <div class="info-item">

                    <div class="info-label">
                        Account Status
                    </div>

                    <div class="info-value">
                        <span class="badge bg-success">
                            <?= e(ucfirst($user['status'])) ?>
                        </span>
                    </div>

                </div>

                <div class="info-item">

                    <div class="info-label">
                        Referral Code
                    </div>

                    <div class="info-value d-flex align-items-center gap-2">

                        <span>
                            <?= e($user['referral_code'] ?? 'Not assigned') ?>
                        </span>

                        <?php if (!empty($user['referral_code'])): ?>

                            <button
                                type="button"
                                class="btn btn-sm btn-outline-secondary"
                                onclick="copyReferral()">

                                <i class="bi bi-copy"></i>

                            </button>

                        <?php endif; ?>

                    </div>

                </div>

                <div class="info-item">

                    <div class="info-label">
                        Registration Date
                    </div>

                    <div class="info-value">

                        <?php if (!empty($createdAt)): ?>

                            <?= e(date('F d, Y', strtotime($createdAt))) ?>

                        <?php else: ?>

                            Not available

                        <?php endif; ?>

                    </div>

                </div>

            </div>

            <!-- SECURITY INFORMATION -->

            <div class="content-card">

                <h5 class="section-title">
                    <i class="bi bi-shield-check me-2"></i>
                    Account Security
                </h5>

                <div class="d-flex align-items-start gap-3">

                    <i class="bi bi-lock-fill text-success fs-3"></i>

                    <div>

                        <div class="fw-bold">
                            Password Protected
                        </div>

                        <small class="text-secondary">
                            Your password is stored as a secure hash.
                        </small>

                    </div>

                </div>

                <hr>

                <div class="d-flex align-items-start gap-3">

                    <i class="bi bi-person-check-fill text-success fs-3"></i>

                    <div>

                        <div class="fw-bold">
                            Active Account
                        </div>

                        <small class="text-secondary">
                            Your account is currently active.
                        </small>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <footer class="text-center text-secondary small mt-4">

        &copy; <?= date('Y') ?> DigitalMarket. All rights reserved.

    </footer>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>

function copyReferral() {

    const referralCode = <?= json_encode(
        (string)($user['referral_code'] ?? '')
    ) ?>;

    if (!referralCode) {
        return;
    }

    if (navigator.clipboard && window.isSecureContext) {

        navigator.clipboard.writeText(referralCode)
            .then(() => alert('Referral code copied successfully.'))
            .catch(() => alert('Unable to copy referral code.'));

    } else {

        const input = document.createElement('textarea');
        input.value = referralCode;
        document.body.appendChild(input);
        input.select();

        try {
            document.execCommand('copy');
            alert('Referral code copied successfully.');
        } catch (error) {
            alert('Unable to copy referral code.');
        }

        input.remove();
    }
}

</script>

</body>
</html>
