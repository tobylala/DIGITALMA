
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection failed. Check config/database.php.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

/* ---------------------------------------------
   USER AUTHENTICATION
--------------------------------------------- */

if (empty($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

$userStmt = $pdo->prepare("
    SELECT id, full_name, username, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$userStmt->execute([$userId]);
$user = $userStmt->fetch();

if (!$user || $user['status'] !== 'active') {
    session_unset();
    session_destroy();
    header('Location: ../auth/login.php');
    exit;
}

/* ---------------------------------------------
   HELPERS
--------------------------------------------- */

function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function money($value): string
{
    return number_format((float)$value, 2);
}

function redirectToDeposits(): never
{
    header('Location: ' . ($_SERVER['SCRIPT_NAME'] ?? 'deposits.php'));
    exit;
}

/* ---------------------------------------------
   CSRF
--------------------------------------------- */

if (empty($_SESSION['deposit_csrf'])) {
    $_SESSION['deposit_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['deposit_csrf'];
$minimumDeposit = 500;

$message = '';
$messageType = 'success';

/* ---------------------------------------------
   LOAD COMPANY PAYMENT ACCOUNTS
--------------------------------------------- */

$methodsStmt = $pdo->query("
    SELECT
        id,
        method_name,
        account_name,
        account_number,
        instructions
    FROM payment_methods
    WHERE status = 'active'
      AND method_type IN ('deposit', 'both')
    ORDER BY id DESC
");

$paymentMethods = $methodsStmt->fetchAll();

/* ---------------------------------------------
   HANDLE DEPOSIT SUBMISSION
--------------------------------------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadedFile = null;

    try {
        if (
            !isset($_POST['csrf_token']) ||
            !is_string($_POST['csrf_token']) ||
            !hash_equals($csrfToken, $_POST['csrf_token'])
        ) {
            throw new RuntimeException('Security verification failed. Refresh the page and try again.');
        }

        $paymentMethodId = filter_var(
            $_POST['payment_method_id'] ?? '',
            FILTER_VALIDATE_INT
        );

        $amountInput = trim((string)($_POST['amount'] ?? ''));
        $transactionId = trim((string)($_POST['transaction_id'] ?? ''));

        if (!$paymentMethodId || $paymentMethodId < 1) {
            throw new RuntimeException('Please select a company payment account.');
        }

        if (!preg_match('/^\d{1,10}(\.\d{1,2})?$/', $amountInput)) {
            throw new RuntimeException('Enter a valid deposit amount.');
        }

        $amount = (float)$amountInput;

        if ($amount < $minimumDeposit) {
            throw new RuntimeException('The minimum deposit amount is ' . money($minimumDeposit) . ' ETB.');
        }

        if ($amount > 999999999) {
            throw new RuntimeException('The deposit amount is too large.');
        }

        if ($transactionId === '' || mb_strlen($transactionId) > 150) {
            throw new RuntimeException('Enter a valid transaction ID (maximum 150 characters).');
        }

        /* Confirm that the selected company account is active. */
        $methodStmt = $pdo->prepare("
            SELECT id, method_name, account_name, account_number
            FROM payment_methods
            WHERE id = ?
              AND status = 'active'
              AND method_type IN ('deposit', 'both')
            LIMIT 1
        ");
        $methodStmt->execute([$paymentMethodId]);
        $selectedMethod = $methodStmt->fetch();

        if (!$selectedMethod) {
            throw new RuntimeException('The selected payment account is no longer available. Refresh the page.');
        }

        /* Check duplicate transaction ID. */
        $duplicateStmt = $pdo->prepare("
            SELECT id
            FROM deposits
            WHERE transaction_id = ?
            LIMIT 1
        ");
        $duplicateStmt->execute([$transactionId]);

        if ($duplicateStmt->fetch()) {
            throw new RuntimeException('This transaction ID has already been submitted.');
        }

        /* Optional payment proof upload. */
        $proofPath = null;

        if (
            isset($_FILES['proof']) &&
            $_FILES['proof']['error'] !== UPLOAD_ERR_NO_FILE
        ) {
            $file = $_FILES['proof'];

            if ($file['error'] !== UPLOAD_ERR_OK) {
                throw new RuntimeException('There was a problem uploading your payment proof.');
            }

            if ($file['size'] > 5 * 1024 * 1024) {
                throw new RuntimeException('The payment proof must not exceed 5 MB.');
            }

            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($file['tmp_name']);

            $allowedTypes = [
                'image/jpeg' => 'jpg',
                'image/png'  => 'png',
                'image/webp' => 'webp',
                'application/pdf' => 'pdf'
            ];

            if (!isset($allowedTypes[$mime])) {
                throw new RuntimeException('Only JPG, PNG, WEBP, and PDF files are allowed.');
            }

            $uploadDirectory = __DIR__ . '/../uploads/deposit_proofs/';

            if (
                !is_dir($uploadDirectory) &&
                !mkdir($uploadDirectory, 0755, true)
            ) {
                throw new RuntimeException('Could not create the payment proof upload directory.');
            }

            $fileName = bin2hex(random_bytes(20)) . '.' . $allowedTypes[$mime];
            $destination = $uploadDirectory . $fileName;

            if (!move_uploaded_file($file['tmp_name'], $destination)) {
                throw new RuntimeException('Could not save the payment proof.');
            }

            $uploadedFile = $destination;
            $proofPath = 'uploads/deposit_proofs/' . $fileName;
        }

        /* Insert deposit request. No wallet credit happens here. */
        $pdo->beginTransaction();

        $insertStmt = $pdo->prepare("
            INSERT INTO deposits
            (
                user_id,
                payment_method_id,
                amount,
                transaction_id,
                proof_path,
                status
            )
            VALUES (?, ?, ?, ?, ?, 'pending')
        ");

        $insertStmt->execute([
            $userId,
            $paymentMethodId,
            $amount,
            $transactionId,
            $proofPath
        ]);

        $pdo->commit();

        $_SESSION['deposit_csrf'] = bin2hex(random_bytes(32));

        $_SESSION['deposit_flash'] = [
            'type' => 'success',
            'message' => 'Your deposit request has been submitted. The administrator will verify your payment before adding money to your wallet.'
        ];

        redirectToDeposits();

    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        if ($uploadedFile && is_file($uploadedFile)) {
            @unlink($uploadedFile);
        }

        $message = $ex instanceof PDOException
            ? 'The deposit request could not be saved. Please check your information and try again.'
            : $ex->getMessage();

        $messageType = 'error';
    }
}

/* ---------------------------------------------
   FLASH MESSAGE
--------------------------------------------- */

if (!empty($_SESSION['deposit_flash'])) {
    $message = $_SESSION['deposit_flash']['message'];
    $messageType = $_SESSION['deposit_flash']['type'];
    unset($_SESSION['deposit_flash']);
}

/* ---------------------------------------------
   WALLET BALANCE
--------------------------------------------- */

$walletStmt = $pdo->prepare("
    SELECT balance, reserved_balance
    FROM wallet_accounts
    WHERE user_id = ?
      AND wallet_type = 'purchase'
    LIMIT 1
");
$walletStmt->execute([$userId]);
$wallet = $walletStmt->fetch();

$walletBalance = (float)($wallet['balance'] ?? 0);
$walletReserved = (float)($wallet['reserved_balance'] ?? 0);
$availableBalance = max(0, $walletBalance - $walletReserved);

/* ---------------------------------------------
   DEPOSIT STATISTICS
--------------------------------------------- */

$statsStmt = $pdo->prepare("
    SELECT
        COUNT(*) AS total_requests,
        COALESCE(SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END), 0) AS pending_amount,
        COALESCE(SUM(CASE WHEN status = 'approved' THEN amount ELSE 0 END), 0) AS approved_amount,
        COALESCE(SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END), 0) AS rejected_count
    FROM deposits
    WHERE user_id = ?
");
$statsStmt->execute([$userId]);
$stats = $statsStmt->fetch();

/* ---------------------------------------------
   DEPOSIT HISTORY
--------------------------------------------- */

$historyStmt = $pdo->prepare("
    SELECT
        d.id,
        d.amount,
        d.transaction_id,
        d.proof_path,
        d.status,
        d.admin_note,
        d.created_at,
        d.reviewed_at,
        pm.method_name
    FROM deposits d
    LEFT JOIN payment_methods pm
        ON pm.id = d.payment_method_id
    WHERE d.user_id = ?
    ORDER BY d.id DESC
    LIMIT 30
");
$historyStmt->execute([$userId]);
$deposits = $historyStmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit Money | DigitalMarket</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: #f5f6fa;
            color: #20243a;
            font-family: 'Inter', sans-serif;
        }

        .sidebar {
            position: fixed;
            inset: 0 auto 0 0;
            width: 255px;
            padding: 27px 17px;
            background: #171b2e;
            color: white;
            overflow-y: auto;
        }

        .brand {
            font-size: 23px;
            font-weight: 800;
            padding: 0 12px;
            margin-bottom: 38px;
        }

        .brand span { color: #8b83ff; }

        .nav-label {
            color: #858ba2;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.2px;
            text-transform: uppercase;
            margin: 23px 12px 10px;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            margin-bottom: 5px;
            border-radius: 8px;
            color: #c3c7d7;
            text-decoration: none;
            font-size: 13px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #292e49;
            color: white;
        }

        .sidebar a.active { border-left: 3px solid #8b83ff; }

        .main {
            margin-left: 255px;
            padding: 30px;
            max-width: 1600px;
        }

        .page-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
        }

        .page-heading h1 {
            font-size: 25px;
            font-weight: 800;
            margin: 0 0 7px;
        }

        .muted { color: #858ba0; font-size: 12px; }

        .card-box {
            background: white;
            border: 1px solid #eceef4;
            border-radius: 13px;
            padding: 22px;
            margin-bottom: 22px;
        }

        .balance-card {
            background: linear-gradient(120deg, #635bff, #827bff);
            color: white;
            border: 0;
        }

        .balance-card .muted { color: #e1dfff; }

        .balance-amount {
            font-size: 29px;
            font-weight: 800;
            margin-top: 8px;
        }

        .stat-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-bottom: 22px;
        }

        .stat-card {
            background: white;
            border: 1px solid #eceef4;
            border-radius: 12px;
            padding: 18px;
        }

        .stat-card small { color: #858ba0; font-size: 11px; }
        .stat-card h3 { font-size: 21px; font-weight: 800; margin: 9px 0 0; }

        .section-title {
            font-size: 16px;
            font-weight: 800;
            margin-bottom: 7px;
        }

        .payment-method {
            border: 1px solid #e6e8f0;
            border-radius: 11px;
            padding: 17px;
            height: 100%;
            background: #fff;
        }

        .payment-method .method-name {
            font-weight: 800;
            font-size: 15px;
            margin-bottom: 13px;
        }

        .account-label {
            display: block;
            font-size: 10px;
            color: #858ba0;
            text-transform: uppercase;
            font-weight: 700;
            margin: 10px 0 4px;
        }

        .account-value {
            font-size: 14px;
            font-weight: 700;
            overflow-wrap: anywhere;
        }

        .instructions {
            background: #f7f7ff;
            border-radius: 8px;
            padding: 11px;
            color: #555b76;
            font-size: 12px;
            line-height: 1.6;
            margin-top: 12px;
            white-space: pre-line;
        }

        .form-label {
            font-size: 12px;
            font-weight: 700;
        }

        .form-control, .form-select {
            padding: 12px;
            border-radius: 8px;
            font-size: 13px;
            border-color: #e1e4ed;
        }

        .form-control:focus, .form-select:focus {
            border-color: #635bff;
            box-shadow: 0 0 0 3px rgba(99,91,255,.10);
        }

        .btn-purple {
            background: #635bff;
            color: white;
            border: 0;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 700;
        }

        .btn-purple:hover { background: #5048e5; color: white; }

        .alert {
            border: 0;
            border-radius: 9px;
            font-size: 13px;
        }

        .status {
            display: inline-block;
            border-radius: 30px;
            padding: 5px 10px;
            font-size: 10px;
            font-weight: 800;
            text-transform: capitalize;
        }

        .status.pending { background: #fff3d8; color: #9b6900; }
        .status.approved { background: #e2f8eb; color: #168047; }
        .status.rejected { background: #ffebeb; color: #b52f39; }

        .table { font-size: 12px; vertical-align: middle; }
        .table thead th {
            background: #f7f8fb;
            color: #737b91;
            font-size: 10px;
            text-transform: uppercase;
            white-space: nowrap;
            padding: 13px;
        }
        .table td { padding: 14px 13px; }

        .empty {
            text-align: center;
            padding: 28px;
            color: #858ba0;
            font-size: 13px;
        }

        @media(max-width: 900px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
            }
            .main { margin-left: 0; padding: 18px; }
            .stat-grid { grid-template-columns: 1fr 1fr; }
        }

        @media(max-width: 550px) {
            .stat-grid { grid-template-columns: 1fr; }
            .page-heading { align-items: flex-start; flex-direction: column; }
        }
    </style>
</head>

<body>

<aside class="sidebar">
    <div class="brand">Digital<span>Market</span></div>

    <div class="nav-label">Main Menu</div>
    <a href="dashboard.php"><i class="bi bi-grid"></i> Dashboard</a>
   
    <a href="deposits.php" class="active"><i class="bi bi-plus-circle"></i> Deposit Money</a>
   
    <a href="../auth/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</aside>

<main class="main">

    <div class="page-heading">
        <div>
            <h1>Deposit Money</h1>
            <div class="muted">Recharge your purchase wallet using the company's official payment accounts.</div>
        </div>
        <div class="muted">
            Welcome, <strong><?= e($user['full_name']) ?></strong>
        </div>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?= $messageType === 'success' ? 'success' : 'danger' ?>">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <div class="row g-3 mb-3">
        <div class="col-lg-4">
            <div class="card-box balance-card h-100 mb-0">
                <div class="muted">Available Purchase Wallet</div>
                <div class="balance-amount"><?= money($availableBalance) ?> ETB</div>
                <div class="muted mt-2">Your current available balance</div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="stat-grid h-100 mb-0">
                <div class="stat-card">
                    <small>Total Deposit Requests</small>
                    <h3><?= (int)$stats['total_requests'] ?></h3>
                </div>
                <div class="stat-card">
                    <small>Pending Deposit Value</small>
                    <h3><?= money($stats['pending_amount']) ?> ETB</h3>
                </div>
                <div class="stat-card">
                    <small>Approved Deposit Value</small>
                    <h3><?= money($stats['approved_amount']) ?> ETB</h3>
                </div>
            </div>
        </div>
    </div>

    <!-- COMPANY PAYMENT ACCOUNTS -->

    <section class="card-box">
        <h2 class="section-title">Company Payment Accounts</h2>
        <p class="muted mb-3">
            Transfer your deposit to one of the official accounts below. Make sure the account details match before sending money.
        </p>

        <?php if (!$paymentMethods): ?>
            <div class="alert alert-warning mb-0">
                <strong>Deposits are temporarily unavailable.</strong>
                The company has not configured an active deposit payment account yet. Please contact the administrator.
            </div>
        <?php else: ?>
            <div class="row g-3">
                <?php foreach ($paymentMethods as $method): ?>
                    <div class="col-lg-6">
                        <div class="payment-method">
                            <div class="method-name">
                                <i class="bi bi-bank me-2"></i>
                                <?= e($method['method_name']) ?>
                            </div>

                            <span class="account-label">Account Name</span>
                            <div class="account-value">
                                <?= e($method['account_name'] ?: 'Not provided') ?>
                            </div>

                            <span class="account-label">Account Number</span>
                            <div class="account-value">
                                <?= e($method['account_number'] ?: 'Not provided') ?>
                            </div>

                            <?php if (!empty($method['instructions'])): ?>
                                <div class="instructions">
                                    <strong>Payment Instructions</strong><br>
                                    <?= e($method['instructions']) ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- SUBMIT DEPOSIT -->

    <section class="card-box">
        <h2 class="section-title">Submit Deposit Request</h2>
        <p class="muted mb-4">
            After transferring the money to a company account, complete this form. Your wallet will be credited after administrator verification.
        </p>

        <?php if ($paymentMethods): ?>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Select Company Payment Account</label>
                        <select name="payment_method_id" class="form-select" required>
                            <option value="">Choose payment account</option>
                            <?php foreach ($paymentMethods as $method): ?>
                                <option value="<?= (int)$method['id'] ?>">
                                    <?= e($method['method_name']) ?>
                                    — <?= e($method['account_number']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Deposit Amount (ETB)</label>
                        <input
                            type="number"
                            name="amount"
                            class="form-control"
                            min="<?= $minimumDeposit ?>"
                            max="999999999"
                            step="0.01"
                            placeholder="Minimum <?= money($minimumDeposit) ?> ETB"
                            required
                        >
                        <small class="muted">Minimum deposit: <?= money($minimumDeposit) ?> ETB</small>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Transaction ID / Reference Number</label>
                        <input
                            type="text"
                            name="transaction_id"
                            class="form-control"
                            maxlength="150"
                            placeholder="Enter the transaction reference"
                            required
                        >
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Payment Screenshot / Receipt</label>
                        <input
                            type="file"
                            name="proof"
                            class="form-control"
                            accept=".jpg,.jpeg,.png,.webp,.pdf"
                        >
                        <small class="muted">Optional. JPG, PNG, WEBP or PDF. Maximum 5 MB.</small>
                    </div>

                    <div class="col-12">
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle me-1"></i>
                            Do not submit a deposit request before making the actual transfer. Your purchase wallet will not be credited until an administrator verifies your payment.
                        </div>
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn-purple" onclick="return confirm('Have you transferred the money to the selected company account?');">
                            <i class="bi bi-send me-1"></i> Submit Deposit Request
                        </button>
                    </div>
                </div>
            </form>
        <?php else: ?>
            <p class="muted mb-0">The deposit form will become available when the administrator configures a company payment account.</p>
        <?php endif; ?>
    </section>

    <!-- DEPOSIT HISTORY -->

    <section class="card-box">
        <h2 class="section-title">My Deposit History</h2>
        <p class="muted mb-3">Your recent deposit submissions and their review status.</p>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Request</th>
                        <th>Payment Method</th>
                        <th>Amount</th>
                        <th>Transaction ID</th>
                        <th>Status</th>
                        <th>Admin Note</th>
                        <th>Submitted</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$deposits): ?>
                        <tr>
                            <td colspan="7" class="empty">You have not submitted any deposit requests yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($deposits as $deposit): ?>
                            <tr>
                                <td>#<?= (int)$deposit['id'] ?></td>
                                <td><?= e($deposit['method_name'] ?? 'Payment method') ?></td>
                                <td><strong><?= money($deposit['amount']) ?> ETB</strong></td>
                                <td><?= e($deposit['transaction_id']) ?></td>
                                <td>
                                    <span class="status <?= e($deposit['status']) ?>">
                                        <?= e($deposit['status']) ?>
                                    </span>
                                </td>
                                <td><?= e($deposit['admin_note'] ?: '—') ?></td>
                                <td><?= e($deposit['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</main>

</body>
</html>
