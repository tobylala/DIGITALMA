
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection is not available.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

if (!isset($_SESSION['user_id'])) {
    header('Location: /digital_marketplace/auth/login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$selfUrl = '/digital_marketplace/user/withdrawal.php';

const MINIMUM_WITHDRAWAL = 300.00;

/* =====================================================
   HELPERS
===================================================== */

function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function money($amount): string
{
    return number_format((float)$amount, 2) . ' ETB';
}

function redirectPage(string $query = ''): void
{
    header('Location: /digital_marketplace/user/withdrawal.php' .
        ($query !== '' ? '?' . $query : ''));
    exit;
}

function statusBadge(string $status): string
{
    $classes = [
        'pending'  => 'warning',
        'approved' => 'info',
        'paid'     => 'success',
        'rejected' => 'danger'
    ];

    $class = $classes[$status] ?? 'secondary';

    return '<span class="badge rounded-pill text-bg-' . $class . '">' .
        e(ucfirst($status)) . '</span>';
}

/* =====================================================
   CREATE WITHDRAWAL ALLOCATION TABLE
===================================================== */

$pdo->exec("
    CREATE TABLE IF NOT EXISTS withdrawal_wallet_allocations (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        withdrawal_id INT UNSIGNED NOT NULL,
        wallet_id INT UNSIGNED NOT NULL,
        wallet_type ENUM('purchase','commission') NOT NULL,
        amount DECIMAL(15,2) NOT NULL,
        created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_withdrawal_wallet (withdrawal_id, wallet_id),
        INDEX idx_withdrawal_id (withdrawal_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

/* =====================================================
   CSRF PROTECTION
===================================================== */

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];
$error = '';
$success = '';

/* =====================================================
   VERIFY USER
===================================================== */

$stmt = $pdo->prepare("
    SELECT id, full_name, username, status
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user || $user['status'] !== 'active') {
    session_destroy();
    header('Location: /digital_marketplace/auth/login.php');
    exit;
}

/* =====================================================
   PROCESS FORMS
===================================================== */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (
        !isset($_POST['csrf_token']) ||
        !hash_equals($csrfToken, (string)$_POST['csrf_token'])
    ) {
        $error = 'Invalid security token. Refresh the page and try again.';
    } else {

        $action = $_POST['action'] ?? '';

        /* ---------------------------------------------
           ADD RECEIVING ACCOUNT
        --------------------------------------------- */

        if ($action === 'add_account') {

            $accountType = trim($_POST['account_type'] ?? '');
            $accountName = trim($_POST['account_name'] ?? '');
            $accountNumber = trim($_POST['account_number'] ?? '');

            if (!in_array($accountType, ['Telebirr', 'CBE'], true)) {
                $error = 'Please select a valid account type.';
            } elseif ($accountName === '' || $accountNumber === '') {
                $error = 'Please enter your account name and number.';
            } elseif (
                strlen($accountName) > 150 ||
                strlen($accountNumber) > 50
            ) {
                $error = 'Account information is too long.';
            } else {
                try {
                    $stmt = $pdo->prepare("
                        SELECT id
                        FROM user_payment_accounts
                        WHERE user_id = ?
                          AND account_type = ?
                          AND account_number = ?
                          AND status = 'active'
                        LIMIT 1
                    ");

                    $stmt->execute([
                        $userId,
                        $accountType,
                        $accountNumber
                    ]);

                    if ($stmt->fetch()) {
                        $error = 'This payment account already exists.';
                    } else {
                        $stmt = $pdo->prepare("
                            INSERT INTO user_payment_accounts
                            (
                                user_id,
                                account_type,
                                account_name,
                                account_number,
                                is_default,
                                status
                            )
                            VALUES (?, ?, ?, ?, 0, 'active')
                        ");

                        $stmt->execute([
                            $userId,
                            $accountType,
                            $accountName,
                            $accountNumber
                        ]);

                        redirectPage('success=account_added');
                    }
                } catch (PDOException $ex) {
                    $error = 'Unable to save your account. Please try again.';
                }
            }
        }

        /* ---------------------------------------------
           SET DEFAULT ACCOUNT
        --------------------------------------------- */

        elseif ($action === 'set_default') {

            $accountId = (int)($_POST['account_id'] ?? 0);

            try {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare("
                    SELECT id
                    FROM user_payment_accounts
                    WHERE id = ?
                      AND user_id = ?
                      AND status = 'active'
                    FOR UPDATE
                ");

                $stmt->execute([$accountId, $userId]);

                if (!$stmt->fetch()) {
                    throw new Exception('Selected account is not available.');
                }

                $stmt = $pdo->prepare("
                    UPDATE user_payment_accounts
                    SET is_default = 0
                    WHERE user_id = ?
                ");
                $stmt->execute([$userId]);

                $stmt = $pdo->prepare("
                    UPDATE user_payment_accounts
                    SET is_default = 1
                    WHERE id = ?
                      AND user_id = ?
                      AND status = 'active'
                ");
                $stmt->execute([$accountId, $userId]);

                $pdo->commit();

                redirectPage('success=default_updated');

            } catch (Throwable $ex) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $error = $ex instanceof PDOException
                    ? 'Unable to update the default account.'
                    : $ex->getMessage();
            }
        }

        /* ---------------------------------------------
           REMOVE ACCOUNT
        --------------------------------------------- */

        elseif ($action === 'delete_account') {

            $accountId = (int)($_POST['account_id'] ?? 0);

            try {
                $stmt = $pdo->prepare("
                    UPDATE user_payment_accounts
                    SET status = 'inactive',
                        is_default = 0
                    WHERE id = ?
                      AND user_id = ?
                ");

                $stmt->execute([$accountId, $userId]);

                if ($stmt->rowCount() > 0) {
                    redirectPage('success=account_deleted');
                } else {
                    $error = 'Account not found.';
                }

            } catch (PDOException $ex) {
                $error = 'Unable to remove the account.';
            }
        }

        /* ---------------------------------------------
           SUBMIT COMBINED WALLET WITHDRAWAL
        --------------------------------------------- */

        elseif ($action === 'submit_withdrawal') {

            $accountId = (int)($_POST['account_id'] ?? 0);
            $paymentMethodId = (int)($_POST['payment_method_id'] ?? 0);
            $amountInput = trim((string)($_POST['amount'] ?? ''));

            if (
                $amountInput === '' ||
                !is_numeric($amountInput) ||
                !is_finite((float)$amountInput)
            ) {
                $error = 'Please enter a valid withdrawal amount.';
            } elseif ((float)$amountInput < MINIMUM_WITHDRAWAL) {
                $error = 'Minimum withdrawal amount is 300 ETB.';
            } elseif ((float)$amountInput > 100000000) {
                $error = 'The amount is too large.';
            } elseif ($accountId <= 0 || $paymentMethodId <= 0) {
                $error = 'Select your receiving account and payment method.';
            } else {

                $amount = round((float)$amountInput, 2);

                try {
                    $pdo->beginTransaction();

                    /* LOCK BOTH WALLETS */

                    $stmt = $pdo->prepare("
                        SELECT id, wallet_type, balance, reserved_balance
                        FROM wallet_accounts
                        WHERE user_id = ?
                          AND wallet_type IN ('purchase', 'commission')
                        ORDER BY
                            CASE wallet_type
                                WHEN 'purchase' THEN 1
                                WHEN 'commission' THEN 2
                                ELSE 3
                            END
                        FOR UPDATE
                    ");

                    $stmt->execute([$userId]);
                    $walletRows = $stmt->fetchAll();

                    $wallets = [
                        'purchase' => null,
                        'commission' => null
                    ];

                    foreach ($walletRows as $walletRow) {
                        $wallets[$walletRow['wallet_type']] = $walletRow;
                    }

                    $purchaseAvailable = 0.00;
                    $commissionAvailable = 0.00;

                    foreach (['purchase', 'commission'] as $type) {

                        if (!$wallets[$type]) {
                            continue;
                        }

                        $available =
                            (float)$wallets[$type]['balance'] -
                            (float)$wallets[$type]['reserved_balance'];

                        if ($type === 'purchase') {
                            $purchaseAvailable = max(0, $available);
                        } else {
                            $commissionAvailable = max(0, $available);
                        }
                    }

                    $totalAvailable = round(
                        $purchaseAvailable + $commissionAvailable,
                        2
                    );

                    /* SERVER-SIDE MINIMUM AND BALANCE CHECK */

                    if ($amount < MINIMUM_WITHDRAWAL) {
                        throw new Exception(
                            'Minimum withdrawal amount is ' .
                            money(MINIMUM_WITHDRAWAL) . '.'
                        );
                    }

                    if ($totalAvailable < MINIMUM_WITHDRAWAL) {
                        throw new Exception(
                            'Your combined balance is below the minimum withdrawal amount of 300 ETB.'
                        );
                    }

                    if ($amount > $totalAvailable) {
                        throw new Exception(
                            'Insufficient combined wallet balance. Available: ' .
                            money($totalAvailable)
                        );
                    }

                    /* VERIFY RECEIVING ACCOUNT */

                    $stmt = $pdo->prepare("
                        SELECT id, account_type, account_name, account_number
                        FROM user_payment_accounts
                        WHERE id = ?
                          AND user_id = ?
                          AND status = 'active'
                        LIMIT 1
                        FOR UPDATE
                    ");

                    $stmt->execute([$accountId, $userId]);
                    $account = $stmt->fetch();

                    if (!$account) {
                        throw new Exception('Selected receiving account is invalid.');
                    }

                    /* VERIFY PAYMENT METHOD */

                    $stmt = $pdo->prepare("
                        SELECT id, method_name
                        FROM payment_methods
                        WHERE id = ?
                          AND status = 'active'
                          AND method_type IN ('withdrawal', 'both')
                        LIMIT 1
                    ");

                    $stmt->execute([$paymentMethodId]);
                    $paymentMethod = $stmt->fetch();

                    if (!$paymentMethod) {
                        throw new Exception(
                            'Selected withdrawal payment method is unavailable.'
                        );
                    }

                    /* ALLOCATE WITHDRAWAL: PURCHASE FIRST */

                    $remaining = $amount;
                    $allocations = [];

                    foreach (['purchase', 'commission'] as $type) {

                        if ($remaining <= 0) {
                            break;
                        }

                        if (!$wallets[$type]) {
                            continue;
                        }

                        $wallet = $wallets[$type];

                        $available = max(
                            0,
                            (float)$wallet['balance'] -
                            (float)$wallet['reserved_balance']
                        );

                        $take = round(min($available, $remaining), 2);

                        if ($take > 0) {
                            $allocations[] = [
                                'wallet_id' => (int)$wallet['id'],
                                'wallet_type' => $type,
                                'amount' => $take,
                                'balance' => (float)$wallet['balance']
                            ];

                            $remaining = round($remaining - $take, 2);
                        }
                    }

                    if ($remaining > 0) {
                        throw new Exception('Unable to allocate the withdrawal amount.');
                    }

                    $primaryWalletType = $allocations[0]['wallet_type'];

                    $allocationDescription = [];

                    foreach ($allocations as $allocation) {
                        $allocationDescription[] =
                            ucfirst($allocation['wallet_type']) .
                            ': ' . number_format($allocation['amount'], 2) . ' ETB';
                    }

                    $accountDetails =
                        'Account type: ' . $account['account_type'] .
                        ' | Account name: ' . $account['account_name'] .
                        ' | Account number: ' . $account['account_number'] .
                        ' | Payment method: ' . $paymentMethod['method_name'] .
                        ' | Wallet allocation: ' .
                        implode(', ', $allocationDescription);

                    /* INSERT WITHDRAWAL */

                    $stmt = $pdo->prepare("
                        INSERT INTO withdrawals
                        (
                            user_id,
                            wallet_type,
                            amount,
                            payment_method_id,
                            account_details,
                            status,
                            created_at
                        )
                        VALUES (?, ?, ?, ?, ?, 'pending', NOW())
                    ");

                    $stmt->execute([
                        $userId,
                        $primaryWalletType,
                        $amount,
                        $paymentMethodId,
                        $accountDetails
                    ]);

                    $withdrawalId = (int)$pdo->lastInsertId();

                    /* RESERVE EACH WALLET ALLOCATION */

                    foreach ($allocations as $allocation) {

                        $stmt = $pdo->prepare("
                            UPDATE wallet_accounts
                            SET reserved_balance = reserved_balance + ?
                            WHERE id = ?
                              AND user_id = ?
                        ");

                        $stmt->execute([
                            $allocation['amount'],
                            $allocation['wallet_id'],
                            $userId
                        ]);

                        if ($stmt->rowCount() !== 1) {
                            throw new Exception('Unable to reserve wallet funds.');
                        }

                        /* SAVE ALLOCATION */

                        $stmt = $pdo->prepare("
                            INSERT INTO withdrawal_wallet_allocations
                            (
                                withdrawal_id,
                                wallet_id,
                                wallet_type,
                                amount
                            )
                            VALUES (?, ?, ?, ?)
                        ");

                        $stmt->execute([
                            $withdrawalId,
                            $allocation['wallet_id'],
                            $allocation['wallet_type'],
                            $allocation['amount']
                        ]);

                        /* RECORD RESERVE TRANSACTION */

                        $stmt = $pdo->prepare("
                            INSERT INTO wallet_transactions
                            (
                                wallet_id,
                                transaction_type,
                                amount,
                                balance_after,
                                reference_type,
                                reference_id,
                                idempotency_key,
                                description,
                                created_at
                            )
                            VALUES (
                                ?, 'reserve', ?, ?,
                                'withdrawal', ?, ?, ?, NOW()
                            )
                        ");

                        $stmt->execute([
                            $allocation['wallet_id'],
                            $allocation['amount'],
                            $allocation['balance'],
                            $withdrawalId,
                            'withdrawal_reserve_' .
                                $withdrawalId . '_' .
                                $allocation['wallet_type'],
                            'Withdrawal request #' . $withdrawalId .
                                ' (' . $allocation['wallet_type'] . ')'
                        ]);
                    }

                    $pdo->commit();

                    redirectPage('success=withdrawal_submitted');

                } catch (Throwable $ex) {

                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    $error = $ex instanceof PDOException
                        ? 'Database error while submitting the withdrawal. Please check your database tables.'
                        : $ex->getMessage();
                }
            }
        }
    }
}

/* =====================================================
   SUCCESS MESSAGES
===================================================== */

if (isset($_GET['success'])) {

    $messages = [
        'account_added' => 'Payment account added successfully.',
        'default_updated' => 'Default account updated successfully.',
        'account_deleted' => 'Payment account removed successfully.',
        'withdrawal_submitted' => 'Your combined-wallet withdrawal request has been submitted successfully.'
    ];

    $success = $messages[$_GET['success']] ?? '';
}

/* =====================================================
   GET WALLET BALANCES
===================================================== */

$stmt = $pdo->prepare("
    SELECT wallet_type, balance, reserved_balance
    FROM wallet_accounts
    WHERE user_id = ?
");

$stmt->execute([$userId]);

$wallets = [
    'purchase' => ['balance' => 0, 'reserved_balance' => 0],
    'commission' => ['balance' => 0, 'reserved_balance' => 0]
];

foreach ($stmt->fetchAll() as $row) {

    if (isset($wallets[$row['wallet_type']])) {
        $wallets[$row['wallet_type']] = [
            'balance' => (float)$row['balance'],
            'reserved_balance' => (float)$row['reserved_balance']
        ];
    }
}

$purchaseAvailable = max(
    0,
    $wallets['purchase']['balance'] -
    $wallets['purchase']['reserved_balance']
);

$commissionAvailable = max(
    0,
    $wallets['commission']['balance'] -
    $wallets['commission']['reserved_balance']
);

$totalBalance = round(
    $wallets['purchase']['balance'] +
    $wallets['commission']['balance'],
    2
);

$totalReserved = round(
    $wallets['purchase']['reserved_balance'] +
    $wallets['commission']['reserved_balance'],
    2
);

$totalAvailable = round(
    $purchaseAvailable + $commissionAvailable,
    2
);

/* =====================================================
   RECEIVING ACCOUNTS
===================================================== */

$stmt = $pdo->prepare("
    SELECT *
    FROM user_payment_accounts
    WHERE user_id = ?
      AND status = 'active'
    ORDER BY is_default DESC, id DESC
");

$stmt->execute([$userId]);
$accounts = $stmt->fetchAll();

/* =====================================================
   PAYMENT METHODS
===================================================== */

$stmt = $pdo->query("
    SELECT id, method_name, account_name, account_number, instructions
    FROM payment_methods
    WHERE status = 'active'
      AND method_type IN ('withdrawal', 'both')
    ORDER BY method_name ASC
");

$paymentMethods = $stmt->fetchAll();

/* =====================================================
   WITHDRAWAL HISTORY
===================================================== */

$stmt = $pdo->prepare("
    SELECT
        w.id,
        w.amount,
        w.wallet_type,
        w.account_details,
        w.status,
        w.admin_note,
        w.payment_reference,
        w.created_at,
        w.reviewed_at,
        pm.method_name
    FROM withdrawals w
    LEFT JOIN payment_methods pm
        ON pm.id = w.payment_method_id
    WHERE w.user_id = ?
    ORDER BY w.id DESC
    LIMIT 50
");

$stmt->execute([$userId]);
$withdrawals = $stmt->fetchAll();

/* =====================================================
   WITHDRAWAL STATISTICS
===================================================== */

$stmt = $pdo->prepare("
    SELECT
        COALESCE(SUM(amount), 0) AS total_requested,

        COALESCE(SUM(
            CASE WHEN status = 'pending'
            THEN amount ELSE 0 END
        ), 0) AS pending_amount,

        COALESCE(SUM(
            CASE WHEN status = 'approved'
            THEN amount ELSE 0 END
        ), 0) AS approved_amount,

        COALESCE(SUM(
            CASE WHEN status = 'paid'
            THEN amount ELSE 0 END
        ), 0) AS paid_amount

    FROM withdrawals
    WHERE user_id = ?
");

$stmt->execute([$userId]);
$withdrawalStats = $stmt->fetch();

$totalWithdrawals = (float)$withdrawalStats['total_requested'];
$pendingWithdrawals = (float)$withdrawalStats['pending_amount'];
$approvedWithdrawals = (float)$withdrawalStats['approved_amount'];
$paidWithdrawals = (float)$withdrawalStats['paid_amount'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Withdrawals - DigitalMarket</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>
*{box-sizing:border-box}
body{margin:0;background:#f5f6fa;color:#24283b;font-family:Inter,sans-serif}
.sidebar{position:fixed;top:0;left:0;bottom:0;width:255px;background:#171b2e;padding:25px 16px;overflow-y:auto;z-index:1000}
.brand{color:#fff;font-size:22px;font-weight:800;padding:5px 12px 30px}
.brand span{color:#827bff}
.sidebar-label{color:#858ba5;font-size:11px;font-weight:700;text-transform:uppercase;margin:18px 12px 10px;letter-spacing:1px}
.sidebar-link{display:flex;align-items:center;gap:12px;color:#b9bed0;text-decoration:none;padding:12px 13px;border-radius:9px;margin-bottom:5px;font-size:13px;font-weight:500}
.sidebar-link i{font-size:17px}
.sidebar-link:hover,.sidebar-link.active{background:#635bff;color:white}
.main{margin-left:255px;padding:30px}
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:28px}
.topbar h2{font-size:24px;font-weight:800;margin:0}
.muted{color:#858ba0;font-size:13px}
.card-box{background:white;border-radius:15px;padding:22px;border:1px solid #eceef4;box-shadow:0 3px 15px rgba(25,30,60,.035);height:100%}
.balance-card{color:white;background:linear-gradient(135deg,#635bff,#817aff);border:0}
.balance-card.dark{background:linear-gradient(135deg,#202640,#3d4566)}
.balance-card.total{background:linear-gradient(135deg,#0e8066,#16a085)}
.balance-label{font-size:13px;opacity:.9}
.balance-value{font-size:27px;font-weight:800;margin:12px 0 5px}
.stat-number{font-size:21px;font-weight:800;margin-top:12px}
.section-title{font-size:16px;font-weight:800;margin-bottom:18px}
.form-label{font-size:13px;font-weight:600}
.form-control,.form-select{padding:12px;border-radius:9px;border-color:#e4e6ef;font-size:13px}
.btn-primary{background:#635bff;border-color:#635bff;border-radius:9px;padding:11px 18px;font-weight:600;font-size:13px}
.btn-primary:hover{background:#5149ed;border-color:#5149ed}
.btn-primary:disabled{opacity:.5;cursor:not-allowed}
.btn-outline-primary{color:#635bff;border-color:#635bff;border-radius:8px;font-size:12px}
.table{font-size:12px;vertical-align:middle}
.table th{color:#858ba0;font-weight:700;background:#fafbfe;padding:14px;white-space:nowrap}
.table td{padding:14px}
.account-box{border:1px solid #eceef4;border-radius:10px;padding:14px;margin-bottom:10px}
.account-number{font-weight:700;font-size:14px;margin-top:5px}
.empty{text-align:center;color:#858ba0;padding:30px 10px;font-size:13px}
.total-available-card{background:#fff;border:1px solid #dcefe9;border-radius:15px;padding:20px}
.total-available-card .amount{color:#087b62;font-size:25px;font-weight:800}
.info-note{background:#f1f4ff;border:1px solid #e0e5ff;padding:13px;border-radius:10px;color:#4e5482;font-size:12px;line-height:1.6}
.amount-feedback{font-size:12px;margin-top:7px;font-weight:600}
.amount-feedback.invalid{color:#dc3545}
.amount-feedback.valid{color:#198754}
@media(max-width:900px){
.sidebar{width:75px;padding:20px 8px}
.brand{font-size:0;text-align:center;padding:10px 0 25px}
.brand span{font-size:20px}
.sidebar-label{display:none}
.sidebar-link{justify-content:center;font-size:0;padding:13px 5px}
.sidebar-link i{font-size:20px}
.main{margin-left:75px;padding:20px 14px}
}
@media(max-width:576px){
.topbar h2{font-size:19px}
.main{padding:15px 10px}
.card-box{padding:16px}
.balance-value{font-size:22px}
}
</style>
</head>

<body>

<aside class="sidebar">
    <div class="brand">Digital<span>Market</span></div>

    <div class="sidebar-label">Main Menu</div>

    <a href="/digital_marketplace/user/dashboard.php" class="sidebar-link">
        <i class="bi bi-grid"></i> Dashboard
    </a>

    <a href="/digital_marketplace/user/withdrawal.php" class="sidebar-link active">
        <i class="bi bi-cash-stack"></i> Withdrawals
    </a>

    <a href="/digital_marketplace/user/transactions.php" class="sidebar-link">
        <i class="bi bi-receipt"></i> Transactions
    </a>

    <a href="/digital_marketplace/auth/logout.php" class="sidebar-link">
        <i class="bi bi-box-arrow-right"></i> Logout
    </a>
</aside>

<main class="main">

    <div class="topbar">
        <div>
            <h2>Withdrawals</h2>
            <div class="muted mt-1">
                Withdraw from your combined wallet balance.
            </div>
        </div>

        <div class="text-end">
            <div class="fw-bold"><?= e($user['full_name']) ?></div>
            <div class="muted">User Account</div>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle me-2"></i><?= e($success) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-circle me-2"></i><?= e($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- COMBINED BALANCES -->

    <div class="row g-3 mb-4">

        <div class="col-lg-4 col-md-6">
            <div class="card-box balance-card total">
                <div class="balance-label">
                    <i class="bi bi-wallet2 me-2"></i>
                    Total Available for Withdrawal
                </div>
                <div class="balance-value"><?= money($totalAvailable) ?></div>
                <small>Purchase + Commission Wallet</small>
            </div>
        </div>

        <div class="col-lg-4 col-md-6">
            <div class="card-box balance-card">
                <div class="balance-label">
                    <i class="bi bi-wallet me-2"></i>
                    Purchase Wallet Available
                </div>
                <div class="balance-value"><?= money($purchaseAvailable) ?></div>
                <small>Reserved: <?= money($wallets['purchase']['reserved_balance']) ?></small>
            </div>
        </div>

        <div class="col-lg-4 col-md-6">
            <div class="card-box balance-card dark">
                <div class="balance-label">
                    <i class="bi bi-graph-up-arrow me-2"></i>
                    Commission Wallet Available
                </div>
                <div class="balance-value"><?= money($commissionAvailable) ?></div>
                <small>Reserved: <?= money($wallets['commission']['reserved_balance']) ?></small>
            </div>
        </div>

    </div>

    <!-- WITHDRAWAL STATISTICS -->

    <div class="row g-3 mb-4">

        <div class="col-md-3">
            <div class="card-box">
                <div class="muted">Total Requested</div>
                <div class="stat-number"><?= money($totalWithdrawals) ?></div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card-box">
                <div class="muted">Pending Requests</div>
                <div class="stat-number text-warning"><?= money($pendingWithdrawals) ?></div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card-box">
                <div class="muted">Approved for Payment</div>
                <div class="stat-number text-primary"><?= money($approvedWithdrawals) ?></div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card-box">
                <div class="muted">Successfully Paid</div>
                <div class="stat-number text-success"><?= money($paidWithdrawals) ?></div>
            </div>
        </div>

    </div>

    <!-- WITHDRAWAL FORM AND ACCOUNT FORM -->

    <div class="row g-4 mb-4">

        <div class="col-lg-7">
            <div class="card-box">

                <h5 class="section-title">
                    <i class="bi bi-cash-stack me-2 text-primary"></i>
                    Request Withdrawal
                </h5>

                <?php if (empty($paymentMethods)): ?>
                    <div class="alert alert-warning">
                        No active withdrawal payment method is available.
                        Please contact the administrator.
                    </div>
                <?php elseif (empty($accounts)): ?>
                    <div class="alert alert-info">
                        Add a receiving account before submitting a withdrawal.
                    </div>
                <?php endif; ?>

                <div class="total-available-card mb-4">
                    <div class="muted mb-1">Your combined withdrawable balance</div>
                    <div class="amount"><?= money($totalAvailable) ?></div>
                    <small class="text-secondary">
                        <?= money($purchaseAvailable) ?> Purchase +
                        <?= money($commissionAvailable) ?> Commission
                    </small>
                </div>

                <form method="POST" action="<?= e($selfUrl) ?>" id="withdrawalForm" autocomplete="off">

                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                    <input type="hidden" name="action" value="submit_withdrawal">

                    <div class="mb-3">
                        <label class="form-label">Withdrawal Amount (ETB)</label>

                        <input type="number"
                               name="amount"
                               id="withdrawalAmount"
                               class="form-control"
                               min="300"
                               max="<?= e(number_format($totalAvailable, 2, '.', '')) ?>"
                               step="0.01"
                               placeholder="Minimum withdrawal: 300 ETB"
                               required>

                        <div class="amount-feedback" id="amountFeedback">
                            Minimum withdrawal is 300 ETB.
                        </div>

                        <div class="muted mt-1">
                            Maximum available: <?= money($totalAvailable) ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Receiving Account</label>

                        <select name="account_id" class="form-select" required>
                            <option value="">Select receiving account</option>
                            <?php foreach ($accounts as $account): ?>
                                <option value="<?= (int)$account['id'] ?>">
                                    <?= e($account['account_type']) ?> -
                                    <?= e($account['account_name']) ?> -
                                    <?= e($account['account_number']) ?>
                                    <?= $account['is_default'] ? ' (Default)' : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Withdrawal Payment Method</label>

                        <select name="payment_method_id" class="form-select" required>
                            <option value="">Select payment method</option>
                            <?php foreach ($paymentMethods as $method): ?>
                                <option value="<?= (int)$method['id'] ?>">
                                    <?= e($method['method_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit"
                            class="btn btn-primary w-100"
                            id="withdrawalSubmit"
                            disabled>
                        <i class="bi bi-send me-2"></i>
                        Submit Withdrawal Request
                    </button>

                </form>

                <div class="info-note mt-3">
                    <i class="bi bi-info-circle me-1"></i>
                    Minimum withdrawal is 300 ETB. Your Purchase Wallet is used
                    first. If necessary, the remaining amount is taken from
                    your Commission Wallet. Funds are reserved while your
                    request is reviewed.
                </div>

            </div>
        </div>

        <div class="col-lg-5">
            <div class="card-box">

                <h5 class="section-title">
                    <i class="bi bi-plus-circle me-2 text-primary"></i>
                    Add Receiving Account
                </h5>

                <form method="POST" action="<?= e($selfUrl) ?>">

                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                    <input type="hidden" name="action" value="add_account">

                    <div class="mb-3">
                        <label class="form-label">Account Type</label>
                        <select name="account_type" class="form-select" required>
                            <option value="">Select account type</option>
                            <option value="Telebirr">Telebirr</option>
                            <option value="CBE">Commercial Bank of Ethiopia (CBE)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Account Holder Name</label>
                        <input type="text" name="account_name"
                               class="form-control" maxlength="150" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Account Number / Phone Number</label>
                        <input type="text" name="account_number"
                               class="form-control" maxlength="50" required>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-plus-lg me-2"></i>
                        Save Payment Account
                    </button>

                </form>

            </div>
        </div>

    </div>

    <!-- RECEIVING ACCOUNTS -->

    <div class="card-box mb-4">

        <h5 class="section-title">
            <i class="bi bi-credit-card me-2 text-primary"></i>
            My Receiving Accounts
        </h5>

        <?php if (empty($accounts)): ?>

            <div class="empty">
                You have not added a receiving account yet.
            </div>

        <?php else: ?>

            <div class="row g-3">

                <?php foreach ($accounts as $account): ?>

                    <div class="col-md-6 col-xl-4">
                        <div class="account-box">

                            <div class="d-flex justify-content-between align-items-center">
                                <strong><?= e($account['account_type']) ?></strong>

                                <?php if ($account['is_default']): ?>
                                    <span class="badge bg-success">Default</span>
                                <?php endif; ?>
                            </div>

                            <div class="account-number">
                                <?= e($account['account_number']) ?>
                            </div>

                            <div class="muted mt-1">
                                <?= e($account['account_name']) ?>
                            </div>

                            <div class="d-flex gap-2 mt-3">

                                <?php if (!$account['is_default']): ?>

                                    <form method="POST" action="<?= e($selfUrl) ?>">
                                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                                        <input type="hidden" name="action" value="set_default">
                                        <input type="hidden" name="account_id" value="<?= (int)$account['id'] ?>">

                                        <button class="btn btn-outline-primary btn-sm" type="submit">
                                            Set Default
                                        </button>
                                    </form>

                                <?php endif; ?>

                                <form method="POST"
                                      action="<?= e($selfUrl) ?>"
                                      onsubmit="return confirm('Remove this receiving account?');">

                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                                    <input type="hidden" name="action" value="delete_account">
                                    <input type="hidden" name="account_id" value="<?= (int)$account['id'] ?>">

                                    <button class="btn btn-outline-danger btn-sm" type="submit">
                                        Remove
                                    </button>
                                </form>

                            </div>

                        </div>
                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </div>

    <!-- WITHDRAWAL HISTORY -->

    <div class="card-box">

        <h5 class="section-title">
            <i class="bi bi-clock-history me-2 text-primary"></i>
            Withdrawal History
        </h5>

        <?php if (empty($withdrawals)): ?>

            <div class="empty">
                You have not submitted any withdrawal requests.
            </div>

        <?php else: ?>

            <div class="table-responsive">
                <table class="table table-hover">

                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>Amount</th>
                            <th>Payment Method</th>
                            <th>Receiving Account</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ($withdrawals as $item): ?>

                            <tr>
                                <td>#<?= (int)$item['id'] ?></td>

                                <td class="fw-bold text-danger">
                                    − <?= money($item['amount']) ?>
                                </td>

                                <td><?= e($item['method_name'] ?? 'Unavailable') ?></td>

                                <td class="text-break" style="min-width:200px">
                                    <?= e($item['account_details']) ?>
                                </td>

                                <td><?= statusBadge($item['status']) ?></td>

                                <td>
                                    <?= e(date('d M Y, h:i A', strtotime($item['created_at']))) ?>
                                </td>
                            </tr>

                            <?php if (!empty($item['admin_note'])): ?>
                                <tr>
                                    <td colspan="6" class="bg-light">
                                        <strong>Administrator Note:</strong>
                                        <?= e($item['admin_note']) ?>
                                    </td>
                                </tr>
                            <?php endif; ?>

                            <?php if (!empty($item['payment_reference'])): ?>
                                <tr>
                                    <td colspan="6" class="bg-light">
                                        <strong>Payment Reference:</strong>
                                        <?= e($item['payment_reference']) ?>
                                    </td>
                                </tr>
                            <?php endif; ?>

                        <?php endforeach; ?>

                    </tbody>
                </table>
            </div>

        <?php endif; ?>

        <div class="muted mt-2">
            Showing your latest 50 withdrawal requests.
        </div>

    </div>

    <div class="text-center muted mt-4">
        © <?= date('Y') ?> DigitalMarket. All rights reserved.
    </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const amountInput = document.getElementById('withdrawalAmount');
    const feedback = document.getElementById('amountFeedback');
    const submitButton = document.getElementById('withdrawalSubmit');
    const form = document.getElementById('withdrawalForm');

    const minimum = 300;
    const maximum = <?= json_encode(round($totalAvailable, 2)) ?>;

    function validateWithdrawal() {

        const rawValue = amountInput.value.trim();
        const amount = Number(rawValue);

        let valid = true;
        let message = '';

        if (maximum < minimum) {
            valid = false;
            message = 'Your combined available balance is below 300 ETB.';
        } else if (rawValue === '' || !Number.isFinite(amount)) {
            valid = false;
            message = 'Enter your withdrawal amount.';
        } else if (amount < minimum) {
            valid = false;
            message = 'Minimum withdrawal is 300 ETB.';
        } else if (amount > maximum) {
            valid = false;
            message = 'Insufficient balance. Maximum available: ' +
                maximum.toFixed(2) + ' ETB.';
        } else {
            message = 'Withdrawal amount is valid.';
        }

        feedback.textContent = message;
        feedback.classList.toggle('valid', valid);
        feedback.classList.toggle('invalid', !valid);

        submitButton.disabled = !valid;

        amountInput.setCustomValidity(valid ? '' : message);

        return valid;
    }

    amountInput.addEventListener('input', validateWithdrawal);
    amountInput.addEventListener('change', validateWithdrawal);

    form.addEventListener('submit', function (event) {
        if (!validateWithdrawal()) {
            event.preventDefault();
            amountInput.reportValidity();
        }
    });

    validateWithdrawal();
});
</script>

</body>
</html>
