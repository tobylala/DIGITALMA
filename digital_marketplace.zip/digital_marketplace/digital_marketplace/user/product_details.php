
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection error. Check config/database.php.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

/* -------------------------------------------------
   SETTINGS
------------------------------------------------- */
const DAILY_COMMISSION_RATE = 5.00;
const DAILY_COMMISSION_DURATION = 365;

/* -------------------------------------------------
   HELPERS
------------------------------------------------- */
function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function redirectToProduct(int $id): void
{
    header('Location: product_details.php?id=' . $id);
    exit;
}

/* -------------------------------------------------
   AUTHENTICATION
------------------------------------------------- */
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];

$userStmt = $pdo->prepare("
    SELECT id, full_name, username, role, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$userStmt->execute([$userId]);
$currentUser = $userStmt->fetch();

if (
    !$currentUser ||
    $currentUser['role'] !== 'user' ||
    $currentUser['status'] !== 'active'
) {
    session_destroy();
    header('Location: ../auth/login.php');
    exit;
}

/* -------------------------------------------------
   PRODUCT ID
------------------------------------------------- */
$productId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$productId || $productId < 1) {
    header('Location: products.php');
    exit;
}

/* -------------------------------------------------
   CSRF TOKEN
------------------------------------------------- */
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* -------------------------------------------------
   FLASH MESSAGE
------------------------------------------------- */
$message = $_SESSION['purchase_message'] ?? '';
$messageType = $_SESSION['purchase_message_type'] ?? 'success';

unset(
    $_SESSION['purchase_message'],
    $_SESSION['purchase_message_type']
);

/* -------------------------------------------------
   PURCHASE PROCESS
------------------------------------------------- */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['action'] ?? '') === 'buy_now'
) {
    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !hash_equals($_SESSION['csrf_token'], $submittedToken)
    ) {
        $message = 'Invalid request. Please refresh the page and try again.';
        $messageType = 'danger';
    } else {
        try {
            $pdo->beginTransaction();

            /*
             * Lock product.
             */
            $productLock = $pdo->prepare("
                SELECT
                    id,
                    product_name,
                    price,
                    commission_rate,
                    status
                FROM products
                WHERE id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $productLock->execute([$productId]);
            $product = $productLock->fetch();

            if (!$product || $product['status'] !== 'active') {
                throw new Exception('This product is no longer available.');
            }

            $price = (float)$product['price'];
            $referralRate = (float)$product['commission_rate'];

            if ($price <= 0) {
                throw new Exception('This product has an invalid price.');
            }

            if ($referralRate < 0 || $referralRate > 100) {
                throw new Exception('This product has an invalid referral commission rate.');
            }

            /*
             * CHECK WHETHER USER ALREADY OWNS PRODUCT.
             */
            $accessCheck = $pdo->prepare("
                SELECT id
                FROM product_access
                WHERE user_id = ?
                  AND product_id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $accessCheck->execute([$userId, $productId]);

            if ($accessCheck->fetch()) {
                throw new Exception('You have already purchased this product.');
            }

            /*
             * IDENTIFY THE BUYER'S REFERRER.
             *
             * users.referred_by stores the referrer's user ID.
             * The referrer must be another active user.
             */
            $buyerStmt = $pdo->prepare("
                SELECT referred_by
                FROM users
                WHERE id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $buyerStmt->execute([$userId]);
            $buyer = $buyerStmt->fetch();

            if (!$buyer) {
                throw new Exception('Your account could not be verified.');
            }

            $affiliateId = null;
            $affiliateReferralCode = null;

            $referredBy = (int)($buyer['referred_by'] ?? 0);

            if ($referredBy > 0 && $referredBy !== $userId) {
                $affiliateStmt = $pdo->prepare("
                    SELECT id, referral_code
                    FROM users
                    WHERE id = ?
                      AND role = 'user'
                      AND status = 'active'
                    LIMIT 1
                ");

                $affiliateStmt->execute([$referredBy]);
                $affiliate = $affiliateStmt->fetch();

                if ($affiliate) {
                    $affiliateId = (int)$affiliate['id'];
                    $affiliateReferralCode = $affiliate['referral_code'];
                }
            }

            /*
             * LOCK PURCHASE WALLET.
             */
            $walletStmt = $pdo->prepare("
                SELECT id, balance, reserved_balance
                FROM wallet_accounts
                WHERE user_id = ?
                  AND wallet_type = 'purchase'
                LIMIT 1
                FOR UPDATE
            ");
            $walletStmt->execute([$userId]);
            $wallet = $walletStmt->fetch();

            if (!$wallet) {
                throw new Exception(
                    'Your purchase wallet was not found. Please contact the administrator.'
                );
            }

            $walletId = (int)$wallet['id'];
            $balance = (float)$wallet['balance'];
            $reservedBalance = (float)$wallet['reserved_balance'];

            $availableBalance = $balance - $reservedBalance;

            if ($availableBalance < $price) {
                throw new Exception(
                    'Insufficient purchase wallet balance. Your available balance is ' .
                    number_format(max(0, $availableBalance), 2) .
                    ' ETB, but this product costs ' .
                    number_format($price, 2) . ' ETB.'
                );
            }

            /*
             * GENERATE ORDER NUMBER.
             */
            $orderNumber = 'DM-' .
                date('YmdHis') . '-' .
                strtoupper(bin2hex(random_bytes(3)));

            /*
             * CREATE COMPLETED ORDER.
             *
             * affiliate_id and referral_code are now saved
             * when the buyer has a valid referrer.
             */
            $orderStmt = $pdo->prepare("
                INSERT INTO orders (
                    order_number,
                    user_id,
                    product_id,
                    quantity,
                    unit_price,
                    affiliate_id,
                    referral_code,
                    total_amount,
                    payment_method,
                    payment_status,
                    status,
                    completed_at
                ) VALUES (
                    ?, ?, ?, 1, ?, ?, ?, ?,
                    'wallet', 'paid', 'completed', NOW()
                )
            ");

            $orderStmt->execute([
                $orderNumber,
                $userId,
                $productId,
                $price,
                $affiliateId,
                $affiliateReferralCode,
                $price
            ]);

            $orderId = (int)$pdo->lastInsertId();

            /*
             * CREATE ORDER ITEM.
             */
            $itemStmt = $pdo->prepare("
                INSERT INTO order_items (
                    order_id,
                    product_id,
                    quantity,
                    unit_price,
                    commission_rate
                ) VALUES (?, ?, 1, ?, ?)
            ");

            $itemStmt->execute([
                $orderId,
                $productId,
                $price,
                $referralRate
            ]);

            $orderItemId = (int)$pdo->lastInsertId();

            /*
             * CREATE REFERRAL COMMISSION.
             *
             * Referral commission:
             * Product price x product commission_rate / 100.
             *
             * Status:
             * pending - administrator can review and approve it.
             *
             * The unique index on:
             * (affiliate_id, order_item_id)
             * prevents duplicate commissions for the same item.
             *
             * This is separate from daily commission.
             */
            $referralCommissionAmount = round(
                $price * $referralRate / 100,
                2
            );

            $referralCommissionCreated = false;

            if (
                $affiliateId !== null &&
                $affiliateId !== $userId &&
                $referralCommissionAmount > 0
            ) {
                $commissionStmt = $pdo->prepare("
                    INSERT INTO commissions (
                        affiliate_id,
                        order_id,
                        order_item_id,
                        amount,
                        status
                    ) VALUES (?, ?, ?, ?, 'pending')
                ");

                $commissionStmt->execute([
                    $affiliateId,
                    $orderId,
                    $orderItemId,
                    $referralCommissionAmount
                ]);

                $referralCommissionCreated = true;
            }

            /*
             * CREATE DAILY COMMISSION SCHEDULE.
             *
             * Daily commission:
             * 5% of original purchase price.
             *
             * Duration:
             * 365 days.
             *
             * Starts:
             * The day after purchase.
             *
             * This is independent of referral commission.
             */
            $scheduleStmt = $pdo->prepare("
                INSERT INTO daily_commission_schedules (
                    user_id,
                    order_id,
                    order_item_id,
                    product_id,
                    purchase_price,
                    daily_rate,
                    duration_days,
                    start_date,
                    end_date,
                    status
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?,
                    DATE_ADD(CURDATE(), INTERVAL 1 DAY),
                    DATE_ADD(CURDATE(), INTERVAL 365 DAY),
                    'active'
                )
            ");

            $scheduleStmt->execute([
                $userId,
                $orderId,
                $orderItemId,
                $productId,
                $price,
                DAILY_COMMISSION_RATE,
                DAILY_COMMISSION_DURATION
            ]);

            /*
             * DEDUCT PURCHASE WALLET BALANCE.
             */
            $newBalance = $balance - $price;

            $updateWallet = $pdo->prepare("
                UPDATE wallet_accounts
                SET balance = balance - ?
                WHERE id = ?
                  AND balance - reserved_balance >= ?
            ");

            $updateWallet->execute([
                $price,
                $walletId,
                $price
            ]);

            if ($updateWallet->rowCount() !== 1) {
                throw new Exception(
                    'Wallet balance could not be updated. Please try again.'
                );
            }

            /*
             * RECORD WALLET DEBIT.
             */
            $transactionStmt = $pdo->prepare("
                INSERT INTO wallet_transactions (
                    wallet_id,
                    transaction_type,
                    amount,
                    balance_after,
                    reference_type,
                    reference_id,
                    idempotency_key,
                    description
                ) VALUES (
                    ?, 'debit', ?, ?, 'order', ?, ?, ?
                )
            ");

            $idempotencyKey = 'purchase_order_' . $orderId;

            $transactionStmt->execute([
                $walletId,
                $price,
                $newBalance,
                $orderId,
                $idempotencyKey,
                'Purchase of ' . $product['product_name']
            ]);

            /*
             * GRANT DIGITAL PRODUCT ACCESS.
             */
            $accessStmt = $pdo->prepare("
                INSERT INTO product_access (
                    user_id,
                    product_id,
                    order_id
                ) VALUES (?, ?, ?)
            ");

            $accessStmt->execute([
                $userId,
                $productId,
                $orderId
            ]);

            /*
             * COMMIT ALL OPERATIONS TOGETHER.
             *
             * If any operation fails, the order, wallet
             * deduction, referral commission, product access,
             * and daily schedule are all rolled back.
             */
            $pdo->commit();

            $successMessage =
                'Purchase successful! You now own "' .
                $product['product_name'] .
                '". Your daily commission schedule has been activated at 5% per day for 365 days.';

            if ($referralCommissionCreated) {
                $successMessage .=
                    ' A referral commission of ' .
                    number_format($referralCommissionAmount, 2) .
                    ' ETB has been recorded for your referrer and is pending administrator approval.';
            }

            $successMessage .= ' Order number: ' . $orderNumber;

            $_SESSION['purchase_message'] = $successMessage;
            $_SESSION['purchase_message_type'] = 'success';

            redirectToProduct($productId);

        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('DigitalMarket purchase error: ' . $ex->getMessage());

            $message = $ex instanceof PDOException
                ? 'The purchase could not be completed because of a database error. Please contact the administrator.'
                : $ex->getMessage();

            $messageType = 'danger';
        }
    }
}

/* -------------------------------------------------
   GET PRODUCT DETAILS
------------------------------------------------- */
$productStmt = $pdo->prepare("
    SELECT
        id,
        product_name,
        description,
        price,
        commission_rate,
        image_path,
        created_at,
        status
    FROM products
    WHERE id = ?
      AND status = 'active'
    LIMIT 1
");

$productStmt->execute([$productId]);
$product = $productStmt->fetch();

if (!$product) {
    header('Location: products.php');
    exit;
}

/* -------------------------------------------------
   CHECK OWNERSHIP
------------------------------------------------- */
$ownedStmt = $pdo->prepare("
    SELECT id, order_id, granted_at
    FROM product_access
    WHERE user_id = ?
      AND product_id = ?
    LIMIT 1
");

$ownedStmt->execute([$userId, $productId]);
$ownership = $ownedStmt->fetch();

$isOwned = (bool)$ownership;

/* -------------------------------------------------
   GET COMMISSION SCHEDULE FOR OWNED PRODUCT
------------------------------------------------- */
$commissionSchedule = null;

if ($isOwned) {
    $scheduleStmt = $pdo->prepare("
        SELECT
            id,
            purchase_price,
            daily_rate,
            duration_days,
            start_date,
            end_date,
            status
        FROM daily_commission_schedules
        WHERE user_id = ?
          AND order_id = ?
        LIMIT 1
    ");

    $scheduleStmt->execute([
        $userId,
        (int)$ownership['order_id']
    ]);

    $commissionSchedule = $scheduleStmt->fetch();
}

/* -------------------------------------------------
   GET PURCHASE WALLET BALANCE
------------------------------------------------- */
$walletBalance = 0;
$walletAvailable = 0;

$walletBalanceStmt = $pdo->prepare("
    SELECT balance, reserved_balance
    FROM wallet_accounts
    WHERE user_id = ?
      AND wallet_type = 'purchase'
    LIMIT 1
");

$walletBalanceStmt->execute([$userId]);
$walletInfo = $walletBalanceStmt->fetch();

if ($walletInfo) {
    $walletBalance = (float)$walletInfo['balance'];
    $walletAvailable = $walletBalance -
        (float)$walletInfo['reserved_balance'];
}

/* -------------------------------------------------
   PRODUCT IMAGE
------------------------------------------------- */
$imagePath = '';

if (!empty($product['image_path'])) {
    $cleanImage = str_replace('\\', '/', $product['image_path']);
    $cleanImage = ltrim($cleanImage, '/');

    if (
        strpos($cleanImage, '..') === false &&
        preg_match('/^[a-zA-Z0-9_\/.-]+$/', $cleanImage)
    ) {
        $imagePath = '../' . $cleanImage;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= e($product['product_name']) ?> | DigitalMarket</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        rel="stylesheet">

    <style>
        :root {
            --navy: #102747;
            --dark-navy: #0a1b32;
            --gold: #d8aa45;
            --light-bg: #f4f6fa;
        }

        body {
            background: var(--light-bg);
            font-family: Arial, sans-serif;
            color: #26354a;
        }

        .navbar {
            background: var(--dark-navy);
            padding: 15px 0;
        }

        .navbar-brand {
            color: white;
            font-size: 22px;
            font-weight: 700;
        }

        .navbar-brand span {
            color: var(--gold);
        }

        .navbar a {
            color: white;
            text-decoration: none;
        }

        .page-wrapper {
            max-width: 1100px;
            margin: 40px auto;
            padding: 0 15px;
        }

        .product-card {
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 5px 25px rgba(0,0,0,.06);
        }

        .product-image {
            width: 100%;
            height: 430px;
            object-fit: contain;
            background: #f8f9fc;
            padding: 20px;
        }

        .image-placeholder {
            height: 430px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #eef1f6;
            color: #9aa5b5;
            font-size: 90px;
        }

        .product-content {
            padding: 35px;
        }

        .product-title {
            color: var(--navy);
            font-size: 30px;
            font-weight: 700;
        }

        .price {
            color: var(--navy);
            font-size: 30px;
            font-weight: 800;
        }

        .gold-text {
            color: #b88720;
        }

        .wallet-box {
            background: #f4f6fa;
            border: 1px solid #e2e7ef;
            border-radius: 12px;
            padding: 18px;
        }

        .commission-box {
            background: #f0faf4;
            border: 1px solid #ccebd7;
            border-radius: 12px;
            padding: 18px;
        }

        .btn-buy {
            background: var(--gold);
            border: none;
            color: var(--dark-navy);
            font-weight: 700;
            padding: 14px 25px;
            border-radius: 9px;
        }

        .btn-buy:hover {
            background: #c69732;
            color: var(--dark-navy);
        }

        .btn-navy {
            background: var(--navy);
            color: white;
            border-radius: 9px;
            padding: 12px 20px;
        }

        .btn-navy:hover {
            background: var(--dark-navy);
            color: white;
        }

        .feature-item {
            padding: 12px 0;
            border-bottom: 1px solid #edf0f4;
        }

        @media(max-width: 768px) {
            .product-image,
            .image-placeholder {
                height: 280px;
            }

            .product-content {
                padding: 22px;
            }

            .product-title {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

<nav class="navbar">
    <div class="container d-flex justify-content-between align-items-center">

        <a href="products.php" class="navbar-brand">
            Digital<span>Market</span>
        </a>

        <div class="d-flex gap-3 align-items-center">

            <a href="products.php">
                <i class="bi bi-grid"></i> Products
            </a>

            <a href="wallet.php">
                <i class="bi bi-wallet2"></i> Wallet
            </a>

            <a href="orders.php">
                <i class="bi bi-bag"></i> Orders
            </a>

        </div>
    </div>
</nav>

<div class="page-wrapper">

    <div class="mb-4">
        <a href="products.php" class="text-decoration-none text-secondary">
            <i class="bi bi-arrow-left"></i> Back to Products
        </a>
    </div>

    <?php if ($message): ?>

        <div class="alert alert-<?= e($messageType) ?> alert-dismissible fade show">

            <?= e($message) ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert">
            </button>

        </div>

    <?php endif; ?>

    <div class="product-card">

        <div class="row g-0">

            <div class="col-lg-6">

                <?php if ($imagePath): ?>

                    <img
                        src="<?= e($imagePath) ?>"
                        class="product-image"
                        alt="<?= e($product['product_name']) ?>">

                <?php else: ?>

                    <div class="image-placeholder">
                        <i class="bi bi-file-earmark-richtext"></i>
                    </div>

                <?php endif; ?>

            </div>

            <div class="col-lg-6">

                <div class="product-content">

                    <span class="badge text-bg-success mb-3">
                        <i class="bi bi-check-circle"></i>
                        Available
                    </span>

                    <h1 class="product-title">
                        <?= e($product['product_name']) ?>
                    </h1>

                    <div class="price mt-3 mb-4">
                        <?= number_format((float)$product['price'], 2) ?>
                        <small class="fs-6">ETB</small>
                    </div>

                    <h6 class="fw-bold">Product Description</h6>

                    <p class="text-secondary">
                        <?= nl2br(e($product['description'] ?: 'No description available.')) ?>
                    </p>

                    <hr>

                    <div class="feature-item">

                        <div class="d-flex justify-content-between">

                            <span class="text-secondary">Product ID</span>

                            <strong>#<?= (int)$product['id'] ?></strong>

                        </div>

                    </div>

                    <div class="feature-item">

                        <div class="d-flex justify-content-between">

                            <span class="text-secondary">Referral Commission Rate</span>

                            <strong class="gold-text">
                                <?= number_format((float)$product['commission_rate'], 2) ?>%
                            </strong>

                        </div>

                    </div>

                    <div class="feature-item">

                        <div class="d-flex justify-content-between">

                            <span class="text-secondary">Daily Commission</span>

                            <strong class="text-success">5% per day</strong>

                        </div>

                    </div>

                    <div class="feature-item">

                        <div class="d-flex justify-content-between">

                            <span class="text-secondary">Commission Duration</span>

                            <strong>365 days</strong>

                        </div>

                    </div>

                    <div class="wallet-box mt-4 mb-4">

                        <div class="d-flex justify-content-between">

                            <span class="text-secondary">
                                <i class="bi bi-wallet2"></i>
                                Available Wallet Balance
                            </span>

                            <strong>
                                <?= number_format(max(0, $walletAvailable), 2) ?> ETB
                            </strong>

                        </div>

                        <div class="d-flex justify-content-between mt-2">

                            <span class="text-secondary">Product Price</span>

                            <strong>
                                <?= number_format((float)$product['price'], 2) ?> ETB
                            </strong>

                        </div>

                    </div>

                    <?php if ($isOwned): ?>

                        <div class="alert alert-success">

                            <i class="bi bi-check-circle-fill"></i>

                            <strong>You already own this product.</strong>

                            <div class="small mt-1">
                                Your purchase has been recorded successfully.
                            </div>

                        </div>

                        <?php if ($commissionSchedule): ?>

                            <div class="commission-box mb-4">

                                <h6 class="fw-bold text-success">

                                    <i class="bi bi-calendar-check"></i>
                                    Daily Commission Schedule

                                </h6>

                                <div class="d-flex justify-content-between mt-3">

                                    <span>Daily rate</span>

                                    <strong>
                                        <?= number_format((float)$commissionSchedule['daily_rate'], 2) ?>%
                                    </strong>

                                </div>

                                <div class="d-flex justify-content-between mt-2">

                                    <span>Daily earning</span>

                                    <strong>
                                        <?= number_format(
                                            (float)$commissionSchedule['purchase_price'] *
                                            (float)$commissionSchedule['daily_rate'] / 100,
                                            2
                                        ) ?> ETB
                                    </strong>

                                </div>

                                <div class="d-flex justify-content-between mt-2">

                                    <span>Duration</span>

                                    <strong>
                                        <?= (int)$commissionSchedule['duration_days'] ?> days
                                    </strong>

                                </div>

                                <div class="d-flex justify-content-between mt-2">

                                    <span>Start date</span>

                                    <strong>
                                        <?= e($commissionSchedule['start_date']) ?>
                                    </strong>

                                </div>

                                <div class="d-flex justify-content-between mt-2">

                                    <span>End date</span>

                                    <strong>
                                        <?= e($commissionSchedule['end_date']) ?>
                                    </strong>

                                </div>

                                <div class="d-flex justify-content-between mt-2">

                                    <span>Status</span>

                                    <strong>
                                        <?= e(ucfirst($commissionSchedule['status'])) ?>
                                    </strong>

                                </div>

                            </div>

                        <?php else: ?>

                            <div class="alert alert-warning">

                                <i class="bi bi-exclamation-triangle"></i>

                                No daily commission schedule exists for this purchase yet.
                                Please contact the administrator to activate the existing purchase.

                            </div>

                        <?php endif; ?>

                        <a href="orders.php" class="btn btn-navy">

                            <i class="bi bi-bag-check"></i>
                            View My Orders

                        </a>

                    <?php elseif ($walletAvailable < (float)$product['price']): ?>

                        <div class="alert alert-warning">

                            <strong>Insufficient wallet balance.</strong>

                            Please recharge your purchase wallet before buying this product.

                        </div>

                        <a href="deposits.php" class="btn btn-buy">

                            <i class="bi bi-plus-circle"></i>
                            Recharge Wallet

                        </a>

                    <?php else: ?>

                        <form
                            method="POST"
                            action="product_details.php?id=<?= (int)$product['id'] ?>"
                            onsubmit="return confirmPurchase();">

                            <input
                                type="hidden"
                                name="action"
                                value="buy_now">

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= e($_SESSION['csrf_token']) ?>">

                            <button type="submit" class="btn btn-buy w-100">

                                <i class="bi bi-bag-check"></i>

                                Buy Now -
                                <?= number_format((float)$product['price'], 2) ?> ETB

                            </button>

                        </form>

                    <?php endif; ?>

                    <a href="products.php" class="btn btn-outline-secondary w-100 mt-3">
                        Continue Browsing
                    </a>

                    <p class="text-muted small mt-3 mb-0">

                        <i class="bi bi-shield-lock"></i>

                        Your purchase is processed securely using your purchase wallet.

                    </p>

                </div>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
function confirmPurchase() {
    return confirm(
        'Are you sure you want to purchase this product? The product price will be deducted from your purchase wallet, and a 365-day daily commission schedule will be created. If you were referred by another user, the referral commission will also be recorded.'
    );
}
</script>

</body>
</html>
