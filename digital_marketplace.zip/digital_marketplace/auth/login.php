
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

$error = '';
$loginValue = '';

if (isset($_SESSION['user_id'])) {
    if (($_SESSION['user_role'] ?? '') === 'admin') {
        header('Location: ../admin/dashboard.php');
    } else {
        header('Location: ../user/dashboard.php');
    }
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $loginValue = trim($_POST['login'] ?? '');
    $passwordInput = $_POST['password'] ?? '';
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_token'], $csrfToken)) {
        $error = 'Invalid request. Please refresh the page and try again.';

    } elseif ($loginValue === '' || $passwordInput === '') {
        $error = 'Please enter your username/email and password.';

    } else {
        try {
            $sql = "
                SELECT id, full_name, username, email, password, role, status
                FROM users
                WHERE username = :username OR email = :email
                LIMIT 1
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'username' => $loginValue,
                'email' => $loginValue
            ]);

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user || !password_verify($passwordInput, $user['password'])) {
                $error = 'Incorrect username/email or password.';

            } elseif ($user['status'] !== 'active') {
                $error = 'Your account is not active. Please contact the administrator.';

            } else {
                session_regenerate_id(true);

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                if ($user['role'] === 'admin') {
                    header('Location: ../admin/dashboard.php');
                } else {
                    header('Location: ../user/dashboard.php');
                }
                exit;
            }

        } catch (PDOException $e) {
            error_log('Login error: ' . $e->getMessage());
            $error = 'Unable to process your login right now. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Sign In | DigitalMarket</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #635bff;
            --primary-hover: #5148e5;
            --dark: #202438;
            --muted: #8991a3;
            --border: #e8eaf0;
        }

        * {
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 25px 15px;
            background: #f5f6fa;
            font-family: 'DM Sans', sans-serif;
            color: var(--dark);
        }

        .login-card {
            width: 100%;
            max-width: 440px;
            padding: 43px 40px 35px;
            background: #fff;
            border: 1px solid #eaecf2;
            border-radius: 16px;
            box-shadow: 0 12px 45px rgba(25, 31, 55, .07);
        }

        .brand {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-bottom: 35px;
            color: var(--dark);
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -.7px;
        }

        .brand-icon {
            width: 39px;
            height: 39px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            color: #fff;
            background: var(--primary);
            font-size: 19px;
        }

        .brand span {
            color: var(--primary);
        }

        .heading {
            text-align: center;
            margin-bottom: 30px;
        }

        .heading h2 {
            margin-bottom: 9px;
            color: var(--dark);
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -.8px;
        }

        .heading p {
            margin: 0;
            color: var(--muted);
            font-size: 13px;
        }

        .form-label {
            margin-bottom: 9px;
            color: #41465a;
            font-size: 12px;
            font-weight: 700;
        }

        .input-wrap {
            position: relative;
        }

        .input-wrap > i {
            position: absolute;
            top: 50%;
            left: 15px;
            transform: translateY(-50%);
            color: #969daf;
            font-size: 17px;
            z-index: 2;
        }

        .form-control {
            height: 52px;
            padding: 12px 44px;
            border: 1px solid var(--border);
            border-radius: 9px;
            background: #fff;
            color: var(--dark);
            font-size: 13px;
            box-shadow: none;
        }

        .form-control::placeholder {
            color: #a8adbb;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99, 91, 255, .09);
        }

        .password-toggle {
            position: absolute;
            top: 50%;
            right: 13px;
            transform: translateY(-50%);
            padding: 5px;
            border: 0;
            background: transparent;
            color: #969daf;
            font-size: 17px;
            cursor: pointer;
        }

        .password-toggle:hover {
            color: var(--primary);
        }

        .login-btn {
            width: 100%;
            height: 52px;
            margin-top: 8px;
            border: none;
            border-radius: 9px;
            background: var(--primary);
            color: #fff;
            font-size: 13px;
            font-weight: 700;
            transition: .2s ease;
        }

        .login-btn:hover {
            background: var(--primary-hover);
            color: #fff;
        }

        .login-alert {
            padding: 12px 14px;
            border-radius: 9px;
            font-size: 12px;
        }

        .register-text {
            margin: 25px 0 0;
            text-align: center;
            color: var(--muted);
            font-size: 12px;
        }

        .register-text a {
            color: var(--primary);
            font-weight: 700;
            text-decoration: none;
        }

        .register-text a:hover {
            text-decoration: underline;
        }

        .back-home {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: #9299a9;
            font-size: 12px;
            text-decoration: none;
        }

        .back-home:hover {
            color: var(--primary);
        }

        .security-note {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 7px;
            margin-top: 28px;
            padding-top: 19px;
            border-top: 1px solid #f0f1f5;
            color: #9aa1af;
            font-size: 10px;
        }

        .security-note i {
            color: #20a477;
        }

        @media (max-width: 480px) {
            .login-card {
                padding: 35px 24px 28px;
                border-radius: 13px;
            }

            .heading h2 {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

<div class="login-card">

    <a href="../home.php" class="brand text-decoration-none">
        <span class="brand-icon">
            <i class="bi bi-layers-fill"></i>
        </span>
        <span style="color:#202438">Digital<span>Market</span></span>
    </a>

    <div class="heading">
        <h2>Sign in</h2>
        <p>Enter your account credentials to continue.</p>
    </div>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger login-alert mb-4" role="alert">
            <i class="bi bi-exclamation-circle-fill me-2"></i>
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="login.php">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>"
        >

        <div class="mb-4">
            <label for="login" class="form-label">Username or Email</label>

            <div class="input-wrap">
                <i class="bi bi-person"></i>

                <input
                    type="text"
                    id="login"
                    name="login"
                    class="form-control"
                    placeholder="Enter your username or email"
                    value="<?= htmlspecialchars($loginValue, ENT_QUOTES, 'UTF-8') ?>"
                    autocomplete="username"
                    required
                    autofocus
                >
            </div>
        </div>

        <div class="mb-4">
            <label for="password" class="form-label">Password</label>

            <div class="input-wrap">
                <i class="bi bi-lock"></i>

                <input
                    type="password"
                    id="password"
                    name="password"
                    class="form-control"
                    placeholder="Enter your password"
                    autocomplete="current-password"
                    required
                >

                <button
                    type="button"
                    class="password-toggle"
                    id="togglePassword"
                    aria-label="Show password"
                >
                    <i class="bi bi-eye"></i>
                </button>
            </div>
        </div>

        <button type="submit" class="btn login-btn">
            Sign In <i class="bi bi-arrow-right ms-2"></i>
        </button>

    </form>

    <p class="register-text">
        Don't have an account?
        <a href="register.php">Create an account</a>
    </p>

    <a href="../home.php" class="back-home">
        <i class="bi bi-arrow-left me-1"></i> Back to Home

         <p class="register-text">
        forgot Your an password?
        <a href="register.php">Create an account</a>
    </p>


    </a>

    <div class="security-note">
        <i class="bi bi-shield-lock-fill"></i>
        Secure account access
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const toggle = document.getElementById('togglePassword');
    const password = document.getElementById('password');

    toggle.addEventListener('click', function () {

        const icon = this.querySelector('i');

        if (password.type === 'password') {
            password.type = 'text';
            icon.classList.replace('bi-eye', 'bi-eye-slash');
            this.setAttribute('aria-label', 'Hide password');
        } else {
            password.type = 'password';
            icon.classList.replace('bi-eye-slash', 'bi-eye');
            this.setAttribute('aria-label', 'Show password');
        }

    });

});
</script>

</body>
</html>
