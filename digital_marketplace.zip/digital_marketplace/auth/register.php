
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

$error = '';
$success = '';

$fullName = '';
$username = '';
$email = '';
$phone = '';
$referralCode = trim($_GET['ref'] ?? '');

if (isset($_SESSION['user_id'])) {
    if (($_SESSION['user_role'] ?? '') === 'admin') {
        header('Location: ../admin/dashboard.php');
    } else {
        header('Location: ../user/dashboard.php');
    }
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function generateReferralCode(PDO $pdo): string
{
    do {
        $code = 'DM' . strtoupper(bin2hex(random_bytes(4)));

        $stmt = $pdo->prepare(
            "SELECT id FROM users WHERE referral_code = ? LIMIT 1"
        );
        $stmt->execute([$code]);

    } while ($stmt->fetch());

    return $code;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $referralCode = strtoupper(trim($_POST['referral_code'] ?? ''));

    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_token'], $csrfToken)) {
        $error = 'Invalid request. Please refresh the page and try again.';

    } elseif (
        $fullName === '' ||
        $username === '' ||
        $email === '' ||
        $password === '' ||
        $confirmPassword === ''
    ) {
        $error = 'Please complete all required fields.';

    } elseif (strlen($fullName) > 150) {
        $error = 'Full name is too long.';

    } elseif (!preg_match('/^[a-zA-Z0-9_]{4,60}$/', $username)) {
        $error = 'Username must be 4–60 characters and contain only letters, numbers and underscores.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        $error = 'Please enter a valid email address.';

    } elseif ($phone !== '' && strlen($phone) > 30) {
        $error = 'Phone number is too long.';

    } elseif (strlen($password) < 8) {
        $error = 'Password must contain at least 8 characters.';

    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match.';

    } else {
        try {
            $check = $pdo->prepare(
                "SELECT id FROM users
                 WHERE username = :username OR email = :email
                 LIMIT 1"
            );

            $check->execute([
                'username' => $username,
                'email' => $email
            ]);

            if ($check->fetch()) {
                $error = 'Username or email address is already registered.';

            } else {

                $referrerId = null;

                if ($referralCode !== '') {
                    $referrerStmt = $pdo->prepare(
                        "SELECT id FROM users
                         WHERE referral_code = ?
                         AND status = 'active'
                         LIMIT 1"
                    );

                    $referrerStmt->execute([$referralCode]);
                    $referrer = $referrerStmt->fetch();

                    if (!$referrer) {
                        $error = 'The referral code is invalid or inactive.';
                    } else {
                        $referrerId = $referrer['id'];
                    }
                }

                if ($error === '') {

                    $pdo->beginTransaction();

                    $newReferralCode = generateReferralCode($pdo);

                    $hashedPassword = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    $insertUser = $pdo->prepare(
                        "INSERT INTO users
                        (
                            full_name,
                            username,
                            email,
                            phone,
                            password,
                            role,
                            status,
                            referral_code,
                            referred_by
                        )
                        VALUES
                        (
                            :full_name,
                            :username,
                            :email,
                            :phone,
                            :password,
                            'user',
                            'active',
                            :referral_code,
                            :referred_by
                        )"
                    );

                    $insertUser->execute([
                        'full_name' => $fullName,
                        'username' => $username,
                        'email' => $email,
                        'phone' => $phone !== '' ? $phone : null,
                        'password' => $hashedPassword,
                        'referral_code' => $newReferralCode,
                        'referred_by' => $referrerId
                    ]);

                    $newUserId = (int) $pdo->lastInsertId();

                    $purchaseWallet = $pdo->prepare(
                        "INSERT INTO wallet_accounts
                        (user_id, wallet_type, balance, reserved_balance)
                        VALUES (?, 'purchase', 0.00, 0.00)"
                    );

                    $purchaseWallet->execute([$newUserId]);

                    $commissionWallet = $pdo->prepare(
                        "INSERT INTO wallet_accounts
                        (user_id, wallet_type, balance, reserved_balance)
                        VALUES (?, 'commission', 0.00, 0.00)"
                    );

                    $commissionWallet->execute([$newUserId]);

                    $pdo->commit();

                    $success = 'Your account has been created successfully! You can now sign in.';

                    $fullName = '';
                    $username = '';
                    $email = '';
                    $phone = '';
                    $referralCode = '';

                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                }
            }

        } catch (PDOException $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('Registration error: ' . $e->getMessage());

            if ($e->getCode() === '23000') {
                $error = 'This username, email or referral code is already in use. Please try again.';
            } else {
                $error = 'Registration failed. Please try again later.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Create Account | DigitalMarket</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #635bff;
            --primary-hover: #5148e5;
            --dark: #202438;
            --muted: #8991a3;
            --border: #e8eaf0;
        }

        * {
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 35px 15px;
            background: #f5f6fa;
            color: var(--dark);
            font-family: 'DM Sans', sans-serif;
        }

        .register-card {
            width: 100%;
            max-width: 620px;
            padding: 40px 45px 32px;
            background: #fff;
            border: 1px solid #eaecf2;
            border-radius: 16px;
            box-shadow: 0 12px 45px rgba(25, 31, 55, .07);
        }

        .brand {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-bottom: 30px;
            color: var(--dark);
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -.7px;
            text-decoration: none;
        }

        .brand-icon {
            width: 39px;
            height: 39px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            color: #fff;
            background: var(--primary);
            font-size: 19px;
        }

        .brand-name span {
            color: var(--primary);
        }

        .heading {
            text-align: center;
            margin-bottom: 28px;
        }

        .heading h2 {
            margin-bottom: 8px;
            color: var(--dark);
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -.8px;
        }

        .heading p {
            margin: 0;
            color: var(--muted);
            font-size: 13px;
        }

        .form-label {
            margin-bottom: 8px;
            color: #41465a;
            font-size: 12px;
            font-weight: 700;
        }

        .form-control {
            height: 48px;
            padding: 11px 13px;
            border: 1px solid var(--border);
            border-radius: 9px;
            background: #fff;
            color: var(--dark);
            font-size: 13px;
            box-shadow: none;
        }

        .form-control::placeholder {
            color: #a8adbb;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99,91,255,.09);
        }

        .field-hint {
            display: block;
            margin-top: 6px;
            color: #9299a9;
            font-size: 10px;
        }

        .referral-input {
            text-transform: uppercase;
        }

        .form-check {
            padding-left: 25px;
        }

        .form-check-input {
            border-color: #cdd1dd;
            cursor: pointer;
        }

        .form-check-input:checked {
            border-color: var(--primary);
            background-color: var(--primary);
        }

        .form-check-input:focus {
            box-shadow: 0 0 0 3px rgba(99,91,255,.09);
        }

        .form-check-label {
            color: #70788c;
            font-size: 11px;
            line-height: 1.6;
            cursor: pointer;
        }

        .register-btn {
            width: 100%;
            height: 51px;
            border: none;
            border-radius: 9px;
            background: var(--primary);
            color: #fff;
            font-size: 13px;
            font-weight: 700;
            transition: .2s ease;
        }

        .register-btn:hover {
            background: var(--primary-hover);
            color: #fff;
        }

        .register-alert {
            padding: 12px 14px;
            border-radius: 9px;
            font-size: 12px;
        }

        .register-footer {
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid #f0f1f5;
            text-align: center;
            color: var(--muted);
            font-size: 12px;
        }

        .register-footer a {
            color: var(--primary);
            font-weight: 700;
            text-decoration: none;
        }

        .register-footer a:hover {
            text-decoration: underline;
        }

        .back-home {
            display: inline-block;
            margin-top: 15px;
            color: #9299a9 !important;
            font-size: 11px;
            font-weight: 500 !important;
        }

        .back-home:hover {
            color: var(--primary) !important;
        }

        .security-note {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 7px;
            margin-top: 20px;
            color: #9aa1af;
            font-size: 10px;
        }

        .security-note i {
            color: #20a477;
        }

        .success-actions {
            text-align: center;
            padding: 15px 0 5px;
        }

        .success-icon {
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            border-radius: 50%;
            background: #eaf8f1;
            color: #20a477;
            font-size: 26px;
        }

        .success-actions h4 {
            font-size: 19px;
            font-weight: 800;
            margin-bottom: 8px;
        }

        .success-actions p {
            color: var(--muted);
            font-size: 12px;
        }

        @media (max-width: 576px) {
            body {
                padding: 18px 12px;
            }

            .register-card {
                padding: 32px 22px 25px;
                border-radius: 13px;
            }

            .heading h2 {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

<div class="register-card">

    <a href="../home.php" class="brand">
        <span class="brand-icon">
            <i class="bi bi-layers-fill"></i>
        </span>
        <span class="brand-name">Digital<span>Market</span></span>
    </a>

    <?php if ($success === ''): ?>

        <div class="heading">
            <h2>Create Account</h2>
            <p>Enter your information to get started.</p>
        </div>

        <?php if ($error !== ''): ?>
            <div class="alert alert-danger register-alert mb-4" role="alert">
                <i class="bi bi-exclamation-circle-fill me-2"></i>
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="register.php">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>"
            >

            <div class="mb-3">
                <label for="full_name" class="form-label">Full Name *</label>

                <input
                    type="text"
                    id="full_name"
                    name="full_name"
                    class="form-control"
                    placeholder="Enter your full name"
                    value="<?= htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8') ?>"
                    maxlength="150"
                    autocomplete="name"
                    required
                >
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="username" class="form-label">Username *</label>

                    <input
                        type="text"
                        id="username"
                        name="username"
                        class="form-control"
                        placeholder="Choose a username"
                        value="<?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?>"
                        minlength="4"
                        maxlength="60"
                        pattern="[A-Za-z0-9_]+"
                        autocomplete="username"
                        required
                    >

                    <small class="field-hint">Letters, numbers and underscores only.</small>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="phone" class="form-label">Phone Number</label>

                    <input
                        type="tel"
                        id="phone"
                        name="phone"
                        class="form-control"
                        placeholder="Enter phone number"
                        value="<?= htmlspecialchars($phone, ENT_QUOTES, 'UTF-8') ?>"
                        maxlength="30"
                        autocomplete="tel"
                    >
                </div>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email Address *</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    class="form-control"
                    placeholder="example@email.com"
                    value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
                    maxlength="150"
                    autocomplete="email"
                    required
                >
            </div>

            <div class="mb-3">
                <label for="referral_code" class="form-label">
                    Referral Code <span class="text-secondary fw-normal">(Optional)</span>
                </label>

                <input
                    type="text"
                    id="referral_code"
                    name="referral_code"
                    class="form-control referral-input"
                    placeholder="Enter referral code if available"
                    value="<?= htmlspecialchars($referralCode, ENT_QUOTES, 'UTF-8') ?>"
                    maxlength="30"
                >
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="password" class="form-label">Password *</label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        class="form-control"
                        placeholder="Minimum 8 characters"
                        minlength="8"
                        autocomplete="new-password"
                        required
                    >
                </div>

                <div class="col-md-6 mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password *</label>

                    <input
                        type="password"
                        id="confirm_password"
                        name="confirm_password"
                        class="form-control"
                        placeholder="Repeat password"
                        minlength="8"
                        autocomplete="new-password"
                        required
                    >
                </div>
            </div>

            <div class="form-check mb-4 mt-1">
                <input
                    type="checkbox"
                    class="form-check-input"
                    id="terms"
                    required
                >

                <label class="form-check-label" for="terms">
                    I confirm that the information provided is correct
                    and agree to follow the platform rules.
                </label>
            </div>

            <button type="submit" class="btn register-btn">
                Create Account
                <i class="bi bi-arrow-right ms-2"></i>
            </button>

        </form>

        <div class="register-footer">
            Already have an account?
            <a href="login.php">Sign In</a>

            <div>
                <a href="../home.php" class="back-home">
                    <i class="bi bi-arrow-left me-1"></i>
                    Back to Home
                </a>
            </div>
        </div>

    <?php else: ?>

        <div class="success-actions">

            <div class="success-icon">
                <i class="bi bi-check-lg"></i>
            </div>

            <h4>Account Created Successfully</h4>

            <p>Your registration is complete. You can now sign in to your account.</p>

            <a href="login.php" class="btn register-btn mt-3 d-flex align-items-center justify-content-center">
                Continue to Login
                <i class="bi bi-arrow-right ms-2"></i>
            </a>

            <a href="../home.php" class="back-home">
                <i class="bi bi-arrow-left me-1"></i>
                Back to Home
            </a>

        </div>

    <?php endif; ?>

    <div class="security-note">
        <i class="bi bi-shield-lock-fill"></i>
        Secure account registration
    </div>

</div>

</body>
</html>
