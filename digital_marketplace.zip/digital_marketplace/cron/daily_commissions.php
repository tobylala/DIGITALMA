<?php
/**
 * DigitalMarket - Exact 24-hour Daily Commission Processor
 *
 * First payment: purchase timestamp + 24 hours.
 * Later payments: every 24 hours, for 365 payments.
 * Run this script every minute using Windows Task Scheduler.
 */

date_default_timezone_set('Africa/Addis_Ababa');
$timezone = new DateTimeZone('Africa/Addis_Ababa');
$isCli = (PHP_SAPI === 'cli');
$messages = [];
$errors = [];
$processed = 0;
$skipped = 0;
$failed = 0;

function outputMessage(string $message, bool $isCli): void
{
    global $messages;
    $messages[] = $message;
    if ($isCli) echo $message . PHP_EOL;
}

function outputError(string $message, bool $isCli): void
{
    global $errors;
    $errors[] = $message;
    if ($isCli) echo 'ERROR: ' . $message . PHP_EOL;
}

if (!$isCli) {
    session_start();
    if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
        http_response_code(403);
        exit('Administrator access required.');
    }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ?>
        <!DOCTYPE html><html lang="en"><head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Daily Commission Processor - DigitalMarket</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head><body class="bg-light"><div class="container py-5">
        <div class="card shadow-sm mx-auto" style="max-width:650px"><div class="card-body p-4">
        <h3>Daily Commission Processor</h3>
        <p class="text-muted">Processes every payment whose exact 24-hour due time has arrived.</p>
        <div class="alert alert-info">The first payment is due 24 hours after purchase. The processor catches up missed due payments and prevents duplicate payments.</div>
        <form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
        <button class="btn btn-primary" type="submit">Process Due Commissions</button>
        <a class="btn btn-secondary" href="../admin/dashboard.php">Cancel</a></form>
        </div></div></div></body></html>
        <?php
        exit;
    }
    $submittedToken = $_POST['csrf_token'] ?? '';
    if (!is_string($submittedToken) || !hash_equals($_SESSION['csrf_token'], $submittedToken)) {
        http_response_code(403);
        exit('Invalid security token. Refresh and try again.');
    }
}

require_once __DIR__ . '/../config/database.php';
if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$now = new DateTimeImmutable('now', $timezone);
$nowSql = $now->format('Y-m-d H:i:s');
outputMessage('DigitalMarket Exact 24-hour Commission Processor', $isCli);
outputMessage('Current Addis Ababa time: ' . $nowSql, $isCli);
outputMessage('------------------------------------------------', $isCli);

try {
    $stmt = $pdo->prepare("SELECT id FROM daily_commission_schedules WHERE status = 'active' AND next_due_at <= ? ORDER BY next_due_at, id");
    $stmt->execute([$nowSql]);
    $scheduleIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) {
    outputError('Unable to load due schedules: ' . $e->getMessage(), $isCli);
    $scheduleIds = [];
}

foreach ($scheduleIds as $scheduleId) {
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("SELECT * FROM daily_commission_schedules WHERE id = ? AND status = 'active' FOR UPDATE");
        $stmt->execute([(int)$scheduleId]);
        $schedule = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$schedule) {
            $pdo->commit();
            $skipped++;
            continue;
        }

        $nextDue = new DateTimeImmutable($schedule['next_due_at'], $timezone);
        $endAt = new DateTimeImmutable($schedule['end_at'], $timezone);
        if ($nextDue > $now || (int)$schedule['payments_made'] >= (int)$schedule['duration_days']) {
            $pdo->commit();
            $skipped++;
            continue;
        }

        $userId = (int)$schedule['user_id'];
        $stmt = $pdo->prepare("SELECT id, balance FROM wallet_accounts WHERE user_id = ? AND wallet_type = 'commission' FOR UPDATE");
        $stmt->execute([$userId]);
        $wallet = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$wallet) {
            $stmt = $pdo->prepare("INSERT INTO wallet_accounts (user_id, wallet_type, balance, reserved_balance) VALUES (?, 'commission', 0.00, 0.00)");
            $stmt->execute([$userId]);
            $walletId = (int)$pdo->lastInsertId();
            $balance = 0.00;
        } else {
            $walletId = (int)$wallet['id'];
            $balance = (float)$wallet['balance'];
        }

        $paidThisSchedule = 0;
        while ($nextDue <= $now && $nextDue <= $endAt && (int)$schedule['payments_made'] < (int)$schedule['duration_days']) {
            $paymentNumber = (int)$schedule['payments_made'] + 1;
            $amount = round((float)$schedule['purchase_price'] * ((float)$schedule['daily_rate'] / 100), 2);
            if ((float)$schedule['purchase_price'] <= 0 || $amount <= 0) {
                throw new RuntimeException('Invalid purchase price or commission amount.');
            }

            $balance = round($balance + $amount, 2);
            $dueAtSql = $nextDue->format('Y-m-d H:i:s');
            $commissionDate = $nextDue->format('Y-m-d');

            $stmt = $pdo->prepare("UPDATE wallet_accounts SET balance = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$balance, $walletId]);

            $stmt = $pdo->prepare("INSERT INTO daily_commission_logs (schedule_id, user_id, commission_date, amount, wallet_id, balance_after, payment_number, due_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([(int)$schedule['id'], $userId, $commissionDate, $amount, $walletId, $balance, $paymentNumber, $dueAtSql]);
            $logId = (int)$pdo->lastInsertId();

            $idempotencyKey = 'daily_commission_' . (int)$schedule['id'] . '_' . $paymentNumber;
            $description = 'Daily product commission payment ' . $paymentNumber . '/' . (int)$schedule['duration_days'];
            $stmt = $pdo->prepare("INSERT INTO wallet_transactions (wallet_id, transaction_type, amount, balance_after, reference_type, reference_id, idempotency_key, description) VALUES (?, 'credit', ?, ?, 'daily_commission', ?, ?, ?)");
            $stmt->execute([$walletId, $amount, $balance, $logId, $idempotencyKey, $description]);

            $schedule['payments_made'] = $paymentNumber;
            $paidThisSchedule++;
            $nextDue = $nextDue->modify('+24 hours');
        }

        $newStatus = ((int)$schedule['payments_made'] >= (int)$schedule['duration_days']) ? 'completed' : 'active';
        $stmt = $pdo->prepare("UPDATE daily_commission_schedules SET payments_made = ?, next_due_at = ?, status = ? WHERE id = ?");
        $stmt->execute([(int)$schedule['payments_made'], $nextDue->format('Y-m-d H:i:s'), $newStatus, (int)$schedule['id']]);
        $pdo->commit();

        $processed += $paidThisSchedule;
        outputMessage('Schedule #' . $scheduleId . ': paid ' . $paidThisSchedule . ' payment(s), user #' . $userId . ', latest balance ' . number_format($balance, 2) . ' ETB.', $isCli);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $failed++;
        outputError('Schedule #' . $scheduleId . ': ' . $e->getMessage(), $isCli);
    }
}

outputMessage('------------------------------------------------', $isCli);
outputMessage('Processing completed. Payments credited: ' . $processed, $isCli);
outputMessage('Skipped schedules: ' . $skipped, $isCli);
outputMessage('Failed schedules: ' . $failed, $isCli);

if (!$isCli) {
    ?>
    <!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Commission Processing Results</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
    <body class="bg-light"><div class="container py-5"><div class="card shadow-sm mx-auto" style="max-width:760px"><div class="card-body p-4">
    <h3>Daily Commission Results</h3><p class="text-muted">Processed at <?= htmlspecialchars($nowSql, ENT_QUOTES, 'UTF-8') ?> (Africa/Addis_Ababa)</p>
    <div class="row g-3 mb-4"><div class="col-4"><div class="alert alert-success"><strong><?= $processed ?></strong><br>Payments</div></div><div class="col-4"><div class="alert alert-secondary"><strong><?= $skipped ?></strong><br>Skipped</div></div><div class="col-4"><div class="alert alert-danger"><strong><?= $failed ?></strong><br>Failed</div></div></div>
    <ul class="list-group mb-4"><?php foreach ($messages as $message): ?><li class="list-group-item"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></li><?php endforeach; ?><?php foreach ($errors as $error): ?><li class="list-group-item list-group-item-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></li><?php endforeach; ?></ul>
    <a href="../admin/dashboard.php" class="btn btn-primary">Back to Admin Dashboard</a></div></div></div></body></html>
    <?php
}
