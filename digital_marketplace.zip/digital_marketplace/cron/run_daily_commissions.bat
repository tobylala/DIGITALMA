@echo off
REM Run the exact 24-hour commission processor.
REM This file is intended to be called by Windows Task Scheduler every minute.
"C:\xampp\php\php.exe" "%~dp0daily_commissions.php" >> "%~dp0daily_commissions.log" 2>&1
