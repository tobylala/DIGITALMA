DIGITALMARKET - EXACT 24-HOUR DAILY COMMISSIONS

RULE
- First commission is due exactly 24 hours after the successful purchase timestamp.
- Each later commission is due exactly 24 hours after the previous due time.
- The schedule has 365 payments.
- Amount = purchase price x daily rate / 100.
- All timestamps use Africa/Addis_Ababa local time.

INSTALL
1. Back up your digital_marketplace database.
2. Open phpMyAdmin and select the digital_marketplace database.
3. Import database/exact_24_hour_commissions_migration.sql.
4. Replace your project files with the updated user/product_details.php,
   user/commissions.php, and cron/daily_commissions.php from this package.
5. Confirm the PHP executable path in cron/run_daily_commissions.bat.
   The default is C:\xampp\php\php.exe.
6. Open Windows Task Scheduler -> Create Task.
7. On Triggers, create a trigger that repeats every 1 minute indefinitely.
8. On Actions, choose Start a program and select:
   C:\xampp\htdocs\digital_marketplace\cron\run_daily_commissions.bat
9. Save the task and choose Run once to test it.
10. Check cron/daily_commissions.log and the daily_commission_logs,
    wallet_accounts, and wallet_transactions tables.

IMPORTANT
- The processor must run at least once per minute for near-on-time payments.
- If Windows/XAMPP is off when a payment becomes due, the processor catches up
  missed due payments when it runs again. The wallet credit and records are
  committed together, and each schedule/payment number is unique.
- Existing schedules are migrated using their original created_at timestamp
  and existing payment count. Verify migrated next_due_at values in phpMyAdmin.
- Take a database backup before importing the migration. Do not import it twice.
