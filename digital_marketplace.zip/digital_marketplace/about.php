
<?php
$pageTitle = 'About Us';
$activePage = 'about';
include 'includes/header.php';
?>

<section class="page-banner">
    <div class="container">
        <h1>About DigitalMarket</h1>
        <p>Learn about our marketplace and what we aim to provide.</p>
    </div>
</section>

<section class="section-padding">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <h2 class="section-heading">A Marketplace for Digital Products</h2>
                <p>
                    DigitalMarket is a digital product marketplace designed
                    to connect customers with useful digital resources.
                    The platform also provides an affiliate system through
                    which registered users can refer customers.
                </p>
                <p>
                    Customers can explore products, make purchases and
                    access the digital content they have purchased.
                    Affiliates can share referral links and earn commissions
                    from qualifying completed sales according to platform rules.
                </p>
            </div>

            <div class="col-lg-6">
                <div class="info-card">
                    <div class="feature-icon">
                        <i class="bi bi-bullseye"></i>
                    </div>
                    <h4 class="section-heading">Our Mission</h4>
                    <p class="text-secondary mb-0">
                        To provide an accessible and organized digital
                        marketplace with transparent purchasing and
                        affiliate commission processes.
                    </p>
                </div>
            </div>
        </div>

        <div class="row g-4 mt-4">
            <div class="col-md-6">
                <div class="feature-card">
                    <h5><i class="bi bi-eye me-2 text-warning"></i>Our Vision</h5>
                    <p class="text-secondary mb-0">
                        To build a trusted digital marketplace that makes
                        digital products easier to discover and access.
                    </p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="feature-card">
                    <h5><i class="bi bi-shield-check me-2 text-warning"></i>Our Commitment</h5>
                    <p class="text-secondary mb-0">
                        To maintain clear product information, transparent
                        transactions and responsible affiliate practices.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
