
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

date_default_timezone_set('Africa/Addis_Ababa');

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection is not available.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$userId = (int) $_SESSION['user_id'];

function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function money($amount): string
{
    return number_format((float)($amount ?? 0), 2) . ' ETB';
}

function statusClass($status): string
{
    return match (strtolower((string)$status)) {
        'approved', 'completed', 'active', 'paid' => 'success',
        'pending' => 'warning',
        'reversed', 'cancelled', 'rejected', 'inactive' => 'danger',
        default => 'secondary'
    };
}

try {
    /*
    |--------------------------------------------------------------------------
    | USER INFORMATION
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT id, full_name, username, referral_code
        FROM users
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        session_destroy();
        header('Location: ../auth/login.php');
        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | COMMISSION WALLET BALANCE
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT balance, reserved_balance
        FROM wallet_accounts
        WHERE user_id = ?
          AND wallet_type = 'commission'
        LIMIT 1
    ");
    $stmt->execute([$userId]);
    $commissionWallet = $stmt->fetch(PDO::FETCH_ASSOC);

    $walletBalance = (float)($commissionWallet['balance'] ?? 0);
    $walletReserved = (float)($commissionWallet['reserved_balance'] ?? 0);
    $availableBalance = max(0, $walletBalance - $walletReserved);

    /*
    |--------------------------------------------------------------------------
    | DAILY COMMISSION TOTAL
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            COALESCE(SUM(amount), 0) AS total_earned,
            COUNT(*) AS total_payments
        FROM daily_commission_logs
        WHERE user_id = ?
    ");
    $stmt->execute([$userId]);
    $dailySummary = $stmt->fetch(PDO::FETCH_ASSOC);

    $dailyTotal = (float)($dailySummary['total_earned'] ?? 0);
    $dailyPayments = (int)($dailySummary['total_payments'] ?? 0);

    /*
    |--------------------------------------------------------------------------
    | DAILY COMMISSION SCHEDULES
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            s.id,
            s.order_id,
            s.product_id,
            s.purchase_price,
            s.daily_rate,
            s.duration_days,
            s.start_date,
            s.end_date,
            s.start_at,
            s.next_due_at,
            s.end_at,
            s.payments_made,
            s.status,
            s.created_at,
            p.product_name
        FROM daily_commission_schedules s
        LEFT JOIN products p
            ON p.id = s.product_id
        WHERE s.user_id = ?
        ORDER BY s.created_at DESC
        LIMIT 20
    ");
    $stmt->execute([$userId]);
    $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /*
    |--------------------------------------------------------------------------
    | DAILY COMMISSION HISTORY
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            id,
            schedule_id,
            commission_date,
            amount,
            balance_after,
            payment_number,
            due_at,
            created_at
        FROM daily_commission_logs
        WHERE user_id = ?
        ORDER BY commission_date DESC, id DESC
        LIMIT 20
    ");
    $stmt->execute([$userId]);
    $dailyHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /*
    |--------------------------------------------------------------------------
    | REFERRAL COMMISSION SUMMARY
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            COALESCE(SUM(amount), 0) AS total_referral,
            COALESCE(SUM(
                CASE WHEN status = 'pending' THEN amount ELSE 0 END
            ), 0) AS pending_referral,
            COALESCE(SUM(
                CASE WHEN status = 'approved' THEN amount ELSE 0 END
            ), 0) AS approved_referral,
            COUNT(*) AS total_referrals
        FROM commissions
        WHERE affiliate_id = ?
    ");
    $stmt->execute([$userId]);
    $referralSummary = $stmt->fetch(PDO::FETCH_ASSOC);

    $referralTotal = (float)($referralSummary['total_referral'] ?? 0);
    $pendingReferral = (float)($referralSummary['pending_referral'] ?? 0);
    $approvedReferral = (float)($referralSummary['approved_referral'] ?? 0);
    $referralCount = (int)($referralSummary['total_referrals'] ?? 0);

    /*
    |--------------------------------------------------------------------------
    | REFERRAL COMMISSION HISTORY
    | Show the buyer/member's full name instead of the order number.
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            c.id,
            c.order_id,
            c.order_item_id,
            c.amount,
            c.status,
            c.created_at,
            c.approved_at,
            buyer.full_name AS referred_member_name,
            buyer.username AS referred_member_username
        FROM commissions c
        LEFT JOIN orders o
            ON o.id = c.order_id
        LEFT JOIN users buyer
            ON buyer.id = o.user_id
        WHERE c.affiliate_id = ?
        ORDER BY c.created_at DESC
        LIMIT 20
    ");
    $stmt->execute([$userId]);
    $referralHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /*
    |--------------------------------------------------------------------------
    | REFERRAL MEMBERS
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            id,
            full_name,
            username,
            created_at
        FROM users
        WHERE referred_by = ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$userId]);
    $referredMembers = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    error_log('Commissions page error: ' . $exception->getMessage());
    die('Unable to load commission information. Please try again later.');
}

$activeSchedules = 0;
foreach ($schedules as $schedule) {
    if (strtolower((string)$schedule['status']) === 'active') {
        $activeSchedules++;
    }
}

$totalReferredMembers = count($referredMembers);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Commissions | Digital Marketplace</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #635bff;
            --primary-dark: #5148e5;
            --dark: #171b2e;
            --muted: #7b8195;
            --background: #f6f7fb;
            --border: #eceef4;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--background);
            color: var(--dark);
            font-family: 'Inter', sans-serif;
            font-size: 14px;
        }

        .main-content {
            max-width: 1250px;
            margin: auto;
            padding: 32px 24px;
        }

        .page-heading {
            margin-bottom: 25px;
        }

        .page-heading h2 {
            font-size: 25px;
            font-weight: 800;
            margin-bottom: 7px;
        }

        .page-heading p {
            color: var(--muted);
            margin: 0;
        }

        .summary-card {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 15px;
            padding: 22px;
            height: 100%;
            box-shadow: 0 3px 15px rgba(20, 25, 50, .025);
        }

        .summary-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }

        .summary-icon {
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            font-size: 21px;
        }

        .purple {
            background: #eeedff;
            color: var(--primary);
        }

        .green {
            background: #e8f8ef;
            color: #179653;
        }

        .orange {
            background: #fff3e7;
            color: #e58a24;
        }

        .blue {
            background: #eaf3ff;
            color: #2879d0;
        }

        .summary-label {
            color: var(--muted);
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .summary-value {
            font-size: 23px;
            font-weight: 800;
            letter-spacing: -.5px;
            overflow-wrap: anywhere;
        }

        .summary-note {
            color: var(--muted);
            font-size: 11px;
            margin-top: 7px;
        }

        .content-card {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 15px;
            margin-top: 25px;
            overflow: hidden;
            box-shadow: 0 3px 15px rgba(20, 25, 50, .025);
        }

        .card-heading {
            padding: 20px 22px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .card-heading h5 {
            font-size: 15px;
            font-weight: 800;
            margin: 0;
        }

        .card-heading p {
            color: var(--muted);
            font-size: 12px;
            margin: 5px 0 0;
        }

        .table-responsive {
            padding: 0 18px 10px;
        }

        .table {
            margin: 0;
            vertical-align: middle;
        }

        .table thead th {
            color: var(--muted);
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .4px;
            padding: 16px 12px;
            border-bottom: 1px solid var(--border);
            white-space: nowrap;
        }

        .table tbody td {
            padding: 15px 12px;
            border-bottom: 1px solid #f0f1f5;
            font-size: 12px;
        }

        .table tbody tr:last-child td {
            border-bottom: none;
        }

        .member-avatar {
            width: 37px;
            height: 37px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: #eeedff;
            color: var(--primary);
            font-size: 15px;
            flex-shrink: 0;
        }

        .member-name {
            font-weight: 700;
            color: var(--dark);
        }

        .member-username {
            color: var(--muted);
            font-size: 11px;
            margin-top: 3px;
        }

        .amount {
            font-weight: 800;
            white-space: nowrap;
        }

        .badge {
            padding: 7px 10px;
            font-size: 10px;
            font-weight: 700;
            border-radius: 20px;
        }

        .program-box {
            padding: 22px;
        }

        .program-highlight {
            background: linear-gradient(120deg, #635bff, #8178ff);
            color: #fff;
            border-radius: 14px;
            padding: 23px;
            margin-bottom: 20px;
        }

        .program-highlight h4 {
            font-weight: 800;
            font-size: 20px;
        }

        .program-highlight p {
            color: rgba(255,255,255,.85);
            font-size: 12px;
            margin-bottom: 0;
        }

        .program-number {
            font-size: 30px;
            font-weight: 800;
            margin: 10px 0;
        }

        .empty-state {
            text-align: center;
            padding: 42px 15px;
            color: var(--muted);
        }

        .empty-state i {
            font-size: 35px;
            color: #b9bdca;
            display: block;
            margin-bottom: 12px;
        }

        .empty-state strong {
            color: var(--dark);
            display: block;
            margin-bottom: 5px;
        }

        .referral-code {
            background: #f2f1ff;
            border: 1px dashed #c7c3ff;
            border-radius: 10px;
            padding: 12px 15px;
            color: var(--primary);
            font-weight: 800;
            letter-spacing: 1px;
        }

        .copy-btn {
            border: 0;
            background: var(--primary);
            color: white;
            border-radius: 8px;
            padding: 9px 13px;
            font-size: 12px;
            font-weight: 700;
        }

        .copy-btn:hover {
            background: var(--primary-dark);
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 22px 13px;
            }

            .page-heading h2 {
                font-size: 21px;
            }

            .summary-value {
                font-size: 19px;
            }

            .summary-card {
                padding: 17px;
            }
        }
    </style>
</head>

<body>

<div class="main-content">

    <!-- PAGE HEADING -->
    <div class="page-heading">
        <h2>My Commissions</h2>
        <p>Track your daily earnings, referral commissions, and referred members.</p>
    </div>

    <!-- SUMMARY CARDS -->
    <div class="row g-3">

        <div class="col-12 col-sm-6 col-xl-3">
            <div class="summary-card">
                <div class="summary-top">
                    <span class="summary-label">Commission Wallet</span>
                    <div class="summary-icon purple">
                        <i class="bi bi-wallet2"></i>
                    </div>
                </div>
                <div class="summary-value"><?= e(money($availableBalance)) ?></div>
                <div class="summary-note">Available commission balance</div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-xl-3">
            <div class="summary-card">
                <div class="summary-top">
                    <span class="summary-label">Daily Commissions</span>
                    <div class="summary-icon green">
                        <i class="bi bi-calendar-check"></i>
                    </div>
                </div>
                <div class="summary-value"><?= e(money($dailyTotal)) ?></div>
                <div class="summary-note"><?= $dailyPayments ?> daily payments received</div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-xl-3">
            <div class="summary-card">
                <div class="summary-top">
                    <span class="summary-label">Referral Commissions</span>
                    <div class="summary-icon orange">
                        <i class="bi bi-people"></i>
                    </div>
                </div>
                <div class="summary-value"><?= e(money($referralTotal)) ?></div>
                <div class="summary-note"><?= $referralCount ?> referral commission records</div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-xl-3">
            <div class="summary-card">
                <div class="summary-top">
                    <span class="summary-label">Referred Members</span>
                    <div class="summary-icon blue">
                        <i class="bi bi-person-plus"></i>
                    </div>
                </div>
                <div class="summary-value"><?= number_format($totalReferredMembers) ?></div>
                <div class="summary-note">Members registered using your referral</div>
            </div>
        </div>

    </div>

    <!-- DAILY COMMISSION PROGRAM -->
    <div class="content-card">
        <div class="card-heading">
            <div>
                <h5><i class="bi bi-calendar2-check me-2 text-primary"></i>Daily Commission Program</h5>
                <p>Daily earnings generated from your completed product purchases.</p>
            </div>
            <span class="badge bg-success">Automatic Program</span>
        </div>

        <div class="program-box">

            <div class="program-highlight">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4>Earn Daily for 365 Days</h4>
                        <p>Receive a daily commission based on the original purchase price of an eligible product.</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <div class="program-number">5%</div>
                        <p>Daily commission rate</p>
                    </div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-md-4">
                    <div class="summary-card">
                        <div class="summary-label">Daily Rate</div>
                        <div class="summary-value">5%</div>
                        <div class="summary-note">Of the original purchase price</div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="summary-card">
                        <div class="summary-label">Duration</div>
                        <div class="summary-value">365 Days</div>
                        <div class="summary-note">One year per eligible purchase</div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="summary-card">
                        <div class="summary-label">Active Schedules</div>
                        <div class="summary-value"><?= number_format($activeSchedules) ?></div>
                        <div class="summary-note">Currently active commission schedules</div>
                    </div>
                </div>
            </div>

            <div class="mt-4">
                <h6 class="fw-bold mb-3">Your Daily Commission Schedules</h6>

                <?php if (empty($schedules)): ?>
                    <div class="empty-state">
                        <i class="bi bi-calendar-x"></i>
                        <strong>No daily commission schedules yet</strong>
                        <span>Eligible schedules will appear here after your purchases.</span>
                    </div>
                <?php else: ?>

                    <div class="table-responsive px-0">
                        <table class="table">
                            <thead>
                            <tr>
                                <th>Product</th>
                                <th>Purchase Price</th>
                                <th>Daily Rate</th>
                                <th>Duration</th>
                                <th>First Payment Due</th>
                                <th>Next Payment Due</th>
                                <th>Payments</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($schedules as $schedule): ?>
                                <tr>
                                    <td>
                                        <strong><?= e($schedule['product_name'] ?: 'Product #' . $schedule['product_id']) ?></strong>
                                    </td>
                                    <td><?= e(money($schedule['purchase_price'])) ?></td>
                                    <td class="amount"><?= e($schedule['daily_rate']) ?>%</td>
                                    <td><?= (int)$schedule['duration_days'] ?> days</td>
                                    <td><?= e($schedule['start_at']) ?></td>
                                    <td><?= $schedule['status'] === 'active' ? e($schedule['next_due_at']) : '—' ?></td>
                                    <td><?= (int)$schedule['payments_made'] ?> / <?= (int)$schedule['duration_days'] ?></td>
                                    <td>
                                        <span class="badge bg-<?= e(statusClass($schedule['status'])) ?>">
                                            <?= e(ucfirst($schedule['status'])) ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- DAILY COMMISSION HISTORY -->
    <div class="content-card">
        <div class="card-heading">
            <div>
                <h5><i class="bi bi-clock-history me-2 text-primary"></i>Daily Commission History</h5>
                <p>Your automatically credited daily commission transactions.</p>
            </div>
            <span class="badge bg-primary"><?= number_format($dailyPayments) ?> Payments</span>
        </div>

        <?php if (empty($dailyHistory)): ?>
            <div class="empty-state">
                <i class="bi bi-receipt"></i>
                <strong>No daily commission payments yet</strong>
                <span>Your daily payment history will appear here.</span>
            </div>
        <?php else: ?>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>Payment Due Time</th>
                        <th>Payment #</th>
                        <th>Schedule ID</th>
                        <th>Amount</th>
                        <th>Wallet Balance After</th>
                        <th>Recorded At</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($dailyHistory as $log): ?>
                        <tr>
                            <td><?= e($log['due_at']) ?></td>
                            <td><?= (int)$log['payment_number'] ?></td>
                            <td>#<?= (int)$log['schedule_id'] ?></td>
                            <td class="amount text-success">+<?= e(money($log['amount'])) ?></td>
                            <td><?= e(money($log['balance_after'])) ?></td>
                            <td><?= e($log['created_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>
    </div>

    <!-- REFERRAL COMMISSION SUMMARY -->
    <div class="content-card">
        <div class="card-heading">
            <div>
                <h5><i class="bi bi-people-fill me-2 text-primary"></i>Referral Commissions</h5>
                <p>Commissions generated when members referred by you purchase products.</p>
            </div>
        </div>

        <div class="program-box">
            <div class="row g-3">
                <div class="col-md-4">
                    <div class="summary-card">
                        <div class="summary-label">Total Referral Commission</div>
                        <div class="summary-value"><?= e(money($referralTotal)) ?></div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="summary-card">
                        <div class="summary-label">Pending Approval</div>
                        <div class="summary-value text-warning"><?= e(money($pendingReferral)) ?></div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="summary-card">
                        <div class="summary-label">Approved Commission</div>
                        <div class="summary-value text-success"><?= e(money($approvedReferral)) ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- REFERRAL HISTORY: MEMBER NAME INSTEAD OF ORDER NUMBER -->
        <div class="card-heading">
            <div>
                <h5>Referral Commission History</h5>
                <p>Purchases made by members you referred.</p>
            </div>
        </div>

        <?php if (empty($referralHistory)): ?>

            <div class="empty-state">
                <i class="bi bi-people"></i>
                <strong>No referral commissions yet</strong>
                <span>When a referred member purchases a product, their commission record will appear here.</span>
            </div>

        <?php else: ?>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>Referred Member</th>
                        <th>Commission Amount</th>
                        <th>Status</th>
                        <th>Purchase Date</th>
                        <th>Approved Date</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php foreach ($referralHistory as $commission): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="member-avatar">
                                        <i class="bi bi-person-fill"></i>
                                    </div>

                                    <div>
                                        <div class="member-name">
                                            <?= e($commission['referred_member_name'] ?: 'Unknown Member') ?>
                                        </div>

                                        <?php if (!empty($commission['referred_member_username'])): ?>
                                            <div class="member-username">
                                                @<?= e($commission['referred_member_username']) ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>

                            <td class="amount text-success">
                                <?= e(money($commission['amount'])) ?>
                            </td>

                            <td>
                                <span class="badge bg-<?= e(statusClass($commission['status'])) ?>">
                                    <?= e(ucfirst($commission['status'])) ?>
                                </span>
                            </td>

                            <td><?= e($commission['created_at']) ?></td>

                            <td>
                                <?= !empty($commission['approved_at'])
                                    ? e($commission['approved_at'])
                                    : '<span class="text-muted">Not approved</span>' ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>
    </div>

    <!-- REFERRED MEMBERS -->
    <div class="content-card">
        <div class="card-heading">
            <div>
                <h5><i class="bi bi-person-plus me-2 text-primary"></i>My Referred Members</h5>
                <p>Members who registered using your referral code.</p>
            </div>

            <span class="badge bg-primary">
                <?= number_format($totalReferredMembers) ?> Members
            </span>
        </div>

        <div class="program-box">

            <?php if (!empty($user['referral_code'])): ?>
                <div class="mb-4">
                    <div class="summary-label mb-2">Your Referral Code</div>

                    <div class="d-flex flex-wrap align-items-center gap-2">
                        <div class="referral-code" id="referralCode">
                            <?= e($user['referral_code']) ?>
                        </div>

                        <button type="button" class="copy-btn" onclick="copyReferralCode()">
                            <i class="bi bi-copy me-1"></i> Copy Code
                        </button>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (empty($referredMembers)): ?>

                <div class="empty-state">
                    <i class="bi bi-person-plus"></i>
                    <strong>No referred members yet</strong>
                    <span>Members who register using your referral code will appear here.</span>
                </div>

            <?php else: ?>

                <div class="table-responsive px-0">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Member Name</th>
                            <th>Username</th>
                            <th>Registration Date</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php foreach ($referredMembers as $member): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="member-avatar">
                                            <i class="bi bi-person-fill"></i>
                                        </div>
                                        <strong><?= e($member['full_name']) ?></strong>
                                    </div>
                                </td>

                                <td>@<?= e($member['username']) ?></td>

                                <td><?= e($member['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php endif; ?>
        </div>
    </div>

</div>

<script>
function copyReferralCode() {
    const codeElement = document.getElementById('referralCode');

    if (!codeElement) {
        return;
    }

    const code = codeElement.innerText.trim();

    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(code).then(function () {
            alert('Referral code copied successfully.');
        }).catch(function () {
            fallbackCopy(code);
        });
    } else {
        fallbackCopy(code);
    }
}

function fallbackCopy(text) {
    const input = document.createElement('textarea');
    input.value = text;
    input.style.position = 'fixed';
    input.style.opacity = '0';

    document.body.appendChild(input);
    input.select();

    try {
        document.execCommand('copy');
        alert('Referral code copied successfully.');
    } catch (error) {
        alert('Unable to copy the referral code.');
    }

    document.body.removeChild(input);
}
</script>

</body>
</html>
