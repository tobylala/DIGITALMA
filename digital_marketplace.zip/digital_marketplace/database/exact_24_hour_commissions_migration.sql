-- DigitalMarket: migrate daily commissions to exact 24-hour intervals.
-- BACK UP your database before running this script.
USE digital_marketplace;

ALTER TABLE daily_commission_schedules
    ADD COLUMN start_at DATETIME NULL AFTER end_date,
    ADD COLUMN next_due_at DATETIME NULL AFTER start_at,
    ADD COLUMN end_at DATETIME NULL AFTER next_due_at,
    ADD COLUMN payments_made SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER end_at;

ALTER TABLE daily_commission_logs
    ADD COLUMN payment_number SMALLINT UNSIGNED NULL AFTER balance_after,
    ADD COLUMN due_at DATETIME NULL AFTER payment_number;

-- Preserve existing history and set the next payment based on the original
-- schedule creation timestamp plus one 24-hour interval for each payment already logged.
UPDATE daily_commission_schedules s
LEFT JOIN (
    SELECT schedule_id, COUNT(*) AS paid_count
    FROM daily_commission_logs
    GROUP BY schedule_id
) x ON x.schedule_id = s.id
SET s.start_at = DATE_ADD(s.created_at, INTERVAL 24 HOUR),
    s.payments_made = COALESCE(x.paid_count, 0),
    s.next_due_at = DATE_ADD(s.created_at, INTERVAL (COALESCE(x.paid_count, 0) + 1) DAY),
    s.end_at = DATE_ADD(DATE_ADD(s.created_at, INTERVAL 24 HOUR), INTERVAL (s.duration_days - 1) DAY);

-- Give historical log rows a sequential payment number and a due timestamp.
UPDATE daily_commission_logs l
JOIN (
    SELECT id, ROW_NUMBER() OVER (PARTITION BY schedule_id ORDER BY id) AS payment_no
    FROM daily_commission_logs
) numbered ON numbered.id = l.id
JOIN daily_commission_schedules s ON s.id = l.schedule_id
SET l.payment_number = numbered.payment_no,
    l.due_at = DATE_ADD(s.start_at, INTERVAL (numbered.payment_no - 1) DAY);

ALTER TABLE daily_commission_logs
    MODIFY payment_number SMALLINT UNSIGNED NOT NULL,
    MODIFY due_at DATETIME NOT NULL,
    DROP INDEX uq_schedule_commission_date,
    ADD UNIQUE KEY uq_schedule_payment_number (schedule_id, payment_number),
    ADD KEY idx_daily_log_due_at (due_at);

ALTER TABLE daily_commission_schedules
    MODIFY start_at DATETIME NOT NULL,
    MODIFY next_due_at DATETIME NOT NULL,
    MODIFY end_at DATETIME NOT NULL,
    ADD KEY idx_daily_schedule_next_due (status, next_due_at);
