
<?php

require_once __DIR__ . '/config/database.php';

session_start();

if (!isset($pdo) || !$pdo instanceof PDO) {
    die('Database connection failed. Check config/database.php.');
}

$errors = [];
$success = false;

if (empty($_SESSION['admin_setup_token'])) {
    $_SESSION['admin_setup_token'] = bin2hex(random_bytes(32));
}

// Only allow initial setup when no administrator exists.
$adminCount = (int)$pdo->query(
    "SELECT COUNT(*) FROM users WHERE role = 'admin'"
)->fetchColumn();

if ($adminCount > 0) {
    die(
        '<h2>Administrator already exists.</h2>
         <p>For security, this setup page is disabled.</p>
         <p>Please delete create_admin.php from your project.</p>'
    );
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (
        !isset($_POST['csrf_token']) ||
        !hash_equals(
            $_SESSION['admin_setup_token'],
            (string)$_POST['csrf_token']
        )
    ) {
        $errors[] = 'Invalid request. Refresh the page and try again.';
    }

    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($fullName === '' || strlen($fullName) > 150) {
        $errors[] = 'Enter a valid full name.';
    }

    if (
        !preg_match('/^[a-zA-Z0-9_]{3,60}$/', $username)
    ) {
        $errors[] = 'Username must be 3–60 characters and contain only letters, numbers, and underscores.';
    }

    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }

    if (strlen($password) < 8) {
        $errors[] = 'Password must contain at least 8 characters.';
    }

    if ($password !== $confirmPassword) {
        $errors[] = 'Passwords do not match.';
    }

    if (empty($errors)) {
        try {
            // Check duplicate username or email.
            $check = $pdo->prepare(
                "SELECT id FROM users
                 WHERE username = ?
                    OR (email = ? AND ? <> '')
                 LIMIT 1"
            );

            $check->execute([$username, $email, $email]);

            if ($check->fetch()) {
                $errors[] = 'Username or email already exists.';
            } else {

                // Generate a unique referral code.
                do {
                    $referralCode = 'ADM' . strtoupper(
                        bin2hex(random_bytes(4))
                    );

                    $refCheck = $pdo->prepare(
                        "SELECT id FROM users WHERE referral_code = ?"
                    );
                    $refCheck->execute([$referralCode]);

                } while ($refCheck->fetch());

                $hashedPassword = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $insert = $pdo->prepare(
                    "INSERT INTO users
                    (
                        full_name,
                        username,
                        email,
                        phone,
                        password,
                        role,
                        status,
                        referral_code,
                        referred_by
                    )
                    VALUES (?, ?, ?, ?, ?, 'admin', 'active', ?, NULL)"
                );

                $insert->execute([
                    $fullName,
                    $username,
                    $email !== '' ? $email : null,
                    $phone !== '' ? $phone : null,
                    $hashedPassword,
                    $referralCode
                ]);

                $success = true;

                // Invalidate the setup token.
                unset($_SESSION['admin_setup_token']);
            }

        } catch (PDOException $e) {
            $errors[] = 'Database error. Check your database configuration.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Create Administrator | Digital Marketplace</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
          rel="stylesheet">

    <style>
        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 25px;
            background: linear-gradient(135deg, #101827, #1e3a5f);
            font-family: Arial, sans-serif;
        }

        .setup-card {
            width: 100%;
            max-width: 520px;
            padding: 35px;
            border-radius: 18px;
            background: #fff;
            box-shadow: 0 20px 60px rgba(0,0,0,.25);
        }

        .setup-icon {
            width: 65px;
            height: 65px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #e8f0ff;
            color: #2457c5;
            border-radius: 18px;
            font-size: 30px;
        }

        .form-label {
            font-weight: 600;
            color: #344054;
        }

        .form-control {
            padding: 12px;
            border-radius: 9px;
        }

        .btn-create {
            padding: 13px;
            border-radius: 9px;
            font-weight: 600;
            background: #2457c5;
            border: none;
        }
    </style>
</head>

<body>

<div class="setup-card">

    <div class="text-center mb-4">
        <div class="setup-icon">
            <i class="bi bi-shield-lock-fill"></i>
        </div>

        <h3 class="fw-bold">Create Administrator</h3>

        <p class="text-muted">
            Digital Marketplace initial administrator setup
        </p>
    </div>

    <?php if ($success): ?>

        <div class="alert alert-success">
            <h5><i class="bi bi-check-circle-fill"></i> Administrator created!</h5>
            Your new administrator account has been created successfully.
        </div>

        <div class="alert alert-warning">
            <strong>Important security step:</strong>
            Delete <code>create_admin.php</code> from your project immediately.
        </div>

        <a href="auth/login.php" class="btn btn-primary w-100">
            Go to Login
        </a>

    <?php else: ?>

        <?php foreach ($errors as $error): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endforeach; ?>

        <form method="POST" autocomplete="off">

            <input type="hidden"
                   name="csrf_token"
                   value="<?= htmlspecialchars($_SESSION['admin_setup_token'], ENT_QUOTES, 'UTF-8') ?>">

            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input type="text"
                       name="full_name"
                       class="form-control"
                       maxlength="150"
                       required
                       value="<?= htmlspecialchars($_POST['full_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text"
                       name="username"
                       class="form-control"
                       maxlength="60"
                       required
                       value="<?= htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Email Address</label>
                <input type="email"
                       name="email"
                       class="form-control"
                       value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Phone Number</label>
                <input type="text"
                       name="phone"
                       class="form-control"
                       value="<?= htmlspecialchars($_POST['phone'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password"
                       name="password"
                       class="form-control"
                       minlength="8"
                       required>
            </div>

            <div class="mb-4">
                <label class="form-label">Confirm Password</label>
                <input type="password"
                       name="confirm_password"
                       class="form-control"
                       minlength="8"
                       required>
            </div>

            <button type="submit" class="btn btn-primary btn-create w-100">
                <i class="bi bi-person-plus-fill"></i>
                Create Administrator Account
            </button>

        </form>

    <?php endif; ?>

</div>

</body>
</html>
